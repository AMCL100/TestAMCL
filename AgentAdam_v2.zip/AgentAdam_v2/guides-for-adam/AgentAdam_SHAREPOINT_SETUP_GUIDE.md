# AgentAdam — SharePoint Instructions Setup (for Adam)

> **What this achieves:** AgentAdam's core rules load automatically into
> every VS Code session for every developer on the team — regardless of
> which folder they have open. When you update the rules, SharePoint syncs
> them to everyone automatically. No per-report files. No cloning. No git
> pull. Update once, everyone gets it.

---

## How it works

```
You maintain ONE file in a SharePoint folder
Each developer adds ONE setting to VS Code
From that point it is completely automatic

You update the file → SharePoint syncs → everyone has it
Developer opens any folder in VS Code → rules load automatically
Nobody has to do anything to get updates ever again
```

---

## The SharePoint location

Your folder is already created at:

```
https://iberdrola.sharepoint.com/sites/UK Operations/
  UK Operations Document Library/
    Reporting/
      Data Visualisation/
        Agentic BI - AgentAdam/          ← put the file here
```

The file to put there: agentadam.instructions.md
(included in this package alongside this guide)

---

## Step 1 — Upload the file (you do this once)

```
1. Open the SharePoint folder in your browser using this link:
   https://iberdrola.sharepoint.com/sites/UK%20Operations/
   UK%20Operations%20Document%20Library/Reporting/
   Data%20Visualisation/Agentic%20BI%20-%20AgentAdam

2. Upload agentadam.instructions.md to that folder
   Drag and drop, or use Upload → Files

3. Done — the file is live
```

---

## Step 2 — Sync the folder to your machine (you do this once)

The VS Code setting needs a local file path. SharePoint syncs to your machine
via the OneDrive sync client.

```
1. In the SharePoint folder (browser), click Sync at the top
   This adds the folder to your OneDrive sync client
   
2. The folder syncs to your machine at:
   C:\Users\[yourname]\IBERDROLA S.A\UK Operations - UK Operations
   Document Library\Reporting\Data Visualisation\Agentic BI - AgentAdam\
```

**Verify the path on your machine:**

```
1. Open File Explorer
2. Look for a folder in your user directory starting with "Iberdrola"
   (or possibly "ScottishPower" — depends on how Iberdrola configured
    the tenant display name on SP machines)
3. Navigate down to: ...UK Operations - UK Operations Document Library\
   Reporting\Data Visualisation\Agentic BI - AgentAdam\
4. Confirm agentadam.instructions.md is there
5. Note the exact top-level folder name (Iberdrola or ScottishPower)
   — you will need it for the VS Code setting
```

---

## Step 3 — Add the VS Code setting (you do this once)

```
1. Open VS Code
2. Press Ctrl+Shift+P
3. Run: Open User Settings (JSON)
   (must say USER settings — not Workspace settings)
4. Add this:

   "chat.instructionsFilesLocations": {
     "~/IBERDROLA S.A/UK Operations - Agentic BI - AgentAdam": true
   }

   (If your top-level folder is "ScottishPower" not "Iberdrola", use that instead)

5. Save (Ctrl+S)
6. Reload window: Ctrl+Shift+P → Developer: Reload Window
```

**If your settings.json already has other settings**, add it inside the
existing curly braces — do not create a second pair:

```json
{
  "editor.fontSize": 14,
  "chat.plugins.enabled": true,
  "chat.instructionsFilesLocations": {
    "~/IBERDROLA S.A/UK Operations - Agentic BI - AgentAdam": true
  }
}
```

---

## Step 4 — Confirm it works

Open any folder in VS Code (does not need to be a report). Open Copilot Chat
and ask:

```
What is Zone C and its coordinates?
```

Expected answer: y:136–1066, x:28–2535

If that answers correctly without opening the AgentAdam repo, without
cloning anything, without any startup commands — it is fully working.

---

## Step 5 — Roll out to the team

Each developer needs to do Steps 2 and 3 once. Send them
AgentAdam_PLUGIN_TEAM_GUIDE.md — it has the exact steps written for
non-technical users.

```
Post in Teams:
"Quick setup needed for AgentAdam — takes 5 minutes, then it's automatic
 forever. Follow the guide I've shared. Ping me if anything doesn't work."
```

---

## When you update the rules

```
1. Edit agentadam.instructions.md in your local synced SharePoint folder
   (or edit it directly in SharePoint in the browser)
2. SharePoint syncs to everyone's machine automatically
   (usually within 1-2 minutes)
3. Post in Teams: "AgentAdam rules updated — takes effect next session"
```

That is it. No GitHub push needed for core rules. No telling developers
to pull or sync. They get it automatically.

---

## What still lives in GitHub

The SharePoint file handles always-on core rules. GitHub still handles
the plugin skills which load on demand for specialist topics.

```
GitHub (auto-updates via plugin, 24h):
  DAX standards skill
  SQL review skill
  Semantic model skill
  Incremental refresh skill
  Documentation skill
  Template standards skill
  Model evaluation skill

SharePoint (auto-updates via sync, ~1 min):
  Core always-on rules — zones, governance, session start,
  colours, SQL review approach, end-of-session checklist
```

Together they give complete coverage. No developer needs to do anything
after the initial one-time setup.

---

## Maintenance — the sync rule going forward

You now have rules in TWO active places (down from three with the
template approach):

```
1. AgentAdam/AgentAdam.md           human-readable source (reference)
2. skills/*/SKILL.md                plugin skills (push to GitHub)
3. agentadam.instructions.md        SharePoint file (save to SharePoint)
```

When you change a rule:
- Update the SharePoint file → team gets it immediately via sync
- Update the matching skill if it is a specialist-topic rule
- Keep AgentAdam.md in sync as the human-readable source

The auto-generation script (on the roadmap) will collapse this to one
command when you're ready for it.

---

## Troubleshooting

```
Rules not loading in VS Code?
  Check the path in settings.json exactly matches your File Explorer path
  The folder name is case-sensitive
  Reload window after any settings change (Ctrl+Shift+P → Developer: Reload Window)

Not sure if it is Iberdrola or ScottishPower in the path?
  File Explorer → navigate to C:\Users\[yourname]\
  Look for the folder — the name is visible there

SharePoint not syncing?
  Open the OneDrive sync client (system tray)
  Check the Iberdrola account is signed in and syncing
  Right-click the OneDrive icon → Settings → Account
```

---

*Questions → Adam McLean. Test on your own machine first.*
