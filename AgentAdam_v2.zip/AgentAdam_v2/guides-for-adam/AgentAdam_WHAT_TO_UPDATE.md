# AgentAdam — What You Need to Update

> **For:** Adam McLean — repo owner
> **Purpose:** Complete checklist of everything to do to get the
> SharePoint-based setup live for your team.

---

## The three things that carry AgentAdam's rules

```
1. SharePoint file (always-on core rules)
   agentadam.instructions.md
   Location: Agentic BI - AgentAdam folder on SharePoint
   Updates: auto-sync to all developers when you save it

2. Plugin skills (specialist knowledge, on demand)
   skills/*/SKILL.md in the GitHub repo
   Updates: auto-push to all developers via plugin within 24h

3. Template Report folder files (fallback only)
   AGENTS.md and .github/copilot-instructions.md
   Inside PBI_Corporate_Template.Report/
   Only used if someone hasn't done the SharePoint setup
```

---

## Part A — SharePoint (do this first)

### A1. Upload the instructions file

```
1. Open the SharePoint folder in your browser:
   https://iberdrola.sharepoint.com/sites/UK%20Operations/
   UK%20Operations%20Document%20Library/Reporting/
   Data%20Visualisation/Agentic%20BI%20-%20AgentAdam

2. Upload agentadam.instructions.md from this package
   (it is in the root of the package alongside this guide)

3. Confirm it is there before moving on
```

### A2. Sync it to your own machine and test

```
1. Click Sync in the SharePoint browser
2. Wait for the folder to appear on your machine at:
   C:\Users\adamm\IBERDROLA S.A\UK Operations - UK Operations
   Document Library\Reporting\Data Visualisation\Agentic BI - AgentAdam\
   (check whether it says Iberdrola or ScottishPower at the top)

3. Add the VS Code user setting:
   Press Ctrl+Shift+P → Open User Settings (JSON) → add:

   "chat.instructionsFilesLocations": {
     "~/IBERDROLA S.A/UK Operations - Agentic BI - AgentAdam": true
   }

4. Reload window: Ctrl+Shift+P → Developer: Reload Window

5. Open any folder in VS Code and ask:
   "What is Zone C and its coordinates?"
   Expect: y:136–1066, x:28–2535
   If correct — SharePoint approach is working on your machine.
```

---

## Part B — GitHub repo (do this second)

### B1. Add the plugin files

From the `repo-files/` folder in this package, add to your repo:

```
.github/
  copilot-instructions.md         (repo-level fallback)
  plugin/
    marketplace.json

plugins/
  agentadam/
    .github/
      plugin.json

skills/
  dax-standards/SKILL.md
  sql-review/SKILL.md
  semantic-model/SKILL.md
  incremental-refresh/SKILL.md
  documentation/SKILL.md
  template-standards/SKILL.md
  model-evaluation/SKILL.md
```

### B2. Add the template instruction files (fallback)

```
AgentAdam/templates/PBI_Corporate_Template.Report/
  AGENTS.md                    (from TEMPLATE_AGENTS.md in the package)
  .github/
    copilot-instructions.md    (from TEMPLATE_copilot-instructions.md)

These are the fallback for anyone not yet on the SharePoint setup.
Not required for the SharePoint approach to work — just belt-and-braces.
```

### B3. Add the documentation files

```
docs/
  AgentAdam_PLUGIN_TEAM_GUIDE.md
  AgentAdam_REPORT_PLANNING_TEMPLATE.md
  AgentAdam_WORKFLOW_COLLAPSIBLE.html

ROADMAP.md           (repo root)
README.md            (repo root)
```

### B4. Commit and push

```
git add .
git commit -m "Add plugin structure, SharePoint instructions, updated docs"
git push origin main
```

### B5. Test the plugin install

```
Ctrl+Shift+P → Chat: Install Plugin From Source → paste repo URL
Ctrl+Shift+X → confirm agentadam appears under Agent Plugins - Installed
Ask: "How many slicers can go on the top bar?"
Expect: max 4, divided equally, 5th to the filter pane
```

---

## Part C — Roll out to the team

### C1. Send the team guide

Share `AgentAdam_PLUGIN_TEAM_GUIDE.md` with the team. It walks them
through all 7 setup steps including the SharePoint sync and the VS Code
setting.

### C2. Post in Teams

```
"AgentAdam is now live as a plugin.
 Follow the setup guide I've shared — takes about 10 minutes.
 After that it's automatic forever.
 Ping me if anything doesn't work."
```

### C3. Walk one person through it first

Before sending to the whole team, do it with one teammate.
Confirm they get the correct Zone C answer before rolling out wider.

---

## When you update the core rules going forward

```
Update agentadam.instructions.md in the SharePoint folder
  → save it → SharePoint syncs to everyone automatically
  → post in Teams so they know something changed

Update skills if the change is specialist-topic (DAX, SQL, etc.)
  → update skills/[relevant]/SKILL.md in the repo
  → push to GitHub → plugin auto-updates within 24h

Keep AgentAdam/AgentAdam.md in sync as the human-readable source
```

---

*Test on your own machine before telling the team. Walk one person through
it first. Keep the old method documented as a fallback during the preview period.*
