---
name: AgentAdam Incremental Refresh
description: Use when setting up or assessing incremental refresh on a Power BI table. Provides a 7-step suitability assessment covering query folding, date columns, RangeStart/RangeEnd parameters, data change detection, and size justification. Trigger whenever incremental refresh, large tables, or slow refreshes are discussed.
---

# AgentAdam — Incremental refresh skill

> **Status:** TEST  
> **Owner:** Adam McLean - COE Data Governance & Visualisation  
> **Last updated:** 2026-05-30  
> **Review cycle:** Fortnightly  
>  
> **Do not alter this file.** This is a governed standards document.  
> If you think a rule needs changing, raise it with Adam McLean directly.  
> Local changes will be overwritten on next `git pull`.


When a user asks about incremental refresh or table partitioning,
always run through this full assessment before making any recommendations
or writing any code. Never skip steps.

Important: the agent can implement incremental refresh correctly in the
TMDL files but CANNOT verify it is actually working. Silent failures are
common. The developer must always validate in their dev workspace after
implementation.

---

## Before starting

Confirm backup exists.
Confirm Power BI Desktop is closed.
Confirm user understands the agent will implement but cannot verify.

---

## Step 1 — Query folding check

Review the Power Query M code for the table in question.

Connectors that support folding:
  SQL Server, Azure SQL, Synapse Analytics, Snowflake,
  Databricks, BigQuery, PostgreSQL, Oracle, Teradata

Connectors that do NOT support folding:
  Excel, CSV, SharePoint lists, Web connectors,
  OData feeds, flat files, REST APIs, JSON/XML sources

If source does not support folding — stop:
  "Incremental refresh requires query folding. This table uses
   [connector] which does not support folding. A full refresh
   is the correct approach for this table."

Folding breakers to check for in the query steps:
  Table.Buffer(), List.Buffer(), Table.ToList()
  Custom functions applied row by row
  Index columns added before the date filter
  Merges/joins with non-foldable sources
  Any step that breaks the native query

Is the RangeStart/RangeEnd filter applied BEFORE any folding-breaking step?
If not — folding is broken. Stop and flag.

If folding cannot be confirmed — stop:
  "Query folding cannot be confirmed. Check in Power Query Editor:
   right-click each step and look for View Native Query.
   If greyed out, that step breaks folding.
   The date filter must appear before any folding-breaking step."

---

## Step 2 — Date column suitability

Check all of the following:
  Is it a date or datetime column? (not text formatted as date)
  Is it populated for every row? (nulls break partitioning)
  Is it a load or transaction date — not calculated or derived?
  Is it consistent across all historical data?

If any fail — stop and flag the specific issue before proceeding.

---

## Step 3 — RangeStart and RangeEnd parameters

Must exist with exactly these properties:
  Name:    RangeStart  (case sensitive)
  Name:    RangeEnd    (case sensitive)
  Type:    Date/Time   (NOT Date alone — Date type causes silent failures)
  Default: sensible historical dates

Critical — Date vs DateTime:
  Date type is the most common cause of silent incremental refresh failure.
  It appears to work but refreshes the full table every time.

If parameters missing → offer to add, show M code first, wait for confirmation.
If parameters are Date type not DateTime → flag as critical before proceeding:
  "RangeStart and RangeEnd are Date type not DateTime. This causes
   a common silent failure. I will correct these — please confirm."

---

## Step 4 — Data change pattern

Ask the user:
  "Does historical data ever change after it has landed?
   e.g. late arriving transactions, backdated entries, corrections."

If yes — ask:
  "Does the source table have a last modified timestamp column?"

  If yes to both: recommend detect data changes using that column.

  If no modified timestamp:
    "Historical data changes but no modified timestamp exists.
     Options:
     a. Add a last modified timestamp at source (recommended)
     b. Use a longer refresh window to catch late changes
     c. Accept that historical corrections will not be picked up
     Which would you like to do?"
    Wait for decision before proceeding.

---

## Step 5 — Size and refresh justification

Ask the user:
  Approximate current row count
  Daily or weekly growth rate
  Current full refresh duration

Only recommend incremental refresh if at least one is true:
  Table exceeds 1 million rows
  Full refresh takes more than 10 minutes
  Refresh window is causing scheduling problems

If thresholds not met:
  "Based on the table size you described, incremental refresh
   may add complexity that is not justified here. A full refresh
   is simpler and easier to maintain. Would you like to proceed
   anyway or stick with a full refresh?"

---

## Step 6 — Pre-implementation summary

Present before writing anything:

  INCREMENTAL REFRESH ASSESSMENT
  ================================
  Table:              [name]
  Query folding:      CONFIRMED / NOT CONFIRMED
  Date column:        [column] — SUITABLE / ISSUES: [describe]
  Parameters:         PRESENT AND CORRECT / MISSING / WRONG TYPE
  Historical changes: YES / NO — [notes]
  Size justified:     YES / NO — [row count, refresh time]

  Recommendation:     PROCEED / DO NOT PROCEED

  Proposed policy:
    Refresh window:   [X days/months]
    Historical store: [X years/months]
    Detect changes:   YES using [column] / NO

  Issues to resolve: [list any]

  Shall I proceed?

Wait for explicit confirmation before writing any TMDL or M code.

---

## Step 7 — Post-implementation reminders

After implementing always tell the user all of the following:

  "Important — the agent cannot verify incremental refresh is
   working correctly. You must validate this yourself:

   1. Publish to your dev workspace before testing.
      Incremental refresh does not activate in Desktop refresh.

   2. The first refresh after enabling will be slow.
      Power BI is building all historical partitions.

   3. After the first publish, monitor the next 3-5 refreshes.
      Check that only the refresh window is being processed,
      not the full historical data.

   4. If refresh times do not improve after the first full build,
      something may be misconfigured. Common silent failures:
        — Query folding broken by a Power Query step
        — RangeStart/RangeEnd are Date type not DateTime
        — Date filter applied after a folding-breaking step

   5. Validate in your dev workspace fully before promoting
      to production."

---

*Last updated: 2026-05-30*
*Owner: Adam McLean - COE Data Governance & Visualisation*
*Review cycle: Fortnightly*


---

*AgentAdam is built on the [data-goblin/power-bi-agentic-development](https://github.com/data-goblin/power-bi-agentic-development) toolkit by Kurt Buhler. AgentAdam adds SP Customer Business-specific standards and governance on top of his work.*
