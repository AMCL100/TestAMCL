---
name: AgentAdam Semantic Model
description: Use when working with the Power BI semantic model — tables, relationships, partitions, TMDL files, and connection handling. Covers model structure rules, partition SQL editing, and credential safety. Trigger whenever the data model rather than the report layer is being changed.
---

# AgentAdam — Semantic model skill

> **Status:** TEST  
> **Owner:** Adam McLean - COE Data Governance & Visualisation  
> **Last updated:** 2026-05-30  
> **Review cycle:** Fortnightly  
>  
> **Do not alter this file.** This is a governed standards document.  
> If you think a rule needs changing, raise it with Adam McLean directly.  
> Local changes will be overwritten on next `git pull`.


This skill defines how the agent works with Power BI semantic models.
The agent reads this file whenever a user asks for semantic model work.

---

## Before starting any model work

Confirm backup exists before making any changes.
Confirm Power BI Desktop is closed.
Ask the user to describe what they need before touching any file.

---

## What the agent can do

Reading:
  Read all TMDL files and describe the model structure
  List tables, columns, measures, relationships, hierarchies
  Read and describe RLS role definitions
  Read and describe incremental refresh policies
  Produce documentation via AgentAdam_DOCUMENTATION_SKILL.md

Writing and editing:
  Write new DAX measures following AgentAdam_DAX_STANDARDS.md
  Edit existing DAX measures
  Add descriptions, display folders, and format strings
  Add or modify table and column descriptions
  Write correct TMDL when user provides full specification
  Write incremental refresh policies following
    AgentAdam_INCREMENTAL_REFRESH_SKILL.md
  Edit relationship properties when explicitly instructed
  Edit hierarchy definitions

Validation:
  Check TMDL syntax correctness
  Check referential integrity within model files
  Flag violations of AgentAdam_DAX_STANDARDS.md
  Flag missing measure metadata
  Flag potential issues (many-to-many, bidirectional,
    isolated tables, calculated columns on fact tables)

---

## What the agent cannot do

These are hard limitations — not workarounds.

Cannot connect to data sources
  Agent works entirely within TMDL files on disk.
  Cannot browse warehouse schema or discover table/column names.
  Cannot validate that column names in TMDL exist at source.
  User must provide: table name, column names, data types.

Cannot refresh or execute
  Cannot trigger a model refresh.
  Cannot test whether changes load correctly.
  Cannot verify that measures return correct results.
  All changes must be validated by a human in Desktop.

Cannot validate data quality
  Cannot check whether relationship keys match in actual data.
  Cannot identify orphaned rows in fact tables.
  Cannot detect nulls in key columns.

Cannot assess performance
  Cannot predict whether a DAX pattern will be slow.
  Cannot assess relationship choices for performance.
  Cannot evaluate storage mode choices.

Cannot design from scratch
  Cannot look at a data source and design a semantic model.
  Cannot decide which tables are facts vs dimensions.
  Cannot determine correct grain for fact tables.
  Cannot choose relationship directions from business requirements.

---

## Specific area rules

### DAX measures
Always follow AgentAdam_DAX_STANDARDS.md in full.
Every measure must have description, display folder, format string.

### Relationships
May read and describe all relationships.
May edit relationship properties only when:
  User provides explicit instruction
  User confirms the business reason
After any relationship change always remind user:
  "Please refresh the model in Desktop and test reports
   that use tables involved in this relationship."

Many-to-many:
  Flag — always requires explicit user confirmation
  Never create without documented business reason

Bidirectional:
  Flag any existing ones
  Never add without explicit instruction

### Calculated columns
NEVER on fact tables — absolute ban, no exceptions.
See AgentAdam_DAX_STANDARDS.md for dimension table rules.

### RLS
May read and describe existing RLS definitions.
If user wants to change existing RLS:
  Flag: "Changing RLS affects data access. Confirm intended
  access pattern and ensure thorough testing after implementation."
Proceed only with explicit confirmation.
Never modify RLS silently.

### Incremental refresh
Always follow AgentAdam_INCREMENTAL_REFRESH_SKILL.md in full.
After implementing always warn developer to validate in dev workspace.
Cannot verify it is working from the file layer alone.

### Partitions and SQL
May read and edit partition SQL only when explicitly instructed.
Always show proposed changes before writing.
Always remind user to test by refreshing in Desktop.
Never add, remove, or rename data sources without approval.

### Connection strings and credentials in SQL

When reading partition SQL or M code from TMDL files,
the agent must:

  Never reproduce connection strings in its responses
  Never include server names or database names verbatim
    unless the user has explicitly asked
  Strip any credentials before discussing the query
  Treat connection details as sensitive data

When reviewing SQL via the SQL_REVIEW_SKILL:
  Only the query logic gets discussed — not the data source
  If a query contains hardcoded credentials, flag this as
  a security issue and recommend moving credentials to
  a secure parameter or gateway connection

### Hierarchies
May read, create, and edit hierarchies.
Always confirm with user: level names, order, source columns.

---

## After any model change

Always tell the user:
  "Please open the .pbip in Desktop, refresh with real data,
   and test all affected measures and reports before publishing.
   Human validation in Desktop is always required."

---

## Honest summary for users

The agent is a skilled assistant for semantic model work,
not an autonomous model designer.

Works best when:
  You tell it exactly what you need
  The model structure already exists
  You need DAX written, reviewed, or standardised
  You want model documentation generated

Needs human judgment for:
  Architectural decisions
  Business logic validation
  Performance assessment
  RLS and security decisions
  Any change that could break existing reports

---

*Last updated: 2026-05-30*
*Owner: Adam McLean - COE Data Governance & Visualisation*
*Review cycle: Fortnightly*

---

## SQL queries used to import data

When a developer shares a SQL query or when reading SQL from
TMDL partition definitions, always run:
AgentAdam/AgentAdam_SQL_REVIEW_SKILL.md

This reviews the query for complexity and performance risk
before the developer imports anything into the model.

Simple queries are fine to use directly in Power BI.
Complex queries should be pre-built in Synapse first.

The agent explains findings in plain English — no jargon.


---

*AgentAdam is built on the [data-goblin/power-bi-agentic-development](https://github.com/data-goblin/power-bi-agentic-development) toolkit by Kurt Buhler. AgentAdam adds SP Customer Business-specific standards and governance on top of his work.*
