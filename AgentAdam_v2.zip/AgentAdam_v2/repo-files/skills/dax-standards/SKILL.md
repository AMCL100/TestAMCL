---
name: AgentAdam DAX Standards
description: Use when writing, reviewing, or editing DAX measures for Power BI at SP Customer Business. Covers measure naming, format strings, display folders, performance rules, the ban on calculated columns on fact tables, and capacity-safe DAX patterns. Trigger whenever DAX is created or modified.
---

# AgentAdam — DAX standards and governance

> **Status:** TEST  
> **Owner:** Adam McLean - COE Data Governance & Visualisation  
> **Last updated:** 2026-05-30  
> **Review cycle:** Fortnightly  
>  
> **Do not alter this file.** This is a governed standards document.  
> If you think a rule needs changing, raise it with Adam McLean directly.  
> Local changes will be overwritten on next `git pull`.


This file defines approved DAX patterns, banned practices, and naming
conventions for all semantic models at AgentAdam.
Applies to all developers and to the AI agent working on this codebase.

---

## Before writing any DAX — mandatory

Always:
  Confirm a backup exists before making model changes
  Confirm Power BI Desktop is closed before editing model files
  Check that every new measure has description, display folder,
  and format string before considering the work complete

---

## Measure metadata — mandatory for every measure

Every measure without exception must have all three.
Never consider model work complete without checking these.

| Requirement | Rule |
|---|---|
| Description | What it calculates and when to use it |
| Display folder | Grouped with related measures — never ungrouped |
| Format string | Always explicit — never leave the default |

---

## Naming conventions

| Type | Convention | Example |
|---|---|---|
| Aggregations | Prefix Total | Total Sales, Total Cost, Total Units |
| Time intelligence | Suffix with period | Sales YTD, Sales MTD, Sales LY |
| Comparisons | Use vs | Sales vs Target, Margin vs Budget |
| Percentages | Suffix % | Margin %, Attach Rate %, Growth % |
| Counts | Prefix # | # Customers, # Orders, # Products |
| Flags / booleans | Prefix Is | Is Active, Is Returned, Is New Customer |
| Rankings | Prefix Rank | Rank by Sales, Rank by Margin |
| Hidden base measures | Prefix _ | _Base Sales, _Cost Numerator |

Measure names must be clear to a business user without opening the measure.
If the name requires explanation — rename it.

---

## Approved DAX patterns

### 1. Always use DIVIDE — never the slash operator

```dax
-- Approved
Margin % =
DIVIDE([Gross Profit], [Total Sales], 0)

-- Banned
Margin % = [Gross Profit] / [Total Sales]
```

### 2. Time intelligence via date table only

```dax
-- Approved
Sales YTD =
CALCULATE([Total Sales], DATESYTD('Date'[Date]))

Sales Last Year =
CALCULATE([Total Sales], SAMEPERIODLASTYEAR('Date'[Date]))

-- Banned
Sales 2024 = CALCULATE([Total Sales], 'Date'[Year] = 2024)
Sales YTD  = CALCULATE([Total Sales], 'Date'[Date] <= TODAY())
```

### 3. Use VAR for complex measures

```dax
-- Approved
Sales vs Target =
VAR ActualSales  = [Total Sales]
VAR TargetSales  = [Total Target]
VAR Variance     = ActualSales - TargetSales
RETURN
    DIVIDE(Variance, TargetSales, 0)
```

### 4. Reference measures — never raw column aggregations

```dax
-- Approved
Profit = [Total Sales] - [Total Cost]

-- Banned
Profit = SUM(Sales[Amount]) - SUM(Cost[Amount])
```

### 5. Use SWITCH over nested IF

```dax
-- Approved
Performance Band =
SWITCH(
    TRUE(),
    [Margin %] >= 0.4, "High",
    [Margin %] >= 0.2, "Medium",
    [Margin %] >= 0,   "Low",
    "Loss"
)

-- Banned
Performance Band =
IF([Margin %] >= 0.4, "High",
    IF([Margin %] >= 0.2, "Medium",
        IF([Margin %] >= 0, "Low", "Loss")))
```

### 6. Use REMOVEFILTERS over FILTER(ALL(...))

```dax
-- Approved
All Regions Sales =
CALCULATE([Total Sales], REMOVEFILTERS('Geography'))

-- Banned
All Regions Sales =
CALCULATE([Total Sales], FILTER(ALL('Geography'), TRUE()))
```

---

## Banned DAX patterns

### Calculated columns on fact tables — absolute ban

NEVER create calculated columns on fact tables. No exceptions.

Why:
  Materialises every row at refresh — catastrophic on large tables
  Computed in row context not filter context — unexpected report results
  Almost always indicates a problem to solve upstream

If a calculated column seems necessary on a fact table:
  1. Can this be a measure? Almost always yes.
  2. Should this be in Power Query? If static, yes.
  3. Should this exist in the data warehouse? If business logic, yes.

### Calculated columns on dimension tables — restricted

Permitted only when ALL of the following are true:
  Cannot be done in Power Query
  Is genuinely static — not based on measures
  Reviewed and approved

Acceptable: concatenated labels, age bands, hierarchy levels
Not acceptable: anything aggregating from a fact table

### Hardcoded dates and years

```dax
-- Banned
Sales This Year = CALCULATE([Total Sales], 'Date'[Year] = 2025)

-- Approved
Sales This Year = CALCULATE([Total Sales], DATESYTD('Date'[Date]))
```

### Nested IF statements
Use SWITCH(TRUE()) instead.

### Undocumented measures
No measure published without description, display folder, format string.

---

## Display folder conventions

```
Sales
    Total Sales / Sales YTD / Sales MTD / Sales LY / Sales vs Target

Margin
    Gross Profit / Margin % / Margin vs Budget

Customers
    # Customers / # New Customers / # Active Customers

Operations
    # Orders / # Units / Avg Order Value

_Hidden
    (base measures referenced only by other measures)
    (prefix with _ so they sort to bottom of field list)
```

---

## Agent rules summary

ALWAYS: DIVIDE, date table functions, VAR/RETURN for complex measures,
  measure references not raw aggregations, SWITCH(TRUE()) not nested IF,
  REMOVEFILTERS not FILTER(ALL(...)), description + folder + format string,
  naming conventions above

NEVER: calculated columns on fact tables, hardcoded dates/years,
  undocumented measures, implicit measures

FLAG violations during review — never silently correct.
Always inform the user before making any changes.

---

*Last updated: 2026-05-30*
*Owner: Adam McLean - COE Data Governance & Visualisation*
*Review cycle: Fortnightly*


---

*AgentAdam is built on the [data-goblin/power-bi-agentic-development](https://github.com/data-goblin/power-bi-agentic-development) toolkit by Kurt Buhler. AgentAdam adds SP Customer Business-specific standards and governance on top of his work.*
