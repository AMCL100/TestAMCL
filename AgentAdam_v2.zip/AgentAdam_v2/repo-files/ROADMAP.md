# AgentAdam — Roadmap

> **Owner:** Adam McLean — COE Data Governance & Visualisation
> **Status:** living document — priorities shift as the pilot teaches us things
> **Note:** This file is documentation only. It is not part of the plugin and
> does not affect how AgentAdam behaves. The plugin only loads `skills/`,
> `.github/copilot-instructions.md`, and the manifests.

This captures ideas we have deliberately chosen NOT to build yet, and why.
Parking something here is a decision, not a backlog dump. The discipline of
*not* building things before the pilot proves they are needed is as important
as the building.

---

## Guiding principle

Build the thing that fixes the proven problem, not the thing that sounds most
impressive. Let the pilot tell us where the real friction is before investing
in new capability.

The two things that always need a human — *is this the right design* and *are
these numbers correct* — do not go away as the mechanical work speeds up. They
become more important. Automation should free people up for that judgement,
not attempt to replace it.

---

## Now — in progress

```
Pilot running                     6-week pilot with the team
Plugin rollout (mid-pilot)        installable via VS Code, no CLI needed
Slicer rule fixes applied         width division, 4-slicer cap, button hide
Collecting round-two feedback     after team uses the plugin 1-2 weeks
```

---

## Near term — after the pilot, if proven needed

### Semantic model evaluation skill (read-only health check)

**Status:** designed, not built. Strong candidate. Low risk.

A read-only skill that evaluates an existing semantic model against best
practice and our standards, then produces an advisory health-check report.
It never changes anything — it surfaces candidates and explains its reasoning.
The developer, who has the business context the agent cannot see, decides what
to action.

**What it would evaluate:**

```
Unused objects (the big refresh/size win)
  Columns not used in any measure, relationship, visual, or RLS rule
  Tables not connected to anything
  Measures defined but never surfaced
  Hidden fields that are just dead weight

Cardinality and data types
  High-cardinality columns that bloat the model
    (long hex IDs, GUIDs, free text, timestamps to the second)
  Datetime split into date + time where time is not needed
  Columns that could use lower precision

Model structure
  Calculated columns that should be measures, or pushed back to
    Synapse (ties to the SQL review skill)
  Bi-directional relationships that could be single
  Inactive relationships never used
  Star schema violations

Naming and metadata
  Fields without descriptions
  Missing display folders
  Inconsistent naming vs our standards
  Missing format strings

Refresh efficiency
  Large tables without incremental refresh (ties to that skill)
  Patterns that disable query folding
```

**The critical design rule — conservative on existing products:**

```
When evaluating an EXISTING model, default stance is CONSERVATIVE.
  Assume the model serves purposes beyond what is visible.
  Frame everything as "consider" not "remove".
  Preserve anything ambiguous.
  Treat the existing product as correct-by-default.
  The burden of proof is on REMOVAL, not retention.

When building a NEW model, the agent can be more opinionated about
structure, because nothing is in production yet.
```

**The opening question — before reading any TMDL:**

The agent must ask, because in our org models are often one-per-report (we
have rolled Power BI out widely to people without deep experience, so shared
models are not the norm here — but it is not always the case, so the agent
must check rather than assume).

```
1. Is this model used by more than one report?
   (In our org it is often one model per report — but not always,
    so I need to check before recommending anything.)

2. Are you planning to expand this report or model soon?
   Any features or fields being staged for later?

3. Should I treat this as a finished product, or one you are
   actively building out?
```

The answers set how aggressive the recommendations are allowed to be:

```
One model, one report, finished      → most confident recommendations
One model, one report, still building → conservative on staged fields
Shared across multiple reports         → most conservative; the agent can
                                          only see THIS report and must say so
```

**Confidence grading in the output — never a flat "delete" list:**

```
SAFE TO REVIEW    genuinely orphaned — no relationship, measure,
                  visual, or RLS reference anywhere in this model
CAUTION           unused here but risky — feeds a measure, part of a
                  complete dimension, or a possible key
DO NOT TOUCH      used in relationships, RLS, or active measures,
                  even if not on a visual
```

**The honest limitation, stated in the skill itself:**

```
The agent sees the artefact (files), not the business context.
It can confirm a field is unused in THIS report.
It cannot see: other reports on a shared model, planned features,
occasional stakeholder use, or downstream consumers (Excel, paginated).
Every removal suggestion is "appears unused — confirm before removing",
never "delete this".
```

**Proportionality — grade recommendations by model size, do NOT be dogmatic:**

Most best-practice guides say "star schema, no exceptions." That advice is
written for 50-dashboard enterprise deployments and does not fit our org,
where many models are small and one-per-report. The skill must grade its
recommendations by how universal each practice actually is.

```
TIER 1 — always apply, even on a tiny one-table report (cost ~nothing)
  Disable Auto Date/Time (creates hidden date table per date column;
    measured size cuts of up to ~65%)
  Have a proper Date table, marked as a date table, contiguous
  Correct data types (never store numbers/dates as text)
  Remove genuinely unused columns
  Measures have format strings, descriptions, display folders

TIER 2 — apply by default, but size-dependent (this is the "small report,
one big table is fine" zone)
  Star schema — true at scale, genuinely optional when tiny.
    A 200-row reference report does NOT need fact/dimension splitting.
    Judge by: row counts, number of reports, will it grow.
  Integer surrogate keys — real benefit at millions of rows,
    irrelevant on a 500-row table
  Measures over calculated columns — strong default, but calculated
    columns are sometimes correct (row context a measure can't replicate)

TIER 3 — only when the problem actually exists (premature otherwise)
  Incremental refresh — only for large/slow tables (~1GB+)
  Splitting high-cardinality datetime into date + time — only when that
    column is actually a measured size problem, and remember it forces
    measure rewrites
  Partitioning, composite models, aggregation tables — scale techniques,
    actively harmful as premature complexity on a small model
```

**The governing principle:** the cost of a practice must be proportional to
the size of the problem it solves. A best practice applied where the problem
does not exist is not best practice — it is just complexity. A 300-row
one-table report should be told "turn off Auto Date/Time, add a date table,
fix that text-stored number — the single-table design is fine at this size,
do not over-engineer it." A 5-million-row model gets the full star schema
conversation.

**Why date table is Tier 1 even on a tiny report:** not because convention
says so, but because the alternative (Auto Date/Time, or filtering on a raw
date column) is actively worse — it creates hidden tables and breaks time
intelligence. The skill should explain the reasoning, not just state the rule.

**Why this is a good fit:** read-only, advisory, uses files we already have,
ties to the SQL review and incremental refresh skills, and produces something
immediately useful (a model that finds dead columns pays for itself the first
time it frees up real space and refresh time). Would slot in as
`skills/model-evaluation/SKILL.md`.

---

### Date table detection and generation

**Status:** designed, not built. Tier 1 — every model should have one.
Pairs naturally with the model evaluation skill above.

The agent detects whether a proper date table exists and, if not, offers to
create a standard one. Detectable entirely from the TMDL — no data access
needed for the detection.

**Detection:**

```
Check for a table marked as a date table (the mark-as-date-table flag)
Check for a contiguous date table with a date key
Check whether date columns are relying on Auto Date/Time (which we want
  to kill anyway)
```

**Generation — derive the range dynamically, snap to full years:**

The robust pattern does NOT hardcode dates. It derives the range from the
fact data and extends to the START of the first year and the END of the last,
because time intelligence (YTD, prior year, year-over-year) needs COMPLETE
years to work correctly. A table running 14-Mar-2023 to 8-Nov-2025 silently
breaks those calculations.

```
CALENDAR(
  DATE(YEAR(MIN(Fact[Date])), 1, 1),
  DATE(YEAR(MAX(Fact[Date])), 12, 31)
)
```

**Three creation methods — DAX is our default, but know all three:**

```
1. DAX calculated table (CALENDAR)         ← our default
   Self-contained, no source work needed, "just works" for a
   less-experienced user building a one-off small report
2. Power Query (M)
   Folds where possible, cleaner for fiscal calendars; more complex
3. Date dimension in the source (Synapse today, Databricks later)
   The enterprise answer — one date table reused everywhere.
   Recommend THIS when it is detected to be a shared model that
   should have a proper date dimension. Same proportionality rule.
```

**The safe sequence — detect, ask, show, approve, then act:**

Follows AgentAdam's plan-and-approve philosophy. NEVER silently auto-create
a date table — it could collide with a date column about to be related, or a
fiscal calendar the developer had planned.

```
1. Detect no date table
2. Ask the one question that changes the table:
   "Does your org use a fiscal year different from the calendar year
    (e.g. April-March)? And should it cover a fixed range or track the
    data dynamically as it grows?"
   (A calendar-year table built for a fiscal-year report is a subtle
    wrong-answer that looks right.)
3. Show the exact DAX and explain why (contiguous full years, mark as
   date table, lets you turn off Auto Date/Time)
4. Get approval
5. Add it, mark it as a date table
6. Then prompt to disable Auto Date/Time
```

Detect → ask → show → approve → add → prompt. Safe, correct, and educational
for less-experienced users all at once.

---

### Skill auto-generation script

**Status:** offered, not built. Convenience, not capability.

Core rules currently live in three places that need keeping in sync:
- `AgentAdam/AgentAdam.md` — human-readable source
- `skills/*/SKILL.md` — plugin skills (GitHub, auto-updates)
- `agentadam.instructions.md` — SharePoint file (auto-syncs to team)

A small script would regenerate the SharePoint file and the `skills/`
versions from the `AgentAdam/` source automatically — collapsing the
three-place sync to a single command. Worth building once standards
changes become frequent enough that manual updates get tedious.

---

## Parked — deliberately not building yet

### Semantic model authoring (agent builds the model from Synapse)

**Status:** parked. Revisit when the tooling matures.

The agent could author a full model definition (tables, relationships,
measures in TMDL) and, with Synapse access, ground it in the real schema.
But:

```
Processing is the wall
  The agent can WRITE a model definition.
  Something still has to PROCESS it — connect, pull data, build —
  and that happens in Desktop, the Service, or via XMLA.
  So the agent authors, you still process. Not truly end-to-end yet.

Data validation stays human
  The agent can confirm a query runs.
  It cannot confirm the numbers are right for the business.

Data exposure needs the IT conversation
  Synapse schema and queries going to the Copilot service as
  context is a bigger exposure than report files alone.
  Confirm enterprise agreement coverage BEFORE building this.

A bad model built fast is still a bad model
  The "plan the model" discipline matters MORE when the agent
  can build quickly, not less.
```

**The check before picking this up:** is the team's real bottleneck the report
building, or the model design and stakeholder work? If it is the latter,
authoring helps less than it looks, because the hard part was never the typing.
The pilot should answer this.

---

### Hooks / automated session startup

**Status:** future. Depends on pilot feedback.

Hooks could auto-load standards at session start and run the pre-publish
checklist automatically. Deliberately NOT in the current plugin to keep the
security surface minimal (no auto-running shell commands). Revisit once the
plugin is proven and we understand which manual steps cause the most friction.

---

### GitHub Actions compliance gate

**Status:** longer term.

A PR-level check that runs AgentAdam against a changed report and posts a
compliance review, blocking merge on critical standards violations. Enforces
governance at the gate rather than relying on developers remembering. Needs
the pilot and the hooks work first.

---

## Sequencing

```
Pilot now
  → round-two feedback on the plugin
  → date table detection + generation (Tier 1, low risk, high value)
  → model evaluation skill (read-only, low risk) if proven useful
  → skill auto-generation script when sync gets tedious
  → hooks / auto-startup (3-6 months)
  → model authoring IF the bottleneck proves to be building, not design
  → GitHub Actions compliance gate (6-12 months)
```

Nothing here is committed. Each item earns its place by the pilot or real usage
showing it solves a proven problem.

---

*Questions or want to reprioritise → Adam McLean.*
