# Documentation skill

> **Status:** TEST  
> **Owner:** Adam McLean - COE Data Governance & Visualisation  
> **Last updated:** 2026-05-30  
> **Review cycle:** Fortnightly  
>  
> **Do not alter this file.** This is a governed standards document.  
> If you think a rule needs changing, raise it with Adam McLean directly.  
> Local changes will be overwritten on next `git pull`.


This skill instructs the agent to produce comprehensive documentation
for Power BI reports and semantic models. It covers three outputs:

  1. Visual inventory    — page by page description of every visual
  2. Model diagram       — Mermaid ERD of all tables and relationships
  3. Measure catalogue   — all measures with descriptions and folders

The agent runs this skill when a user asks for any of the following:
  "Document this report"
  "Generate documentation for this model"
  "Create a handover document"
  "Produce a model diagram"
  "Give me a visual inventory"
  Or any similar request for report or model documentation

---

## Before starting — mandatory checks

[ ] Confirm the file is .pbip format (agent cannot read .pbix)
[ ] Confirm Power BI Desktop is closed
[ ] Confirm which template variant (Simple or Interactive)
[ ] Ask the user which outputs they need:
      a. Visual inventory only
      b. Model diagram and measure catalogue only
      c. Full documentation (all three)

Tell the user:
  "I will generate your documentation now. This may take a moment
   as I read through all the report pages and model files.
   I will produce a single markdown file you can save and share."

---

## Output 1 — Visual inventory

Read every report page in the .pbip folder.
For each page, read the visual.json files and extract:
  Visual type
  Title text (if set)
  Fields bound to the visual
  Filters applied at visual level
  Conditional formatting (note if present)
  Position zone (A, B, or C based on coordinates)

Produce output in this format:

```
PAGE DOCUMENTATION
==================

Page: [Page name]
Purpose: [infer from title and visual content — one sentence]
─────────────────────────────────────────────────────────────

Visual 1 — [Visual type]
  Title:              [title text or "No title set" — flag if missing]
  Fields:             [list all bound fields and measures]
  Page filters:       [list any page-level filters]
  Visual filters:     [list any visual-level filters]
  Conditional format: [Yes — describe / No]
  Zone:               [A / B / C]
  Notes:              [anything unusual or worth flagging]

Visual 2 — [Visual type]
  [repeat for every visual on the page]

─────────────────────────────────────────────────────────────
Issues found on this page:
  [ ] [list any visuals with missing titles]
  [ ] [list any visuals with no fields bound — dummy data still present]
  [ ] [list any visuals placed outside their correct zone]
  [ ] [none — if page is fully compliant]
```

Repeat for every page in the report.
Skip pages 1-5 (guidance pages — note them as "Guidance page — not documented").

### Visual title rules — flag these
If any visual has no title set — flag it as a documentation gap.
If any visual title is generic ("Bar Chart", "Card", "Visual 1") — flag it.
Good titles describe the business question: "Revenue by Region", "YTD vs Target"

---

## Output 2 — Data model diagram

Read all TMDL files in the semantic model.
Extract:
  All table names
  All relationships (from, to, cardinality, active/inactive)
  Fact tables vs dimension tables (infer from name and relationship direction)
  Calculated tables (note separately)

Produce a Mermaid ERD diagram:

```mermaid
erDiagram
  [FactTable] }|--|| [DimTable1] : "[Key column]"
  [FactTable] }|--|| [DimTable2] : "[Key column]"
  [FactTable] }|--|| [DimTable3] : "[Key column]"
  [FactTable] }|--|{ [DimTable4] : "[Key column] — inactive"
```

Cardinality notation:
  Many to one (standard):    }|--||
  Many to many (flag this):  }|--|{
  One to one (flag this):    ||--||
  Inactive relationship:     note after the label

After the diagram, produce a relationship summary table:

```
RELATIONSHIP SUMMARY
====================
From table          From column    To table           To column      Type      Active
─────────────────────────────────────────────────────────────────────────────────────
[FactTable]         [DateKey]      [Dim_Date]         [DateKey]      Many:One  Yes
[FactTable]         [ProductKey]   [Dim_Product]      [ProductKey]   Many:One  Yes
[continue for all relationships]

Issues flagged:
  [ ] [list any many-to-many relationships — these need review]
  [ ] [list any inactive relationships — confirm they are intentional]
  [ ] [list any tables with no relationships — isolated tables]
  [ ] [none — if model is clean]
```

---

## Output 3 — Measure catalogue

Read all measures from TMDL files.
For each measure extract:
  Name
  Display folder
  Description (if set)
  Format string
  DAX expression

Produce output in this format:

```
MEASURE CATALOGUE
=================

Display folder: [Folder name]
─────────────────────────────

Measure: [Measure name]
  Description:  [description text or "⚠ MISSING — add a description"]
  Format:       [format string or "⚠ MISSING — add a format string"]
  DAX:
    [measure name] =
    [DAX expression, indented]

Measure: [next measure]
  [repeat]

─────────────────────────────
Display folder: [Next folder]
  [repeat for all folders]

─────────────────────────────
Ungrouped measures (no display folder):
  ⚠ The following measures have no display folder — this violates
    AgentAdam standards. Please assign them to a display folder.
  [list measure names]
```

After the catalogue, produce a compliance summary:

```
MEASURE COMPLIANCE SUMMARY
===========================
Total measures:              [count]
Missing descriptions:        [count] ⚠
Missing format strings:      [count] ⚠
Missing display folders:     [count] ⚠
Fully compliant measures:    [count]

Measures requiring attention:
  [list all non-compliant measure names]
```

---

## Output 4 — Table inventory

Read all tables from TMDL files.
Produce a simple inventory:

```
TABLE INVENTORY
===============
Table                  Type              Columns   Partitions   Notes
─────────────────────────────────────────────────────────────────────
[Fact_Sales]           Fact              [count]   [count]      [notes]
[Dim_Date]             Dimension         [count]   1            Marked as date table
[Dim_Product]          Dimension         [count]   1
[Measure_Table]        Measure table     0         —            Measures only
[CalcTable]            Calculated table  [count]   —            ⚠ Review if needed

Tables with incremental refresh:
  [list any tables with partition policies]

Tables with no relationships:
  ⚠ [list any isolated tables — may be unused]
```

---

## Full documentation output — assembled file

When the user requests full documentation, assemble all outputs
into a single markdown file in this order:

```markdown
# [Report name] — documentation
Generated: [date]
Template:  [Simple / Interactive]
Report type: [Type A / B / C]
Generated by: AI agent using AgentAdam.md documentation skill

---

## Contents
1. Report summary
2. Page visual inventory
3. Data model diagram
4. Relationship summary
5. Table inventory
6. Measure catalogue
7. Compliance summary
8. Issues and recommendations

---

## 1. Report summary
[Brief description inferred from report title, page names, and visual content]
Primary purpose:    [one sentence]
Pages:              [count]
Visuals:            [total count across all pages]
Measures:           [count]
Tables:             [count]

---

## 2. Page visual inventory
[Output 1 content here]

---

## 3. Data model diagram
[Output 2 Mermaid diagram here]

---

## 4. Relationship summary
[Output 2 relationship table here]

---

## 5. Table inventory
[Output 4 content here]

---

## 6. Measure catalogue
[Output 3 content here]

---

## 7. Compliance summary
[Combined compliance notes from all outputs]

---

## 8. Issues and recommendations
[Consolidated list of all flagged issues from all sections]
[Prioritised: Critical → Warning → Suggestion]

Critical (must fix before publishing):
  [ ] [list critical issues]

Warnings (should fix):
  [ ] [list warnings]

Suggestions (nice to have):
  [ ] [list suggestions]
```

Save the output as:
  [ReportName]_Documentation_[YYYY-MM-DD].md

Tell the user:
  "Documentation complete. I have saved it as
   [filename]. Please review the Issues and
   Recommendations section — I have flagged
   [X] items that need attention before publishing."

---

## Agent rules for this skill

- NEVER modify any report or model file while generating documentation
  This skill is read-only — documentation only, no changes
- Always flag missing titles, descriptions, format strings, and display folders
- Always flag many-to-many relationships — these are almost always a concern
- Always flag isolated tables with no relationships
- Always flag visuals with dummy data still bound (no real fields)
- Produce documentation even if there are issues — document what exists,
  flag what needs fixing, do not refuse to document an imperfect report
- If a page has no visuals, note it as an empty page
- If a measure has no DAX (blank) — flag as critical issue

---

## Quick documentation commands

Users can request specific outputs with these short commands:

  "Document the visuals"         → Output 1 only (visual inventory)
  "Generate a model diagram"     → Output 2 only (ERD + relationships)
  "Catalogue the measures"       → Output 3 only (measure catalogue)
  "List the tables"              → Output 4 only (table inventory)
  "Full documentation"           → All outputs assembled into one file
  "Compliance check"             → Compliance summaries from all outputs
                                   without the full detail

---

*Last updated: 2026-05-30*
*Owner: Adam McLean - COE Data Governance & Visualisation*
*Review cycle: [ANNUALLY or when report standards change]*

---

## Output 5 — SQL and partition queries

Read all partition definitions from TMDL files.
For each partition extract and document:

```
SQL AND PARTITION DOCUMENTATION
================================

Table: [table name]
Partition: [partition name]
Mode: [Import / DirectQuery / Incremental]

Source system:    [inferred from connection string]
Source table:     [table name at source]

SQL / M query:
  [full query reproduced here]

Filter logic:
  [plain English explanation of what the query filters and why]

Incremental refresh:
  Enabled:          [Yes / No]
  Refresh window:   [X days/months if applicable]
  Historical store: [X years/months if applicable]
  RangeStart param: [confirmed present / missing]
  RangeEnd param:   [confirmed present / missing]

Known limitations:
  [any known issues, data gaps, or caveats]
```

Repeat for every partitioned table.
Flag any tables where:
  SQL contains SELECT * — should specify columns explicitly
  No date filter exists on a large table — incremental refresh candidate
  Query folding cannot be confirmed

---

## Output 6 — Measure logic documentation

For every measure, produce plain English documentation
in addition to the DAX expression in the catalogue.

```
MEASURE LOGIC DOCUMENTATION
============================

Measure: [measure name]
Display folder: [folder]
Format string: [format]

What it calculates:
  [Plain English — what business question does this measure answer?]

Business rules applied:
  [Any specific rules, exclusions, or conditions]
  e.g. "Excludes returns marked as fraudulent"
  e.g. "Uses invoice date not payment date"
  e.g. "Rounds to nearest whole number for presentation"

Dependencies:
  Measures referenced:  [list any measures this calls]
  Tables used:          [list tables involved]
  Filters applied:      [any CALCULATE modifiers explained]

Edge cases:
  [How does this measure behave with no data?]
  [How does it handle nulls?]
  [Any known unexpected behaviours?]

DAX expression:
  [measure name] =
  [full DAX, indented]

Compliance:
  Description:     [present / MISSING]
  Format string:   [present / MISSING]
  Display folder:  [present / MISSING]
```

Flag any measure where:
  The logic is more than 3 VAR steps — may need simplification
  It references more than 2 levels of other measures — document chain
  It uses CALCULATE with complex modifiers — explain the context change

---

## Output 7 — Derived fields documentation

For every calculated column (dimension tables only —
calculated columns on fact tables are banned):

```
DERIVED FIELDS DOCUMENTATION
==============================

Table: [table name]
Column: [column name]
Data type: [type]

Source column(s):   [what columns it derives from]
Format applied:     [format string if any]

Transformation logic:
  [Plain English — what does this column calculate?]

DAX expression:
  [column name] =
  [full DAX]

Why not a measure:
  [Explanation of why this is a calculated column
   rather than a measure or Power Query step]

Why not Power Query:
  [If applicable — why this wasn't done upstream]
```

Flag any derived field that:
  Could be done as a measure instead — recommend conversion
  Could be done in Power Query — recommend moving upstream
  Exists on a fact table — flag as critical violation

---

## Output 8 — Format strings documentation

Document all non-default format strings across all measures:

```
FORMAT STRING REFERENCE
========================

Measure                    Format string           Example output
─────────────────────────────────────────────────────────────────
Total Revenue              £#,##0                  £1,234,567
Margin %                   0.0%                    42.3%
# Orders                   #,##0                   12,456
Sales YTD                  £#,##0.00               £1,234,567.89
[continue for all]

Non-standard formats used:
  [List any custom format strings with explanation of why]

Missing format strings:
  ⚠ The following measures have no format string:
  [list]
```

---

## Updated quick commands

```
"Document the visuals"         → Output 1 (visual inventory)
"Generate a model diagram"     → Output 2 (ERD + relationships)
"Catalogue the measures"       → Output 3 (measure catalogue)
"List the tables"              → Output 4 (table inventory)
"Document the SQL"             → Output 5 (SQL + partitions)
"Document measure logic"       → Output 6 (plain English logic)
"Document derived fields"      → Output 7 (calculated columns)
"Document format strings"      → Output 8 (format reference)
"Full documentation"           → All outputs in one file
"Compliance check"             → Compliance summaries only
```



---

*AgentAdam is built on the [data-goblin/power-bi-agentic-development](https://github.com/data-goblin/power-bi-agentic-development) toolkit by Kurt Buhler. AgentAdam adds SP Customer Business-specific standards and governance on top of his work.*
