# AgentAdam — Page wireframe template

> **Status:** TEST  
> **Owner:** Adam McLean - COE Data Governance & Visualisation  
> **Last updated:** 2026-05-30  
> **Review cycle:** Fortnightly  
>  
> **Do not alter this file.** This is a governed standards document.  
> If you think a rule needs changing, raise it with Adam McLean directly.  
> Local changes will be overwritten on next `git pull`.


Complete this before your agent session.
The agent reads this file to understand your intended layout
before placing any visuals on the page.

You do not need to be precise — rough descriptions are fine.
The agent will use this as a guide and flag any conflicts
with zone rules or template standards before building.

Copy this template for each page you are planning.
Delete this instruction block before sharing with the agent.

---

## Report details

Report name:      [name]
Page name:        [what this page will be called]
Developer page:   [which blank page you are working on e.g. Page 3]
Audience:         Executive / Operational / Mixed
Story this page tells: [one sentence — what question does this answer?]

---

## Zone A — Top bar

Report title:     [the report name shown top left]
Page title:       [the main heading for this page]
Page subtitle:    [supporting context — optional, leave blank if not needed]

Critical slicers (3–5 maximum, high impact filters only):
  Slicer 1:       [field name e.g. Date]
  Slicer 2:       [field name e.g. Region]
  Slicer 3:       [field name e.g. Account]
  Slicer 4:       [optional]
  Slicer 5:       [optional]

---

## Zone C — Visual canvas

Describe your layout row by row.
Use rough proportions — full width, half, third etc.
The agent handles exact sizing, spacing, and positioning.

```
┌──────────────────────────────────────────────────────┐
│ ZONE A — Top bar (agent manages — do not edit)        │
│ Title  │  Page title / subtitle  │  Slicers  │  ▼   │
└──────────────────────────────────────────────────────┘
│                                                       │
│  ROW 1:                                               │
│  [describe what goes here]                            │
│                                                       │
├─────────────────────────┬─────────────────────────────┤
│  ROW 2 LEFT:            │  ROW 2 RIGHT:               │
│  [describe]             │  [describe]                 │
│                         │                             │
├─────────────────────────┴─────────────────────────────┤
│  ROW 3:                                               │
│  [describe]                                           │
│                                                       │
└──────────────────────────────────────────────────────┘
                                     │
                           ┌─────────┴──────────┐
                           │  ZONE B — Filter    │
                           │  panel — activated  │
                           │  by More Filters ▼  │
                           │  Agent manages this │
                           └────────────────────┘
```

---

## Row by row description

Fill in as many rows as needed. Delete rows you do not use.

### Row 1
Layout:     Full width / Two columns / Three columns / Four columns
Content:    [describe each visual e.g. KPI card — Total Revenue]
Notes:      [anything specific e.g. show vs target, conditional colour]

### Row 2
Layout:     Full width / Two columns / Three columns / Four columns
Content:    [describe each visual]
Notes:      [anything specific]

### Row 3
Layout:     Full width / Two columns / Three columns / Four columns
Content:    [describe each visual]
Notes:      [anything specific]

### Row 4
Layout:     Full width / Two columns / Three columns / Four columns
Content:    [describe each visual]
Notes:      [anything specific]

### Row 5
Layout:     Full width / Two columns / Three columns / Four columns
Content:    [describe each visual]
Notes:      [anything specific]

---

## Additional notes for the agent

Measures available:       [list key measures the agent can use]
Colour highlighting:      [specific conditional formatting needed]
Cross-filter behaviour:   [any visuals that should not cross-filter]
Story emphasis:           [which visual is most important on this page]
Anything else:            [any other instructions]

---

## Example — completed wireframe

Report name:      Sales Performance 2026
Page name:        Revenue Overview
Developer page:   Page 1
Audience:         Mixed
Story:            How is revenue tracking vs target and where are the gaps?

Zone A:
  Report title:   Sales Performance 2026
  Page title:     Revenue Overview
  Page subtitle:  Year to date performance vs target
  Slicers:        Date, Region, Account Manager

Zone C layout:

  Row 1 — Three columns
    Left:    KPI card — Total Revenue YTD
    Centre:  KPI card — Revenue vs Target %
    Right:   KPI card — # Active Accounts
    Notes:   Show positive/negative conditional colour on vs target card

  Row 2 — Two columns
    Left (60%):  Line chart — Monthly revenue vs target over time
    Right (40%): Donut chart — Revenue split by region
    Notes:       Line chart is the hero visual on this page

  Row 3 — Full width
    Matrix table — Revenue by account manager and region
    Notes:        Conditional formatting on variance column

Measures available:
  Total Revenue, Revenue YTD, Revenue vs Target,
  Revenue vs Target %, # Active Accounts

Story emphasis: The line chart in Row 2 tells the trend story

---

*Template version: 1.0*
*Owner: Adam McLean - COE Data Governance & Visualisation*


---

*AgentAdam is built on the [data-goblin/power-bi-agentic-development](https://github.com/data-goblin/power-bi-agentic-development) toolkit by Kurt Buhler. AgentAdam adds SP Customer Business-specific standards and governance on top of his work.*
