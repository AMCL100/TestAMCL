# AgentAdam — Theme standards

> **Status:** TEST  
> **Owner:** Adam McLean - COE Data Governance & Visualisation  
> **Last updated:** 2026-05-30  
> **Review cycle:** Fortnightly  
>  
> **Do not alter this file.** This is a governed standards document.  
> If you think a rule needs changing, raise it with Adam McLean directly.  
> Local changes will be overwritten on next `git pull`.


Extracted from: AgentAdam/themes/PBITheme.json
Theme name: SP UK Ops Reporting

This file is the authoritative reference for all colour, font, and
styling decisions. The agent reads this file to understand the visual
language of every AgentAdam report.

The agent must NEVER modify PBITheme.json.
The agent must NEVER apply a different theme.
All values below come directly from the theme JSON.

---

## Font

Primary font:  IberPangea, IberPangea Text
Fallback font: Arial

All text elements across all visuals use IberPangea.
The agent must never change the font family on any element.

---

## Text classes

These are the theme-defined text styles. They map to visual elements
as described below. Font sizes are in points (pt).

| Class | Size | Colour | Usage |
|---|---|---|---|
| title | 18pt | #000000 | Visual titles |
| label | 14pt | #000000 | Axis labels, data labels, legend text |
| header | 10pt | #000000 | Visual header icons and controls |
| callout | inherited | #000000 | Card callout values |

Note: Card value (60px bold) and page-level typography (32px page title,
16px subtitle) are defined in the SVG background — not in this theme JSON.
See TEMPLATE_STANDARDS.md for those values.

---

## Sentiment colours

Used for conditional formatting, KPIs, and performance indicators.

| Purpose | Hex | Usage |
|---|---|---|
| Good / positive | #008C39 | Above target, positive variance |
| Bad / negative | #DB1D1D | Below target, negative variance |
| Neutral | #E3850D | On target, no change, caution |
| Maximum | #0792E5 | Maximum value indicators |
| Foreground | #3A3537 | General text, legend text |

Note: Card visual conditional formatting uses slightly different values
extracted from the PBIR files:
  Positive (> 0):    #02892E
  Negative (< 0):    #9B0000
  Between -1 and 0:  #9B0000

The theme JSON values (#008C39 / #DB1D1D) apply to general visual
conditional formatting. The PBIR card values apply specifically to
card visual value conditional formatting.

---

## Page background

Colour:       #E6E6E6
Transparency: 35%

Note: The SVG background image sits on top of this. The page background
colour is only visible in areas not covered by the SVG. Do not modify.

---

## Data colour palette

32 colours in sequence. Power BI cycles through these for chart series.
The agent should reference these when advising on colour usage or
checking that visuals align with the theme palette.

| Position | Hex | Description |
|---|---|---|
| 1 | #02892E | Primary green — brand colour, first series |
| 2 | #017CBE | Primary blue — second series |
| 3 | #AF6400 | Amber/brown — third series |
| 4 | #00402A | Dark green — fourth series |
| 5 | #084F6A | Dark blue — fifth series |
| 6 | #757029 | Olive — sixth series |
| 7 | #2F6852 | Teal green — seventh series |
| 8 | #625F5D | Dark grey — eighth series |
| 9 | #3599B8 | Mid blue |
| 10 | #DFBFBF | Pale pink |
| 11 | #4AC5BB | Turquoise |
| 12 | #5F6B6D | Slate grey |
| 13 | #FB8281 | Salmon |
| 14 | #F4D25A | Yellow |
| 15 | #7F898A | Mid grey |
| 16 | #A4DDEE | Light blue |
| 17 | #FDAB89 | Peach |
| 18 | #B687AC | Mauve |
| 19 | #28738A | Teal |
| 20 | #A78F8F | Dusty rose |
| 21 | #168980 | Dark teal |
| 22 | #293537 | Near black |
| 23 | #BB4A4A | Dark red |
| 24 | #B59525 | Gold |
| 25 | #475052 | Dark slate |
| 26 | #6A9FB0 | Steel blue |
| 27 | #BD7150 | Terracotta |
| 28 | #7B4F71 | Purple |
| 29 | #1B4D5C | Navy teal |
| 30 | #706060 | Warm grey |
| 31 | #0F5C55 | Forest green |
| 32 | #1C2325 | Charcoal |

Primary brand colours for single-series charts and KPIs:
  Green:  #02892E (position 1)
  Blue:   #017CBE (position 2)

---

## Visual styling defaults

These apply globally to all visuals via the theme JSON.

| Element | Value |
|---|---|
| Visual header foreground | #000000 |
| Tooltip title colour | #000000 |
| Tooltip value colour | #000000 |
| Tooltip action colour | #000000 |
| Outspace pane foreground | #000000 |

---

## Complete formatting reference

Combined from theme JSON and PBIR file extraction.
This is the full formatting standard for every visual type.

### All visuals

```
Font family:        IberPangea, IberPangea Text (fallback: Arial)
Border colour:      #CCCCCC
Border width:       1px
Border radius:      5px rounded corners
Padding:            10px all sides
Background:         white / transparent
Responsive:         false
Visual header:      visible (hidden on card visuals only)
```

### Card visuals (cardVisual — new card)

```
Value font:         60px  Bold  centre aligned
Value colour:       #000000 (conditional — see sentiment colours)
Label font:         18px  regular  centre aligned
Label colour:       #000000
Reference label:    18px  regular / bold
Conditional positive: #02892E
Conditional negative: #9B0000
Border:             #CCCCCC  1px  5px radius
Visual header:      hidden
Divider:            shown
```

### All other visuals

```
Title font:         16px  Bold  left aligned  #000000
Subtitle font:      14px  regular  left aligned  #000000
Axis labels:        14px  regular  #000000
Axis titles:        off by default (on for scatter/combo only)
Data labels:        14px  regular  #000000  OutsideEnd
                    on if visual not too crowded
                    off if gridlines are on
Gridlines:          on when data labels are off
Legend:             Top Left  title off  14px  #3A3537
```

### More Filters button

```
Text:               'More filters'  14px  #ffffff  centre
Fill:               #02892E  hover: #333333
Icon:               funnel SVG  right placement  35px
Border radius:      5px
```

---

## Agent rules

- NEVER modify PBITheme.json under any circumstances
- NEVER apply a different theme to any report
- ALWAYS use IberPangea as the font family
- ALWAYS use the sentiment colours above for conditional formatting
- ALWAYS use the data colour palette — never introduce custom colours
  outside this palette without explicit user instruction
- When creating new visuals not in the vocabulary, apply all formatting
  values from the complete formatting reference above
- When advising on colour choices, reference the palette by position
  e.g. "I'll use position 1 (#02892E) for the primary series"

---

*Last updated: 2026-05-30*
*Owner: Adam McLean - COE Data Governance & Visualisation*
*Review cycle: Fortnightly*


---

*AgentAdam is built on the [data-goblin/power-bi-agentic-development](https://github.com/data-goblin/power-bi-agentic-development) toolkit by Kurt Buhler. AgentAdam adds SP Customer Business-specific standards and governance on top of his work.*
