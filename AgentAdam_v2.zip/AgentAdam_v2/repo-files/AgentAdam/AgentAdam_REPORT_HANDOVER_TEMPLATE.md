# Report handover document

> **Status:** TEST  
> **Owner:** Adam McLean - COE Data Governance & Visualisation  
> **Last updated:** 2026-05-30  
> **Review cycle:** Fortnightly  
>  
> **Do not alter this file.** This is a governed standards document.  
> If you think a rule needs changing, raise it with Adam McLean directly.  
> Local changes will be overwritten on next `git pull`.


Complete this document when publishing a new report or handing
over an existing one. The agent can help draft sections 1-4.
Sections 5-7 must be completed and signed off by a human.

The agent generates this template pre-filled where possible
using the DOCUMENTATION_SKILL.md outputs. The developer
reviews, corrects, and completes the human sections.

---

## Report details

Report name:         [name]
Template used:       Simple / Interactive
Report type:         Type A / B / C
Canvas size:         1706 x 720 / 2560 x 1080
File location:       [path or workspace app URL]
Date published:      [date]
Version:             [1.0]

---

## 1. Purpose and audience

### What business question does this report answer?
[One or two sentences. Be specific — not "sales performance" but
"weekly revenue tracking for the Northern region sales team,
comparing actuals against target with YTD and prior year context"]

### Who is the primary audience?
[Job titles or teams, not individual names]

### How often is it used and when?
[Daily / weekly / monthly — and when in the working week/month]

---

## 2. Data sources

### Source systems
[List every data source this report connects to]

  Source 1:   [system name]
  Tables used: [list]
  Refresh:    [frequency and time]

  Source 2:   [system name]
  Tables used: [list]
  Refresh:    [frequency and time]

### Data freshness
Most recent data available as of: [time lag — e.g. "end of previous day"]
Refresh schedule:                 [e.g. "Daily at 06:00"]
Refresh method:                   [scheduled / manual / incremental]

---

## 3. Report structure

### Pages
[Agent generates this from the visual inventory]

  Page 1: [name] — [one line description]
  Page 2: [name] — [one line description]
  [continue for all pages]

### Key measures
[Agent generates this from the measure catalogue — developer confirms]

  [Measure name] — [what it calculates in plain English]
  [Measure name] — [what it calculates in plain English]
  [list the most important measures — not all of them]

### Filters available
  Primary filters (always visible):
    [list Zone B filters]

  Date filter (header):
    [date range slicer description]

  Secondary filters (collapsible — if present):
    [list if applicable]

---

## 4. Known limitations and caveats

### Data limitations
[Anything the user needs to know about the data — gaps, exclusions,
known quality issues, fields that are sometimes null, etc]

  [Example: "Returns data is only available from January 2024 onwards"]
  [Example: "Customer region is based on billing address, not delivery address"]

### Report limitations
[Anything the user needs to know about the report itself]

  [Example: "The matrix table cannot exceed 10,000 rows — apply filters first"]
  [Example: "Cross-filtering between the map and bar chart is intentionally disabled"]

### Measures to interpret carefully
[Any measures that might be misread without context]

  [Example: "Margin % excludes freight costs — see Adjusted Margin % for full picture"]

---

## 5. Ownership and support

Report owner:        [name and team]
Technical owner:     [BI developer name]
Business owner:      [stakeholder name and team]

For data questions contact:   [name / team / email]
For report issues contact:    [name / team / email]
For access requests contact:  [name / team / process]

---

## 6. Change log

| Version | Date | Changed by | What changed |
|---|---|---|---|
| 1.0 | [date] | [name] | Initial release |
| | | | |

---

## 7. Sign-off

### Developer sign-off
I confirm this report has been built to AgentAdam standards,
tested against real data, and is ready for publication.

Name:        [developer name]
Date:        [date]
Signature:   [name or initials]

### Business owner sign-off
I confirm this report meets the business requirements,
the data has been validated, and I approve publication.

Name:        [business owner name]
Date:        [date]
Signature:   [name or initials]

---

## Agent instructions for this template

When a user asks the agent to "create a handover document" or
"prepare this report for handover":

1. Run the full documentation skill (DOCUMENTATION_SKILL.md)
2. Use the outputs to pre-fill:
     Section 3 — pages from visual inventory
     Section 3 — key measures from measure catalogue
     Section 3 — filters from visual inventory
3. Leave sections 1, 2, 4, 5, 6, 7 with placeholder prompts —
   these require human knowledge the agent does not have
4. Save as: [ReportName]_Handover_[YYYY-MM-DD].md
5. Tell the user:
     "I have pre-filled everything I can from the report files.
      Please complete sections 1, 2, 4, 5, 6, and 7 — these
      need your knowledge of the business context, data sources,
      and sign-off details. Section 7 must be signed by both
      the developer and business owner before publishing."

---

*Template version: 1.0*
*Owner: Adam McLean - COE Data Governance & Visualisation*
*Review cycle: [ANNUALLY]*


---

*AgentAdam is built on the [data-goblin/power-bi-agentic-development](https://github.com/data-goblin/power-bi-agentic-development) toolkit by Kurt Buhler. AgentAdam adds SP Customer Business-specific standards and governance on top of his work.*
