# AgentAdam — Template standards

> **Status:** TEST  
> **Owner:** Adam McLean - COE Data Governance & Visualisation  
> **Last updated:** 2026-05-30  
> **Review cycle:** Fortnightly  
>  
> **Do not alter this file.** This is a governed standards document.  
> If you think a rule needs changing, raise it with Adam McLean directly.  
> Local changes will be overwritten on next `git pull`.


---

## Definitions

The following terms are used throughout this file.
The agent must understand these before starting any work.

**Zone A** — The top bar area defined by the SVG background image. Contains
the report title, page title, page subtitle, critical slicers, and the
More Filters button. The agent never places report visuals here.

**Zone B** — The filter panel area. Hidden by default. Revealed when the
user clicks the More Filters button. Contains additional non-critical
slicers, a Reset button, and a Close button. Always the highest z-order
element on the page when visible.

**Zone C** — The visual canvas. The only area where the agent places,
resizes, and arranges report visuals. Bounded by the SVG background.

**Filter Panel** — The named group in the Selection pane on every developer
page (Pages 1–15). Always named exactly 'Filter Panel'. Contains the
filter panel shape, slicers, Reset button, and Close button. Always the
highest z-order element.

**Developer pages** — Pages 1–15. Pre-configured blank pages with SVG
background, Filter Panel group, and scoped bookmark pair. Hidden in
view mode. Renamed and selectively unhidden on publish.

**Visual vocabulary** — Seven hidden pages containing pre-formatted visuals
with dummy data. Never unhidden. Agent copies formatting from these.

**DummyData** — The calculated table powering visual vocabulary visuals.
Must never appear in a published report.

**3/30/300 rule** — Design principle: the top of the page gives the
overview (3 second read), the middle gives trend and context (30 second
read), the bottom gives detail (300 second read). Z or F reading pattern.
Overridden by any wireframe or plan provided by the user.

**IberPangea** — The AgentAdam brand font. Used for all text
throughout the report. Fallback: Arial.

**ThemeDataColor** — Colour references in the PBIR files that map to the
theme colour palette. ColorId 0 = primary background/white.
ColorId 1 = primary text/black. ColorId 5 = brand primary colour.

---

## Template location

AgentAdam/templates/PBI_Corporate_Template.pbip

Developers copy this file — never work in the original.
The original must always remain clean and unchanged.

---

## Canvas

Size:         2560 x 1080 (single canvas size — no variants)
Display mode: FitToPage
Deployment:   AgentAdam Power BI workspace apps

NEVER change the canvas size.
NEVER add navigation elements — workspace app handles navigation.
NEVER reserve space for Power BI service chrome.

---

## Background

The background is an SVG image embedded in the template as a
registered resource. It defines all zone boundaries visually.

NEVER attempt to recreate or modify the SVG background.
NEVER add a separate background image — the SVG is the background.
The SVG is part of the template structure — it cannot be applied
separately like a theme.

---

## Zone coordinates

All coordinates are in pixels on the 2560 x 1080 canvas.
Format: y-start to y-end on length / x-start to x-end on width.

### Zone A — Top bar (SVG defined)

```
Overall top bar:
  y:  8  → 128    (height: 120px)
  x:  15 → 2546   (width:  2531px)

Report title (textbox):
  y:  11 → 36     x:  21  → 343

Page title (textbox):
  y:  20 → 92     x:  383 → 1090

Page subtitle (textbox):
  y:  84 → 135    x:  383 → 1090
  Note: slight overlap with Zone A bottom — acceptable,
  overlap is empty textbox space not actual text

Critical slicers zone:
  y:  16 → 110    x:  1106 → 2350    (zone width: 751px)
  Maximum 4 slicers on the top bar. Critical and high-impact only.
  e.g. Account Determination, Date, key dimensions

More Filters button:
  y:  63 → 103    x:  2351 → 2504
  Fill:   #02892E (green)  Hover: #333333
  Text:   'More filters'  14px  IberPangea  white  centre
  Icon:   funnel SVG  right placement  35px
  Shape:  5px rounded corners
  Links to: [page number] Filter Show bookmark
  NEVER move or resize this button (position is fixed)
  Visibility is conditional — see button visibility rule below
```

### Slicer width and placement — IMPORTANT

The agent MUST size and place top bar slicers so they never spill
left out of the critical slicers zone into the page title and
subtitle area (which sit at x:383 → 1090).

**Divide the critical slicers zone equally among the slicers present.**

```
Zone available:  x:1106 → 2350  =  751px total
Gap between slicers: 10px

Width per slicer = (1244 - (10 × (n-1))) / n   where n = slicer count

  1 slicer  → 751px  (or sized sensibly, anchored right)
  2 slicers → 370px each
  3 slicers → 243px each
  4 slicers → 180px each

Slicers are laid out left to right starting at x:1106.
No slicer may begin before x:1106 or extend beyond x:2350.
```

### Slicer overflow rule

```
Total slicers on page ≤ 4
  → ALL slicers go on the top bar (critical slicers zone)
  → divided equally per the widths above
  → filter pane is empty
  → More Filters button is HIDDEN (see below)

Total slicers on page ≥ 5
  → first 4 go on the top bar
  → 5th and every subsequent slicer go in the filter pane (Zone B)
  → More Filters button is VISIBLE
```

Always fill the top bar FIRST. Never place a slicer in the filter
pane while there is still room on the top bar (fewer than 4 there).

### More Filters button visibility rule

```
IF the filter pane (Zone B) contains 0 slicers
  → set the More Filters button to visible: false
  → NEVER delete the button — only hide it
  → it must remain in the PBIR file so it reappears
    automatically if a 5th slicer is later added

IF the filter pane contains 1 or more slicers
  → set the More Filters button to visible: true
```

This prevents a dead button appearing when there are no additional
filters to show. The button is hidden, never removed.

Agent rules for Zone A:
- NEVER place report visuals in Zone A
- NEVER move or resize the report title, page title,
  page subtitle, or More Filters button
- NEVER add slicers outside the critical slicers zone
- NEVER let a slicer extend left of x:1106 into the title area
- Agent may update title and subtitle text content only
- Maximum 4 slicers on the top bar — 5th onwards goes to filter pane
- Divide the slicer zone width equally among the slicers present
- Hide (never delete) the More Filters button when the pane is empty

### Zone B — Filter panel (pop-up)

```
Position when active:
  y:  129 → 1066   (height: 937px)
  x:  2020 → 2546  (width:  526px)
  z-order: ALWAYS highest on page (z:17000 or above)

Contents:
  Filter panel title: 'Additional Filters'
  Reset button:       text 'Reset' + reset icon
  Close button:       text 'Close ⛝'
  Additional slicers: non-critical filters
```

Agent rules for Zone B:
- NEVER place report visuals in Zone B
- NEVER move or resize the Filter Panel group
- NEVER move the Reset or Close buttons
- NEVER add slicers outside Zone B
- Only place slicers here once the top bar is full (4 slicers)
- The 5th slicer onwards on a page belongs here
- When this pane is empty, the More Filters button must be hidden
- New filters require explicit user approval before adding
- Filter Panel group must always be highest z-order on page

### Zone C — Visual canvas

```
Position:
  y:  136 → 1066   (height: 930px)
  x:  28  → 2535   (width:  2507px)

Minimum spacing between visuals: 10px
Preferred spacing: even distribution within Zone C
```

Agent rules for Zone C:
- All report visuals must stay within Zone C boundaries
- KPI cards and summary visuals always in the top portion
- Detail visuals (tables, matrices) towards the bottom
- Minimum 10px between all visuals — never less
- Even spacing preferred across the canvas
- Agent may freely resize and reposition visuals within Zone C

---

## Layer order — every developer page, every time

Correct order from bottom to top in Selection pane:

```
SVG Background / Page Background    (bottom — never move)
Report visuals                      (above background)
Filter Panel                        (ALWAYS top — never below any visual)
```

The Filter Panel group (named exactly 'Filter Panel') must always
be the highest z-order element on the page. If any action moves it
below a report visual, restore it to the top immediately.

When adding any new visual to a page, always confirm the
Filter Panel remains at the top of the layer order afterwards.

---

## Filter Panel — bookmark structure

Each developer page has exactly ONE bookmark group with TWO children.
Bookmark naming follows this exact pattern:

```
Page 1:   "1) Filter Show"  /  "1) Filter Hide"
Page 2:   "2) Filter Show"  /  "2) Filter Hide"
Page 3:   "3) Filter Show"  /  "3) Filter Hide"
...
Page 15:  "15) Filter Show" / "15) Filter Hide"
```

Bookmark scope:
  applyOnlyToTargetVisuals: true
  suppressData: true
  Captures: selected visuals only
  Does NOT capture: data state, page state, all visuals

The Filter Panel group on each page is named exactly:
  'Filter Panel'

Agent rules for bookmarks:
- NEVER add, remove, or rename any bookmark
- NEVER change bookmark scope or what they capture
- NEVER link a More Filters button to the wrong page bookmark
- After any structural change, remind user to test
  Filter Show and Filter Hide work correctly in Desktop

---

## If developer pages run out — page duplication

If all 15 developer pages are in use and a new page is needed,
the agent may duplicate an existing blank developer page.

Process — always confirm with user before starting:

  1. Identify the next page number (e.g. 16)
  2. Copy the page folder in the PBIR structure
  3. Assign a new unique page ID
  4. Read all new visual IDs generated on the duplicated page
  5. Create a new bookmark group named 'Page [N]' with two children:
       "[N]) Filter Show"
       "[N]) Filter Hide"
  6. Set both bookmarks to:
       applyOnlyToTargetVisuals: true
       suppressData: true
       Target visual IDs: the new Filter Panel group visual IDs
  7. Link the More Filters button on the new page to "[N]) Filter Show"
  8. Confirm Filter Panel group is highest z-order on new page
  9. Set page visibility to HiddenInViewMode

After duplication always remind the user:
  "Please open the .pbip in Desktop and test that the
   Filter Show and Filter Hide bookmarks work correctly
   on the new page before adding any visuals."

NEVER create a raw blank page without the SVG background.
NEVER attempt to manually recreate the SVG or filter panel structure.

---

## Typography

Font family:  IberPangea
Fallback:     Arial
All text elements use IberPangea throughout.
The agent must never change the font family on any element.

```
Zone A text (embedded in SVG — do not modify):
  Report title:     18px   #ffffff   regular
  Page title:       32px   #ffffff   bold
  Page subtitle:    16px   #ffffff   regular

Card visuals (cardVisual — new card):
  Value:            60px   ThemeDataColor 1   bold    centre
  Label:            18px   ThemeDataColor 1   regular centre
  Reference label title: 18px  ThemeDataColor 1
  Reference label value: 18px  ThemeDataColor 1  bold

All other visuals:
  Visual title:     16px   ThemeDataColor 1   bold    left
  Visual subtitle:  14px   ThemeDataColor 1   regular left
  Axis labels:      14px   ThemeDataColor 1
  Data labels:      14px   ThemeDataColor 1
  Legend text:      14px   #3A3735
  More Filters btn: 14px   #ffffff   centre
```

The agent must NEVER change font family, font sizes, or font colours.
These are fixed brand standards — only visual size and position may change.

---

## Colours

```
Positive (> 0):           #02892E   dark green
Negative (< 0):           #9B0000   dark red
Between -1 and 0:         #9B0000   dark red
Above 1:                  #02892E   dark green

More Filters button:      #02892E   hover: #333333
Visual borders:           #CCCCCC
Legend text:              #3A3735

ThemeDataColor references:
  ColorId 0:  Primary background / white
  ColorId 1:  Primary text / black
  ColorId 5:  Brand primary colour
```

Conditional formatting on card visuals uses these colours
via the Conditional expression in the PBIR files.
The agent must replicate this pattern exactly when creating
new card visuals with positive/negative indicators.

---

## Visual formatting standards

These apply to ALL visuals. Extracted from the PBIR files.
The agent must never deviate from these standards.

```
Border:
  Show:           true
  Colour:         #CCCCCC
  Width:          1px
  Radius:         5px rounded corners

Padding:
  Top:            10px
  Bottom:         10px
  Left:           10px
  Right:          10px

Background:
  Show:           true
  Transparency:   0%
  Colour:         ThemeDataColor 0 (white)

Visual header:
  Hidden on card visuals
  Default on all other visuals

Gridlines:
  Off when data labels are on
  On when data labels are off

Data labels:
  On by default if visual is not too crowded
  Position: OutsideEnd
  Font: 14px  IberPangea  ThemeDataColor 1
  Label density: 100%

Axis labels:
  Font: 14px  IberPangea  ThemeDataColor 1
  Display units: auto (0)

Axis titles:
  Off by default
  On only when necessary (scatter plots, combo charts)
  Explain axis in visual title where possible
  Remove axis titles that add no value

Legend:
  Position: Top Left
  Title: off
  Font: 14px  IberPangea  #3A3735

Responsive: false on all visuals

Spacing between subtitle and content: 10px
```

---

## Visual modification rules

### What the agent may freely change
  Overall visual size (width and height of container)
  Overall visual position within Zone C
  Data fields bound to the visual
  Visual title and subtitle text content
  Whether data labels are on or off (based on crowding)
  Whether gridlines are on or off (inverse of data labels)

### What the agent must NEVER change
  Font family (always IberPangea / Arial fallback)
  Font sizes (fixed per element type above)
  Font colours (fixed per element type above)
  Border colour, width, or radius
  Padding values
  Background colour or transparency
  Conditional formatting colour rules
  Rounded corner radius
  Legend position or title visibility
  Responsive setting (always false)
  Any formatting inherited from the template

---

## Visual vocabulary

Seven hidden pages containing pre-formatted visuals with dummy data.
These pages are ALWAYS hidden — in Desktop and in published reports.
NEVER unhide vocabulary pages.
NEVER modify, reformat, or delete visuals on vocabulary pages.

The agent copies formatting rules from these visuals.
Dimensions (width and height) may differ in the actual report —
only the formatting (borders, fonts, colours, padding, layout) carries over.

### Complete visual library

```
PAGE: Visuals: KPI, Card & Slicers
  New Card (cardVisual)         — with reference labels and comparison values
                                   positive/negative conditional formatting
  Classic Card                  — simple single metric card
  KPI visual                    — with target comparison
  Advanced Slicer               — style 1
  Advanced Slicer               — style 2
  Standard Slicer               — dropdown style

PAGE: Visuals: Ranking
  Clustered Bar Chart           — horizontal, ranked descending
  Clustered Column Chart        — vertical, ranked
  Matrix (pivotTable)           — expandable rows
  Table (tableEx)               — flat table

PAGE: Visuals: Change Over Time
  Line Chart                    — single series over time
  Clustered Column Chart        — grouped columns over time
  Area Chart                    — filled area over time
  Line & Clustered Column Combo — dual axis combo

PAGE: Visuals: Change Over Time II
  Stacked Column Chart          — part-to-whole over time
  Stacked Area Chart            — cumulative area over time
  100% Stacked Area Chart       — proportional area
  Line & Stacked Column Combo   — trend over stacked bars

PAGE: Visuals: Part-To-Whole
  Stacked Bar Chart             — horizontal part-to-whole
  100% Stacked Bar Chart        — horizontal proportional
  Stacked Column Chart          — vertical part-to-whole
  100% Stacked Column Chart     — vertical proportional
  Waterfall Chart               — running total with delta
  Doughnut Chart                — proportional with centre
  Pie Chart                     — proportional

PAGE: Visuals: Correlation
  Scatter Chart                 — with trend line
  Bubble Chart                  — scatter with size dimension
  Line Chart                    — trend/relationship
  Line & Column Combo           — correlation dual axis

PAGE: Visuals: Flow
  Waterfall Chart               — flow and delta
  Ribbon Chart                  — rank change over time
  Decomposition Tree            — hierarchical breakdown
```

Total: 30 pre-formatted visuals.

### How to use the visual vocabulary

  1. Identify the visual type needed
  2. Find it on the relevant vocabulary page
  3. Copy it (Ctrl+C in Desktop, or copy folder in PBIR)
  4. Paste into the working report page
  5. Replace dummy data with real fields
  6. Resize to fit the report layout (dimensions may change)
  7. Do not reformat — all styling is already correct

When a visual type is not in the vocabulary:
  Create it natively
  Apply all formatting standards from this file
  Match border, padding, font sizes, and colours exactly
  Flag to user that this visual needs a formatting review in Desktop

---

## Dummy data rules

The DummyData calculated table powers all vocabulary visuals.

NEVER delete DummyData while vocabulary visuals reference it.
NEVER modify DummyData columns bound to vocabulary visuals.

End of every session — always check:
  Are any report page visuals still bound to DummyData?
  If yes — flag to user before closing:
    "The following visuals are still using dummy data:
     [list them]. Please rebind to real data sources
     before publishing. Dummy data must never appear
     in a published report."

When developer rebinds all visuals to real sources:
  Remind them DummyData table can then be safely deleted.

---

## Design philosophy

The agent applies these principles to every report unless
a wireframe or plan provided by the user overrides them.
User-provided wireframes always take priority.

### 3/30/300 rule
Design reports so they can be read at three levels:
  3 seconds:   headline KPIs and key numbers at the top
               user understands the overall position immediately
  30 seconds:  trends and context in the middle
               user understands direction and performance
  300 seconds: detail and analysis at the bottom
               user can investigate and drill into specifics

### Z and F reading pattern
Arrange visuals so the eye naturally moves across and down.
Place the most important information top-left.
Place supporting detail bottom-right.
Use consistent alignment and even spacing to guide the eye.

### Hierarchy within Zone C
```
Top of Zone C:      KPI cards and headline numbers
Middle of Zone C:   Charts, trends, comparisons
Bottom of Zone C:   Tables, matrices, detail
```

### Design principles
  Function over form — clarity is always more important than aesthetics
  Tell a story — each page should answer a specific question
  Consistency — same visual treatment across all pages in the report
  Minimum 10px between all visuals — never crowd the canvas
  Even spacing preferred — distribute visuals evenly within Zone C
  Explain in titles — use visual titles to tell the user what they
    are seeing, not just label the data

### Audience-based adjustments
  Executive:    fewer visuals per page, larger KPIs, simpler charts,
                clear headlines, minimal detail
  Operational:  more detail per page, tables and matrices acceptable,
                performance-focused layout
  Mixed:        lead with 3-second summary, detail below the fold

---

## Publishing rules

When prompted to publish a report:

  1. Ask the user which workspace to publish to
  2. Default to user's own sandbox workspace if none specified
  3. Before publishing, always:

     Pages to hide:
       All visual vocabulary pages (always hidden)
       Guidance & Help page
       Template Summary page
       Report Information page (unless user wants it visible)
       Any developer pages (1–15) not developed on

     Pages to unhide:
       Only developer pages that have been worked on
       Example Page (if user wants it visible)

     Page naming:
       Rename all developed pages appropriately
       Remove the number prefix (e.g. '1' becomes 'Sales Overview')
       Confirm page names with user before publishing

  4. Confirm the publish plan with user before executing:
     "I am about to publish to [workspace].
      The following pages will be visible: [list]
      The following pages will be hidden: [list]
      Page names: [list]
      Shall I proceed?"

  5. Wait for explicit user confirmation before publishing

---

## Guidance pages — agent rules

The following pages are always locked — read-only reference:
  Guidance & Help
  Template Summary
  Report Information

NEVER modify, delete, or add content to these pages.
Treat as developer reference documentation only.

---

*Last updated: 2026-05-30*
*Owner: Adam McLean - COE Data Governance & Visualisation*
*Review cycle: Fortnightly*

---

## Fallback formatting — visuals not in vocabulary

When creating any visual not covered by the visual vocabulary,
apply these exact settings. These match the vocabulary standard
precisely — any report visual should be indistinguishable in
formatting from a vocabulary copy.

### Border
  Colour:       #CCCCCC
  Width:        1px
  Radius:       5px rounded corners
  Show:         true

### Padding
  All sides:    10px

### Background
  Colour:       white
  Transparency: 0%

### Typography
Font family: IberPangea, IberPangea Text (fallback: Arial)

  Title:        16px  Bold  #000000  left aligned
  Subtitle:     14px  regular  #000000  left aligned
  Axis labels:  14px  regular  #000000
  Axis titles:  off by default
                on only for scatter plots and combo charts
                explain axis in title where possible instead
  Data labels:  14px  regular  #000000  OutsideEnd
  Legend text:  14px  regular  #3A3537

### Data label and gridline rule
  Data labels ON  → gridlines OFF
  Data labels OFF → gridlines ON
  Never have both on or both off simultaneously

### Legend
  Position:     Top Left
  Title:        always off
  Font:         14px  #3A3537

### Visual header
  Visible on all visuals except card visuals
  Hidden on card visuals (cardVisual type)

### Responsive
  Always false — never enable responsive sizing

### Colour usage
  Use the theme data colour palette in sequence.
  Never introduce colours outside the palette
  without explicit user instruction.

  Single series:    #02892E  (position 1 — primary green)
  Two series:       #02892E  then  #017CBE
  Three or more:    follow palette order positions 1, 2, 3...

  Full palette in AgentAdamTheme_STANDARDS.md

### Conditional formatting colours
  Positive (> 0):   #02892E  dark green
  Negative (< 0):   #9B0000  dark red
  Neutral:          #E3850D  amber
  Between -1 and 0: #9B0000  dark red

### After creating any non-vocabulary visual

Always tell the user:
  "This visual type is not in the AgentAdam visual vocabulary.
   I have applied the standard fallback formatting settings
   but please review it in Desktop to confirm it looks
   consistent with the rest of the report.
   If this visual type will be used regularly, consider
   adding it to the vocabulary pages in the template."


---

## Layer order — agent must always verify

The Filter Panel must always be the highest z-order element
on every modified page. The agent verifies this by reading
the visual.json files after every change.

Always check on every modified page:
  Read all visual.json files on the page
  Identify the Filter Panel group by its 'Filter Panel' name
  Confirm it has the highest z-order value
  If not — restore it to the top before finishing

Limitations the agent must declare:
  Cannot detect changes a developer made manually in Desktop
  Between sessions, if a developer reordered visuals in
  the Selection pane, the agent only sees the result
  in the PBIR file — it has no history

Always remind the developer at the end of any session:
  "Please verify in Desktop that the Filter Panel still
   appears on top of all visuals when activated. The View →
   Selection pane is the easiest way to check this."

---

## How the agent uses the visual vocabulary pages

The visual vocabulary pages are hidden in the published report
and hidden from end users in Desktop view mode.
However their visual.json files are fully readable by the agent
in the .pbip folder structure.

The agent uses them in two ways:

### 1. As a formatting reference

When the agent creates or places a visual on a developer page,
it reads the corresponding visual.json from the vocabulary page
to extract the exact formatting settings:
  Border colour, width, and radius
  Padding values
  Font family, size, and colour per element
  Legend position and title setting
  Data label settings
  Background colour and transparency
  Any other formatting properties

It then applies those same settings to the new visual.
This ensures every visual the agent creates matches the
vocabulary standard exactly — even if the developer never
manually copies from the vocabulary pages.

### 2. As a copy source (preferred approach)

The preferred approach is for the developer to copy a visual
directly from the vocabulary page in Desktop, paste it onto
their working page, then ask the agent to bind real data to it.

When this happens the agent simply:
  Reads the copied visual to confirm it is correctly formatted
  Binds the developer's real data fields to it
  Resizes if needed within Zone C
  Leaves all formatting untouched

### What the agent never does with vocabulary pages

  Never modifies any visual on a vocabulary page
  Never moves or resizes any element on a vocabulary page
  Never deletes any visual from a vocabulary page
  Never unhides vocabulary pages
  Never adds new visuals to vocabulary pages

Vocabulary pages are read-only reference material.
Any changes to the vocabulary must be made manually in
Desktop by the template owner and committed to the repo.

### When a visual type is not in the vocabulary

If the developer needs a visual type that does not exist
in the vocabulary, the agent:
  Creates it natively in Power BI
  Applies all formatting values from AgentAdamTheme_STANDARDS.md
  These values are the same as those used in the vocabulary visuals
  Tells the developer: "This visual type is not in the AgentAdam
  vocabulary. I have applied the standard formatting but please
  review it in Desktop to confirm it looks consistent with the
  rest of the report. If this visual gets used regularly,
  consider adding it to the vocabulary pages in the template."



---

*AgentAdam is built on the [data-goblin/power-bi-agentic-development](https://github.com/data-goblin/power-bi-agentic-development) toolkit by Kurt Buhler. AgentAdam adds SP Customer Business-specific standards and governance on top of his work.*
