# Attribution

> **Status:** TEST  
> **Owner:** Adam McLean - COE Data Governance & Visualisation  
> **Last updated:** 2026-05-30  
> **Review cycle:** Fortnightly


The core Power BI agentic development toolkit used in this repository
was created by Kurt Buhler (Data Goblins) and is available at:

  https://github.com/data-goblin/power-bi-agentic-development

The skills, hooks, agents, and plugins are Kurt's work and are used
here under the community use terms of that project.

If you share or build on this toolkit further, you must maintain
this attribution and include a link to the original project.
This is a requirement of the licence terms, not optional.

---

AgentAdam specific files are our own work built on top
of Kurt's foundation:

  AgentAdam/AgentAdam.md
  AgentAdam/DAX_STANDARDS.md
  AgentAdam/SEMANTIC_MODEL_SKILL.md
  AgentAdam/INCREMENTAL_REFRESH_SKILL.md
  AgentAdam/DOCUMENTATION_SKILL.md
  AgentAdam/REPORT_HANDOVER_TEMPLATE.md
  AgentAdam/themes/AgentAdamTheme_STANDARDS.md
  AgentAdam/templates/TEMPLATE_STANDARDS.md

These files cover AgentAdam specific governance and standards.
They do not reproduce or rewrite Kurt's skill files.

---

If this toolkit has saved your team time, consider:
  Starring Kurt's repo on GitHub
  Mentioning it in internal presentations or documentation
  Sharing it with the Power BI community

Kurt is doing valuable open source work. Recognition matters.

  https://github.com/data-goblin/power-bi-agentic-development
  https://data-goblins.com

---

Owner: Adam McLean - COE Data Governance & Visualisation
Review cycle: Fortnightly
