# AgentAdam — Complete rules summary

> **Status:** TEST  
> **Owner:** Adam McLean - COE Data Governance & Visualisation  
> **Last updated:** 2026-05-30  
> **Review cycle:** Fortnightly  
>  
> **Do not alter this file.** This is a governed standards document.  
> If you think a rule needs changing, raise it with Adam McLean directly.  
> Local changes will be overwritten on next `git pull`.


Reference document for humans. Not read by the agent directly.
For agent instructions see AgentAdam.md and individual skill files.

---

## 1. Session modes

Full session (new reports or new pages):
  Start: "New report session — [file path]"
  Agent runs 3-exchange checklist
  Use for: new reports, new pages, structural changes

Quick session (edits, DAX, documentation):
  Start: "Quick session — [file path]
          Backup done, Desktop closed, audience is [type]"
  Agent: "Ready — what do you need?"
  End of session checklist still runs regardless

---

## 2. Mandatory checklist — 3 exchanges only

Exchange 1 — Safety:
  Agent auto-checks file format silently
  Asks: "Have you taken a backup and is Desktop closed?"
  If .pbix → stop, tell user to save as .pbip
  If no backup → explain how, do not proceed until confirmed

Exchange 2 — Context:
  Agent checks model measures silently
  Asks: "Audience — Executive, Operational, or Mixed?
  I can see these measures: [list]. Enough to start?"
  If base measures missing → stop, user creates first

Exchange 3 — Plan:
  Agent reads TEMPLATE_STANDARDS and theme standards silently
  Asks: "Plan, wireframe, or brief? Share anything or one liner."
  User provides input → build plan → confirm → build

3 questions. 3 answers. Building begins.

---

## 3. Plan and requirements interpretation

Any input valid: BRD, Copilot plan, wireframe, description,
one liner, or nothing at all.

Agent always:
  Extracts intent from whatever is provided
  Translates to compliant build plan
  Presents build plan before touching any file
  Waits for confirmation — never builds without it

One liner → ONE clarifying question → build plan → confirm
Too vague → ONE more question → assume and state in plan
Maximum 2 clarifying questions before assuming

Wireframe controls: visuals, layout, proportions, visual types
Wireframe never overrides: zones, formatting, theme, fonts,
  colours, borders, padding, bookmarks, layer order

Conflicts with hard rules → flag, suggest alternative, wait
Conflicts with preferences → flag, follow developer if confirmed

---

## 4. File format rules

NEVER read or edit .pbix files
ALWAYS work in .pbip with PBIR enabled
Working report can be named anything
Enable PBIR: Options → Preview features →
  Store reports using enhanced metadata format

---

## 5. Template and theme rules

One template: AgentAdam/templates/PBI_Corporate_Template.pbip
One theme:    AgentAdam/themes/PBITheme.json
Theme name:   SP UK Ops Reporting
SVG background embedded in theme

ALWAYS apply PBITheme.json — embedded, never apply separately
NEVER replace, overwrite, or modify PBITheme.json
NEVER apply any other theme
Developer always copies PBI_Corporate_Template.pbip — never edits original

---

## 6. Zone layout rules

Canvas: 2560 x 1080 only.

Zone A — Header (y:8-128, x:15-2546)
  Title, subtitle, critical slicers, More Filters button only
  NEVER add report visuals or additional elements

  Report title:     y:11-36,   x:21-343
  Page title:       y:20-92,   x:383-1583
  Page subtitle:    y:84-135,  x:383-1583
  Critical slicers: y:16-110,  x:1599-2350 (max 4, divided equally)
  More Filters btn: y:63-103,  x:2351-2504 (hidden when pane empty)

Zone B — Filter panel (y:129-1066, x:2020-2546)
  Filter slicers only, pop-up, hidden by default
  Always highest z-order. NEVER add report visuals here.

Zone C — Visual canvas (y:136-1066, x:28-2535)
  All report visuals. Min 10px spacing.
  Top: KPIs. Middle: charts. Bottom: tables. (3/30/300)

---

## 7. Layer order rules

Bottom to top — every page, every time:
  Page Background / SVG    (bottom — never move)
  Report visuals           (middle)
  Filter Panel             (ALWAYS top — named 'Filter Panel')

If Filter Panel moves below a visual — restore immediately.

---

## 8. Filter panel and bookmark rules

Each developer page has ONE bookmark group, TWO children:
  Page 1:   "1) Filter Show" / "1) Filter Hide"
  Page 2:   "2) Filter Show" / "2) Filter Hide"
  ...continuing to Page 15...

Scope: applyOnlyToTargetVisuals:true, suppressData:true
Filter Panel group named exactly 'Filter Panel' on every page.

NEVER add, remove, or rename bookmarks
NEVER change bookmark scope
NEVER move or resize Filter Button or Filter Panel

Page duplication (all 15 used):
  Agent may duplicate blank page
  Must create new bookmark pair following naming pattern
  Must update targets to new visual IDs
  Must confirm Filter Panel highest z-order
  Must confirm with user, remind to test in Desktop

---

## 9. Filter governance

Top bar (Zone A): max 4 slicers, divided equally by width
  Fill the top bar first before using the filter pane
  Slicers must never spill left into the title area (x:383-1583)
5th slicer onwards: filter pane (Zone B)
More Filters button:
  ≤4 slicers total (pane empty) → hidden (never deleted)
  ≥5 slicers (pane in use)      → visible
Zone C: page-level only
Too many requested → flag, suggest design or model change

---

## 10. Visual rules

Priority: vocabulary copy → native → AppSource (approval) → custom (approval)

NEVER: HTML Content, SVG, Deneb without approval
NEVER: implicit measures
PREFER: bar/column over pie/donut
NO: waterfall or scatter without confirmation

May change:
  Size, position in Zone C, data fields,
  title/subtitle text, data labels on/off, gridlines on/off

Must never change:
  Font: IberPangea, IberPangea Text (fallback Arial)
  Font sizes: title 16px bold, subtitle 14px,
    axis 14px, data labels 14px, legend 14px,
    card value 60px bold, card label 18px
  Colours: #000000 text, #3A3537 legend
  Border: #CCCCCC 1px 5px radius
  Padding: 10px all sides
  Conditional colours: positive #02892E, negative #9B0000
  Legend: Top Left, title off
  Responsive: always false

---

## 11. Visual vocabulary rules

7 hidden pages, ~30 pre-formatted visuals. Always hidden.
NEVER modify, reformat, delete, or unhide vocabulary pages.
Agent copies formatting — dimensions may differ in actual report.

Pages:
  Visuals: KPI, Card & Slicers
  Visuals: Ranking
  Visuals: Change Over Time
  Visuals: Change Over Time II
  Visuals: Part-To-Whole
  Visuals: Correlation
  Visuals: Flow

Fallback for non-vocabulary visuals:
  Apply all values from AgentAdamTheme_STANDARDS.md
  Tell user: "This visual is not in the vocabulary —
  please review formatting in Desktop."

---

## 12. Dummy data rules

NEVER delete DummyData while vocabulary visuals reference it.
End of every session: check no report visuals bound to dummy data.
If found → flag. Must never publish with dummy data.

---

## 13. DAX rules

ALWAYS:
  DIVIDE not slash, date table functions, VAR/RETURN for
  complex measures, measure references not raw aggregations,
  SWITCH(TRUE()) not nested IF, REMOVEFILTERS not FILTER(ALL()),
  description + display folder + format string on every measure

NEVER:
  Calculated columns on fact tables (absolute ban)
  Hardcoded dates or years
  Undocumented measures
  Implicit measures

Flag violations — never silently correct.

---

## 14. Naming conventions

Total prefix    → aggregations       (Total Sales)
Period suffix   → time intelligence  (Sales YTD, Sales LY)
vs              → comparisons        (Sales vs Target)
% suffix        → percentages        (Margin %)
# prefix        → counts             (# Orders)
Is prefix       → flags/booleans     (Is Active)
Rank prefix     → rankings           (Rank by Sales)
_ prefix        → hidden base        (_Base Sales)

All measures must be in a display folder. None ungrouped.

---

## 15. Semantic model rules

Agent may: read/describe TMDL, write DAX, document model
Agent cannot: connect to sources, refresh, test against
  real data, validate keys in data, assess performance,
  design from scratch

Developer must create base measures before agent session.
After any model change: remind user to refresh and test.

---

## 16. Incremental refresh rules

Full 7-step assessment always required:
  1. Query folding    2. Date column    3. Parameters (DateTime not Date)
  4. Data changes     5. Size justified  6. Summary + confirm  7. Reminders

Agent cannot verify it is working — developer must validate
in dev workspace after implementation. Silent failures are common.

---

## 17. RLS rules

May read and describe existing RLS.
If changing existing RLS → warn user, confirm intent,
  remind to test thoroughly after implementation.
Never modify silently.

---

## 18. Calculation group rules

May read and make simple edits.
Never create without full specification and user confirmation.
Always flag: precedence interactions, format string conflicts.

---

## 19. Partition and SQL rules

NEVER modify without explicit instruction.
Always show proposed changes first.
Always remind user to test by refreshing in Desktop.

---

## 20. Documentation outputs

"Document the visuals"       → visual inventory per page
"Generate a model diagram"   → Mermaid ERD + relationships
"Catalogue the measures"     → all measures with DAX + compliance
"List the tables"            → table inventory
"Document the SQL"           → all partition queries
"Document measure logic"     → plain English business rules
"Document derived fields"    → calculated columns
"Document format strings"    → all non-default format strings
"Full documentation"         → all outputs in one dated file
"Compliance check"           → compliance summaries only

Documentation is read-only — never modifies any file.

---

## 21. Publishing rules

The agent never publishes reports directly.
Publishing is always done manually by the developer.

When developer says report is ready, agent runs pre-publish checklist:
  [ ] No dummy data on any visual
  [ ] All measures tested against real data in Desktop
  [ ] Filter panel opens and closes on every page
  [ ] All page names confirmed correct
  [ ] Vocabulary pages confirmed hidden
  [ ] Guidance pages 1-5 confirmed hidden
  [ ] Unused blank pages confirmed hidden
  [ ] Developer confirmed target workspace

If all pass — agent tells developer to publish manually:
  "Please publish via Desktop: Home → Publish → [workspace]
   Always publish to dev workspace first.
   Validate before promoting to production."

If any fail — flag and do not sign off until resolved.


## 22. What the agent cannot verify (be honest with developer)

  Cannot verify backup exists on disk — trusts user's answer
  Cannot test measures against real data
  Cannot detect dummy data by content — only by table reference
  Cannot confirm relationships return correct results
  Cannot detect manual changes between sessions
  Cannot validate that connection strings are secure

Always remind developer:
  Human validation in Desktop is essential after every session

---

## 23. What the agent cannot do

Cannot: read .pbix, show live edits, connect to sources,
  browse schema, trigger refresh, test against real data,
  validate keys in data, assess performance at scale,
  design from scratch, generate graphical diagrams

Future (Power BI modeling MCP — reassess in 6-12 months):
  Live model querying, real-time DAX validation,
  performance assessment with live data

---

*Last updated: 2026-05-30*
*Owner: Adam McLean - COE Data Governance & Visualisation*
*Review cycle: Fortnightly*


---

*AgentAdam is built on the [data-goblin/power-bi-agentic-development](https://github.com/data-goblin/power-bi-agentic-development) toolkit by Kurt Buhler. AgentAdam adds SP Customer Business-specific standards and governance on top of his work.*
