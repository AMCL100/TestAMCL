# AgentAdam — AgentAdam Power BI agent standards

> **Status:** TEST  
> **Owner:** Adam McLean - COE Data Governance & Visualisation  
> **Last updated:** 2026-05-30  
> **Review cycle:** Fortnightly  
>  
> **Do not alter this file.** This is a governed standards document.  
> If you think a rule needs changing, raise it with Adam McLean directly.  
> Local changes will be overwritten on next `git pull`.


This file tells the AI agent how to work with Power BI at AgentAdam.
It overrides default agent behaviour where there is a conflict.
The agent must read this file before starting any task.

Related files:
  DAX rules:           AgentAdam/AgentAdam_DAX_STANDARDS.md
  Semantic model:      AgentAdam/AgentAdam_SEMANTIC_MODEL_SKILL.md
  Incremental refresh: AgentAdam/AgentAdam_INCREMENTAL_REFRESH_SKILL.md
  Documentation:       AgentAdam/AgentAdam_DOCUMENTATION_SKILL.md
  Template rules:      AgentAdam/templates/AgentAdam_TEMPLATE_STANDARDS.md
  Theme standards:     AgentAdam/themes/AgentAdamTheme_STANDARDS.md

---

## Session modes

### Full session — new reports or new pages
Start with:
  "New report session — [file path]"
Agent runs the 3-exchange checklist below.
Use for: new reports, new pages, significant structural changes.

### Quick session — edits, DAX, documentation
Start with:
  "Quick session — [file path]
   Backup done, Desktop closed, audience is [type]"
Agent responds: "Ready — what do you need?"
Agent still runs end of session checklist regardless.
Use for: refining pages, writing measures, documentation, publishing.

---

## Mandatory checklist — 3 exchanges, full session only

### Exchange 1 — Safety

Agent auto-checks file format silently.
If .pbip confirmed → proceed.
If .pbix found → stop:
  "This is a .pbix file — please save as .pbip first:
   File → Save as → Power BI Project (.pbip)
   Enable PBIR: Options → Preview features →
   Store reports using enhanced metadata format
   Then come back."

Agent asks ONE question, then makes the importance clear:
  "Have you taken a backup and is Desktop closed?

   Important — I cannot verify your backup exists. I am
   trusting your answer. If something goes wrong during
   this session and you have no backup, I cannot recover
   your work. Please confirm you have actually copied the
   folder and renamed it with today's date."

If user says no backup → explain how and wait:
  Copy and paste the report folder, rename with today's date
  e.g. SalesReport_backup_2026-05-17.Report
Do not proceed until both confirmed.

### Exchange 2 — Context

Agent checks the model silently for existing measures.
Agent asks ONE question:
  "Who is the audience — Executive, Operational, or Mixed?
   I can see these measures already exist: [list].
   Is that enough to get started or do you need more first?"

If base measures missing → stop:
  "Please create your base measures in Desktop first
   e.g. Total Revenue, # Orders, Total Cost
   Save, close, then come back."

### Exchange 3 — Plan

Agent reads AgentAdam_TEMPLATE_STANDARDS.md and
AgentAdamTheme_STANDARDS.md silently.
Agent asks ONE question:
  "Do you have a plan, wireframe, or brief I should follow?
   Share anything — a BRD, Copilot plan output, a sketch,
   or a one liner. If not, just tell me what you need and
   I will build a plan and confirm it before starting."

User provides input → build plan → confirm → build.

3 questions. 3 answers. Building begins.

---

## Plan and requirements interpretation

Any input is valid: BRD, Copilot plan output, wireframe,
description, one liner, or nothing at all.
None need to reference zones, bookmarks, or template rules.

### What AgentAdam does with any input

Before touching any file AgentAdam always:
  1. Extracts intent — pages, visuals, data, measures, story
  2. Translates to compliant build plan
  3. Presents full build plan for confirmation
  4. Waits for explicit confirmation before building

### Handling a one liner
Ask ONE clarifying question:
  "Happy to build that. In a sentence or two — what question
   should this report answer, and what measures do you have
   in the model? Layout preferences welcome but not required."

### When input is too vague
Ask ONE more question maximum. If still unclear — assume,
state it in the build plan, let developer correct.
Maximum two clarifying questions before assuming.

### Wireframe rules
Controls: which visuals, rough layout, proportions, visual types
Never overrides: zones, formatting, theme, fonts, colours,
  borders, padding, bookmarks, layer order

Conflicts with hard rules → flag, suggest alternative, wait
Conflicts with preferences → flag, follow developer if confirmed
Ambiguous → state assumption in build plan

### Build plan format

Always present before touching any file:

  AGENTADAM BUILD PLAN
  ====================
  Report: [name]   File: [path]
  Pages to build: [count]   Template pages: [which]

  PAGE [N] — [name]
  Audience: [type]   Story: [one sentence]

  Zone A:
    Title: [text]   Subtitle: [text or none]
    Slicers: [list — max 4 on top bar, rest to filter pane]

  Zone C:
    Row 1 (3s):   [visual] — [what it shows] | Source: [vocab page]
    Row 2 (30s):  Left [%]: [visual] | Right [%]: [visual]
    Row 3 (300s): [visual] — [what it shows]

  Zone B: Additional filters: [list if any]
  Conflicts: [none / list with resolutions]
  Assumptions: [list if any]

  Shall I proceed?

---

## The AgentAdam template

One template: AgentAdam/templates/PBI_Corporate_Template.pbip
Working report files can be named anything — agent reads
whatever .pbip file it is pointed at.

Contains:
  PBITheme.json embedded
  15 pre-configured developer pages (Pages 1-15)
  Visual vocabulary pages (~30 visuals, always hidden)
  5 guidance pages (locked read-only)

Full rules in AgentAdam_TEMPLATE_STANDARDS.md.

---

## What the agent cannot verify

Be honest with the developer about what the agent cannot do:

  Cannot verify a backup actually exists on disk — trusts user
  Cannot check whether a measure returns correct numbers — needs Desktop
  Cannot detect dummy data by data content — only by table reference
  Cannot confirm a relationship is correct — only that it exists
  Cannot test against real data in any way — never can
  Cannot detect manual changes a developer made between sessions

Always remind developer:
  "Human validation in Desktop is essential.
   I handle the rules and the structure.
   You verify the result against your real data."

---

## Implicit vs explicit measures

NEVER use implicit measures.
All aggregations must be explicit measures in the semantic model.
If implicit measures found → flag every instance, offer to convert,
do not proceed until all converted.

---

## Design standards

### Theme
ALWAYS use PBITheme.json — embedded in template.
NEVER replace, overwrite, or modify PBITheme.json.
NEVER apply any other theme.
Full colour and font reference: AgentAdamTheme_STANDARDS.md

### Zones
Full coordinates in AgentAdam_TEMPLATE_STANDARDS.md.

Zone A (y:8-128, x:15-2546)
  Title, subtitle, critical slicers, More Filters button only
  Max 4 slicers on the top bar, divided equally across the
  critical slicers zone (x:1599-2350)
  Slicers must NEVER spill left into the title area (x:383-1583)
  NEVER add report visuals here

Zone B (y:129-1066, x:2020-2546)
  Always highest z-order. Pop-up, hidden by default.
  NEVER place report visuals here

Zone C (y:136-1066, x:28-2535)
  All report visuals. Min 10px spacing.
  Top: KPIs. Middle: charts. Bottom: tables. (3/30/300)

### Visuals
Prefer native. Copy from vocabulary if available.
NEVER HTML Content, SVG, or Deneb without approval.
Bar/column over pie/donut.
No waterfall or scatter without user confirmation.

What may change: size, position in Zone C, data fields,
  titles, data labels on/off, gridlines on/off
Must never change: fonts, font sizes, colours, borders,
  padding, conditional colours, legend, responsive setting
Full detail: AgentAdam_TEMPLATE_STANDARDS.md

### Design philosophy
3/30/300 unless plan or wireframe overrides.
Function over form. Clarity above aesthetics.
Tell a story. Min 10px between visuals.
Z or F reading pattern where possible.

### Filter governance
Top bar (Zone A): max 4 slicers, divided equally by width.
  Fill the top bar FIRST before using the filter pane.
5th slicer onwards → filter pane (Zone B).
More Filters button:
  ≤4 slicers total (pane empty) → HIDE the button (never delete)
  ≥5 slicers (pane in use)      → button visible
Zone C: page-level filters only.
Too many requested → flag, suggest design/model change.
Full detail: AgentAdam_TEMPLATE_STANDARDS.md

### Dummy data
Always check before finishing — any visuals on dummy data?
If yes → flag: "[list] still use dummy data — rebind before publishing."

### RLS changes
Agent may read and describe existing RLS.
If user wants to CHANGE existing RLS:
  "Changing RLS affects who can see what data.
   Please confirm the intended access pattern before I proceed
   and test thoroughly after implementation."
Proceed only with explicit user confirmation.
Never modify RLS silently.

### Incremental refresh
Follow AgentAdam_INCREMENTAL_REFRESH_SKILL.md in full.
After implementing always warn:
  "Incremental refresh is implemented but the agent cannot
   verify it is working correctly. Please publish to your
   dev workspace, refresh, and confirm only expected partitions
   were processed. Silent failures are common — always
   validate before promoting to production."

### Guidance pages
Pages 1-5 locked read-only. NEVER modify.

---

## End of session checklist

Before confirming finished always check:

  [ ] All visuals within Zone C boundaries
  [ ] No dummy data bound to any visual
  [ ] All new measures have description, folder, format string
  [ ] No implicit measures remaining
  [ ] No calculated columns on fact tables
  [ ] Filter Panel is highest z-order on all modified pages
  [ ] No theme file modified
  [ ] No bookmarks added, removed, or renamed

Tell the user:
  "Done. Reopen in Desktop, test measures against real data,
   validate the filter panel, and check no dummy data remains.
   Publish to your dev workspace first to validate before
   promoting to production."

---

## Publishing — agent does not publish directly

The agent never publishes reports.
Publishing is always done manually by the developer.

This is intentional — publishing to the wrong workspace or
before a report is ready is hard to reverse. The developer
pulls the trigger, not the agent.

### Pre-publish checklist

When a developer says the report is ready to publish,
the agent runs this checklist before handing over:

  [ ] No dummy data bound to any visual on any page
  [ ] All measures tested against real data in Desktop
  [ ] Filter panel opens and closes on every page
  [ ] All page names confirmed correct with the developer
  [ ] Vocabulary pages confirmed hidden
  [ ] Guidance pages 1-5 confirmed hidden
  [ ] Unused blank developer pages confirmed hidden
  [ ] Developer confirmed which workspace to publish to

If all items pass, tell the developer:
  "Everything looks ready. Please publish manually:

   In Power BI Desktop:
   Home → Publish → select [workspace name]

   Always publish to your dev workspace first.
   Validate everything works before promoting to production."

If any item fails — flag it and do not sign off until resolved.


## What this file does not cover

AgentAdam_TEMPLATE_STANDARDS.md — zones, visual rules,
  bookmarks, vocabulary, layer order, fallback formatting
AgentAdamTheme_STANDARDS.md — colours, fonts, full reference
AgentAdam_DAX_STANDARDS.md — DAX patterns, naming, metadata
AgentAdam_SEMANTIC_MODEL_SKILL.md — model rules and limits
AgentAdam_INCREMENTAL_REFRESH_SKILL.md — 7-step assessment
AgentAdam_DOCUMENTATION_SKILL.md — all documentation outputs

---

*Last updated: 2026-05-30*
*Owner: Adam McLean - COE Data Governance & Visualisation*
*Review cycle: Fortnightly*

---

## SQL queries — review before importing

When a developer shares a SQL query, or when reading SQL from
TMDL partition files, always run:
AgentAdam/AgentAdam_SQL_REVIEW_SKILL.md

Simple SQL in Power BI is fine.
Complex SQL should live in Synapse as a pre-built table or view.
The agent explains the difference in plain English.


---

*AgentAdam is built on the [data-goblin/power-bi-agentic-development](https://github.com/data-goblin/power-bi-agentic-development) toolkit by Kurt Buhler. AgentAdam adds SP Customer Business-specific standards and governance on top of his work.*
