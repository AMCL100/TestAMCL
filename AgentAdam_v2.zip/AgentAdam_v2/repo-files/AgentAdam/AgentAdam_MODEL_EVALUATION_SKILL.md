---
name: AgentAdam Model Evaluation
description: Use when asked to review, evaluate, health-check, optimise, or assess an existing Power BI semantic model — for size, refresh speed, unused objects, structure, or best-practice compliance. Read-only and advisory; it surfaces findings and explains them, never deletes or changes anything. Trigger whenever the developer asks "is this model any good", "can we make this smaller/faster", "review my model", or similar.
---

# AgentAdam — Semantic Model Evaluation

> **Status:** TEST
> **Owner:** Adam McLean - COE Data Governance & Visualisation
> **Last updated:** 2026-06-06
> **Review cycle:** Fortnightly
>
> **Do not alter this file.** This is a governed standards document.
> If you think a rule needs changing, raise it with Adam McLean directly.
> Local changes will be overwritten on next `git pull`.

This skill evaluates an EXISTING semantic model against best practice and
AgentAdam standards, then produces an advisory health-check report. It is
read-only. It surfaces candidates and explains its reasoning. The developer,
who has the business context the agent cannot see, decides what to action.

The agent NEVER deletes, removes, or alters model objects as part of an
evaluation. It produces findings only. Any change is a separate, explicitly
approved action.

---

## Core philosophy

The agent sees the artefact (the files), not the business. It can confirm a
field is unused in THIS report. It cannot see other reports on a shared model,
planned features, occasional stakeholder use, or downstream consumers (Excel
pivot connections, paginated reports, other tools). Therefore:

- Every removal suggestion is phrased **"appears unused — confirm before
  removing"**, never "delete this".
- On an existing, in-production model the default stance is **conservative**:
  the burden of proof is on removal, not retention. Anything ambiguous is
  preserved and flagged as "confirm first".
- Recommendations are **proportional**: the cost of a fix must match the size
  of the problem it solves. A best practice applied where the problem does
  not exist is not best practice — it is just complexity.

---

## Step 1 — Ask the gating questions BEFORE reading the model

Do not read the model files until these are answered. Skipping a check that
does not apply saves the developer's time and keeps the evaluation focused.

Ask all three together, briefly:

```
Before I look at the model, three quick questions so I don't
recommend something that breaks it:

1. Is this model used by more than one report?
   (Often it's one model per report here — but if it's shared, I can
    only see THIS report, so I'll treat "unused" findings as caution.)

2. Does this report need Row Level Security (RLS)?
   (Usually only when sharing with external partners. If not, I'll
    skip RLS checks rather than flag them as missing.)

3. Is this a finished product, or one you're still building out?
   (Changes how confidently I flag things as "unused".)
```

Apply the answers:

```
Shared across multiple reports
  → unused-object detection drops to CAUTION only. State clearly:
    "I can only see this report. A field unused here may be critical
     in another report on this model — I cannot see those."

RLS not needed
  → skip all RLS checks entirely. Do not flag missing RLS.

Still being built
  → be conservative on anything that looks staged for later;
    ask "is this for a planned feature?" rather than flagging unused.

Finished, single-report model
  → highest confidence (but still "confirm before removing", never delete).
```

---

## Step 2 — Evaluate, graded by three tiers

Grade every finding by how universal the practice actually is. Do NOT be
dogmatic. Most published best-practice guides are written for large
enterprise deployments; many models here are small and one-per-report, and
for those a simpler design is genuinely correct.

### TIER 1 — always worth fixing, costs ~nothing

Flag these confidently regardless of model size.

```
Auto Date/Time enabled
  Creates a hidden date table for every date column. Often a large
  share of model size. Recommend disabling and using one date table.

No proper date table / not marked as a date table / not contiguous
  See the date-table guidance below. Almost every model needs one.

Numbers or dates stored as text
  Breaks aggregation and sorting, wastes memory. Recommend correct types.

Genuinely unused columns  (GATED by the shared-model answer)
  Columns not referenced in any measure, relationship, visual, or RLS rule.
  Only high-confidence on a single-report model. On a shared model these
  are CAUTION only.

Measures missing format strings, descriptions, or display folders
  Costs nothing to fix, helps everyone. Ties to the DAX standards skill.

Implicit measures (raw columns dragged into visuals)
  Against AgentAdam standards. Recommend explicit measures.
```

### TIER 2 — apply by default, but size-dependent

Frame these as "worth it if this grows, optional if it stays small — your
call". This is the zone where one big flat table is sometimes genuinely fine.

```
Flat mega-table where a star schema is warranted
  True at scale, optional when tiny. A few-hundred-row reference report
  does NOT need fact/dimension splitting. Judge by row counts, number of
  reports, and whether it will grow. Recommend star schema for models that
  are large, shared, or growing — not for small single-purpose ones.

Text relationship keys that should be integer surrogate keys
  Real benefit at millions of rows (faster joins, better compression);
  irrelevant on a small dimension. Do not recommend for tiny tables.

Calculated columns that should be measures
  Strong default. But note that calculated columns are sometimes correct
  (when the logic genuinely needs row context a measure cannot replicate).

Calculated columns that should be pushed back to the source
  If the logic could be computed in Synapse instead, recommend that —
  ties to the SQL review skill and the "do heavy lifting at source"
  philosophy. (Synapse today; this principle carries to the future
  data platform unchanged.)

Snowflaked dimensions that could be flattened
  Recommend flattening for cleaner star schema, size-dependent.
```

### TIER 3 — only flag if the problem actually exists

Do NOT raise these on a small model. Premature complexity is a cost, not a win.

```
Large tables without incremental refresh
  Only relevant for large/slow tables. ASK whether full refresh is
  actually a problem before recommending — incremental adds complexity
  and is only worth it if refresh time or size is genuinely hurting.
  Ties to the incremental refresh skill.

High-cardinality datetime splitting (date + time columns)
  Only when that column is a measured size problem. Note it forces
  measures to be rewritten, so only worth it if the saving is significant.

Partitioning, composite models, aggregation tables
  Scale techniques. Actively harmful as premature complexity on a
  small model. Only raise for genuinely large models.
```

---

## Step 3 — Space-saver checks

Look specifically for compression killers and dead weight:

```
High-cardinality text / hex / GUID columns in fact tables
  These destroy compression. Recommend moving to a dimension, replacing
  with a smaller surrogate key, or removing if unused.

Over-precise decimals
  More decimal places than the business needs compress poorly.
  Recommend reducing precision or using a fixed decimal / integer type.

DateTime where only the date is needed
  If the time component is always midnight or never used, recommend
  converting to a date type, or splitting if time is occasionally needed.

Long free-text columns (comments, descriptions, URLs) in fact tables
  Recommend moving to a dimension or dropping if unused.

Sparse columns (mostly blank)
  Flag for review — often removable.

Duplicate columns carrying the same information
  Recommend keeping one.

Staging / intermediate Power Query steps loaded into the model
  Recommend disabling their load if they only support other queries.
```

For any large model, recommend the developer confirm findings with VertiPaq
Analyzer (free, via DAX Studio) — it shows exactly which columns consume the
most memory, so removal effort can be aimed where it actually pays off.

---

## Step 4 — The aggregation check

A high-value pattern: detail stored but never displayed.

```
Detect:   a fact table at transactional grain (one row per line item)
          where every visual using it shows only aggregates
          (sums / averages by month, region, etc — never individual rows)

Conclude: the detail grain is being stored but never shown

Recommend (conservatively, and source-first):
  "This table holds detail at [transaction] grain, but every visual
   aggregates to [month/region]. If you never need individual
   transactions, aggregating could cut size and speed refresh
   significantly.

   The better fix is usually at SOURCE — have Synapse build the
   aggregated table in the daily batch, so the heavy work happens
   once per day rather than in Power BI. Model-side aggregation is
   the fallback.

   This is a one-way door: confirm you never need transaction-level
   detail for drill-through, audit, or future reporting before doing
   this."
```

Never aggregate automatically. Always suggest, explain the trade-off, and
require explicit confirmation.

---

## Step 5 — Date table detection and generation

Almost every model needs a proper date table. Detect and, if missing, offer
to create one — but never silently.

```
Detect:
  Is there a table marked as a date table (the mark-as-date-table flag)?
  Is it contiguous and does it cover full years?
  Are date columns relying on Auto Date/Time (which should be disabled)?

If missing, ASK the one question that changes the table:
  "I don't see a proper date table. Before I suggest one:
   does your org use a fiscal year different from the calendar year
   (e.g. April–March)? And should it cover a fixed range, or track
   the data dynamically as it grows?"
  (A calendar-year table built for a fiscal-year report is a subtle
   wrong answer that looks right.)

Then SHOW the DAX and explain — derive the range dynamically and snap to
FULL years, because time intelligence (YTD, prior year, year-over-year)
needs complete years to work:

  CALENDAR(
    DATE(YEAR(MIN(Fact[Date])), 1, 1),
    DATE(YEAR(MAX(Fact[Date])), 12, 31)
  )

Three creation methods — DAX is the default here:
  1. DAX calculated table (CALENDAR)  ← default; self-contained, no
     source work, "just works" for a one-off small report
  2. Power Query (M)  — folds where possible, cleaner for fiscal calendars
  3. Date dimension in the source (Synapse)  — the enterprise answer;
     recommend THIS when it is a shared model that should have a proper
     reusable date dimension

Sequence: detect -> ask -> show the DAX -> get approval -> add it and mark
it as a date table -> then prompt to disable Auto Date/Time.
```

Never create the date table without showing it and getting approval first.

---

## Step 6 — Report back with a tier-scored summary

Produce the findings in ONE pass (do not drag it into a long back-and-forth —
that wastes the developer's time and credits). Use this shape:

```
MODEL HEALTH CHECK — [model name]

[N] findings:
  [n] safe wins        (Tier 1 — always worth doing)
  [n] worth reviewing  (Tier 2 — depends whether this grows)
  [n] leave alone      (Tier 3 / not applicable at this size)

SAFE WINS
  • [finding] — [why it matters] — [what to do]
  ...

WORTH REVIEWING (your call — depends if this model grows)
  • [finding] — [why] — [recommendation] — [the trade-off]
  ...

LEAVE ALONE / NOT APPLICABLE HERE
  • [why this common recommendation does NOT apply to this model]
  ...

Anything removable is flagged "appears unused — confirm before removing".
Nothing here has been changed. These are recommendations only.
```

Keep each finding to a line or two. Lead with the safe wins (they build
confidence and are genuinely free). Be explicit about what you are NOT
recommending and why — it teaches the proportionality lesson and reassures
the developer you are not just reciting a checklist.

---

## Optional — propose a better architecture

If (and only if) the developer asks for it, you may propose an improved model
structure that answers the same questions more efficiently. When you do:

- Describe the proposed structure in plain English first (tables,
  relationships, grain, where aggregation should happen).
- Recommend source-side work (Synapse) for anything heavy, per the SQL
  review philosophy.
- Only write proposed TMDL if the developer explicitly asks for it — that
  edges into model authoring, which is a separate, approved activity.
- Always frame it as "answers the same questions, more efficiently" — never
  change what the report can do without the developer's say-so.

---

## What this skill must never do

- NEVER delete, remove, or alter model objects as part of an evaluation.
- NEVER aggregate, split, or restructure automatically.
- NEVER create a date table without showing it and getting approval.
- NEVER recommend removing something flagged as used in relationships, RLS,
  or active measures — even if it is not on a visual.
- NEVER apply enterprise-scale recommendations to a small model.
- NEVER claim certainty about usage on a shared model.

Evaluation is advisory. The developer always decides. The agent's job is to
surface findings clearly, grade them honestly, and explain its reasoning —
including what it cannot see.
