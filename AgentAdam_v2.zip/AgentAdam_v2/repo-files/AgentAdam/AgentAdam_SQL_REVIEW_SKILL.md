# AgentAdam — SQL review skill

> **Status:** TEST  
> **Owner:** Adam McLean - COE Data Governance & Visualisation  
> **Last updated:** 2026-05-30  
> **Review cycle:** Fortnightly  
>  
> **Do not alter this file.** This is a governed standards document.  
> If you think a rule needs changing, raise it with Adam McLean directly.  
> Local changes will be overwritten on next `git pull`.


This skill helps the agent review SQL queries that developers use
to import data into Power BI. It flags queries that are doing too
much heavy work inside Power BI and recommends moving that work
into Synapse instead.

The agent reads this skill whenever a developer shares a SQL query
or when reading SQL from existing partition definitions in TMDL files.

---

## Why this matters — plain English explanation

When you write a SQL query in Power BI to pull in data, that query
runs every single time someone:
  Opens the report
  Refreshes the data
  Clicks a slicer or filter

If the query is simple and fast — no problem. Power BI handles it
easily and your report feels snappy.

If the query is complex and slow — every one of those actions makes
Synapse work very hard. This costs money, slows down everyone else
using Synapse at the same time, and makes your report feel sluggish.
The Synapse capacity admins also do not enjoy it.

The solution is to move the heavy work into Synapse first — as a
pre-built table or view that Power BI simply reads from. Think of it
like doing your cooking in the kitchen (Synapse) rather than at the
dining table (Power BI). Power BI should be serving the meal,
not doing the preparation.

---

## When the agent runs this review

  When a developer shares a SQL query before importing
  When reading existing SQL from TMDL partition files
  When a developer asks "is this SQL okay to use in Power BI?"
  When reviewing an existing model for performance issues

---

## Step 1 — Read and understand the query

Before assessing anything, read the full SQL query.
Explain back to the developer in plain English what it does:

  "This query is pulling sales data from the Orders table,
   filtering to the last 3 years, and joining it to the
   Customer table to get customer names and regions."

This confirms the agent has understood the query correctly
and gives the developer a chance to correct any misunderstanding.

---

## Step 2 — Check for simple patterns (these are fine)

These patterns are straightforward and safe to run in Power BI:

Reading from a single table:
  SELECT [columns] FROM [table] WHERE [simple filter]
  This is exactly what Power BI is designed for.

Simple joins between two or three tables:
  Joining a fact table to one or two dimension tables
  on a clear key column is normal and expected.

Basic filters:
  WHERE OrderDate >= '2023-01-01'
  WHERE Status = 'Complete'
  WHERE Region IN ('North', 'South')
  These are fine — they reduce the data before it reaches Power BI.

Selecting specific columns:
  Always good — only pulling the columns that are needed.

If the query only contains these patterns → tell the developer:
  "This query looks straightforward and is fine to run directly
   in Power BI. No changes needed."

---

## Step 3 — Check for warning signs (explain these in plain English)

The following patterns mean the query is doing heavy work that
should ideally live in Synapse instead. Explain each issue
in plain English — do not use technical jargon.

### SELECT * (selecting everything)

What it means: the query is pulling every single column from
the table, including ones that Power BI will never use.

Say to the developer:
  "Your query is pulling every column from [table name].
   This means Power BI is downloading a lot of data it
   does not need. Can you list the specific columns your
   report uses? I can help you update the query to only
   pull those — it will be faster and use less memory."

### No filter on a large table

What it means: the query is pulling the entire table with
no date or status filter. If the table has millions of rows,
this will be slow and expensive.

Say to the developer:
  "This query pulls every row from [table name] with no filter.
   If this table is large, this will be slow and costly.
   Does your report only need data from a certain time period
   or status? Adding a filter here would make a big difference."

### Complex calculations inside the query

What it means: the query is doing maths or logic that results
in new values being calculated — things like running totals,
rankings, comparisons to previous rows, or percentages.

Plain English signals to look for:
  CASE WHEN ... THEN ... END (lots of conditional logic)
  SUM(...) OVER (...) or ROW_NUMBER() OVER (...) — calculations
    that look at multiple rows at once
  Subqueries — a SELECT inside another SELECT
  Many lines of complex logic producing a single column

Say to the developer:
  "Your query is doing some heavy calculations — things like
   [describe what you found in plain terms e.g. 'calculating
   a running total' or 'ranking rows' or 'working out each
   row's share of the total'].

   Every time your report refreshes or someone clicks a filter,
   Synapse has to redo all of this work. That is expensive and
   slow.

   The better approach is to have this pre-calculated in Synapse
   as a table or view that Power BI simply reads from. Power BI
   then just picks up the already-calculated values instead of
   working them out every time.

   I would recommend speaking to your Synapse team about creating
   a pre-built object for this. I can describe exactly what it
   needs to contain if that helps."

### Joining many large tables together

What it means: the query is combining four or more tables,
or joining very large tables together in complex ways.

Say to the developer:
  "Your query is joining [number] tables together. When these
   tables are large, combining them inside Power BI can be very
   slow and puts a lot of pressure on Synapse every time the
   report refreshes.

   If this is a join that will always be the same — the same
   tables, the same columns — it is worth having it pre-built
   in Synapse as a single table that Power BI reads directly.
   This would be much faster."

### Very long or hard to read queries

What it means: if a query is extremely long or very difficult
to understand, it is a signal that it may be doing too much.

Say to the developer:
  "This query is quite complex. Complex queries are harder to
   maintain and often run slowly. It is worth asking whether
   some or all of this logic could live in Synapse instead,
   where it is easier to manage and only runs once rather than
   every time the report refreshes."

---

## Step 4 — Give a clear recommendation

After reviewing, always give a clear recommendation in one of
three categories. Use plain English — no technical terms.

### Green — fine to use in Power BI

  "This query is straightforward and is fine to run directly
   in Power BI. No changes needed."

### Amber — small improvements suggested

  "This query will work but there are a couple of small things
   worth tidying up before you import:
   [list the specific issues and simple fixes]
   These changes will make your report faster and use less
   memory. Would you like help updating the query?"

### Red — recommend moving to Synapse first

  "This query is doing quite a lot of heavy work that will
   run every time your report refreshes or someone uses a
   filter. Over time this will make your report slow and
   will put unnecessary pressure on Synapse.

   My recommendation is to have this logic pre-built in
   Synapse as a table or view, then have Power BI read from
   that instead. This means the heavy work only happens once
   when the Synapse table is built, not every time someone
   uses your report.

   Here is what I would suggest the Synapse object contains:
   [describe the output in plain English]

   Please speak to your Synapse team about setting this up.
   Once it exists, Power BI can connect to it with a very
   simple query and everything will run much faster."

---

## Step 5 — Log the SQL in documentation

After the review is complete, always remind the developer:
  "This SQL query will be included in the report documentation
   when you run 'Full documentation please'. It will be recorded
   alongside a plain English description of what it does."

This ensures future developers and maintainers can understand
where the data comes from without having to reverse-engineer
the query themselves.

---

## What the agent does NOT do

The agent does not contact Synapse or run queries itself.
The agent cannot tell you how long a query actually takes to run —
that requires testing against real data.
The agent cannot create Synapse tables or views — it can describe
what they need to contain, but the Synapse team builds them.

The agent's job is to flag risks and give clear recommendations.
The developer and Synapse team make the final decisions.

---

## Quick reference — plain English signals to watch for

| What you see in the SQL | What it means | Recommendation |
|---|---|---|
| SELECT * | Pulling more data than needed | Ask developer to list specific columns |
| No WHERE clause | Pulling entire table | Suggest adding a date or status filter |
| CASE WHEN (lots of it) | Complex logic | Consider moving to Synapse |
| SUM/COUNT OVER (...) | Calculations across multiple rows | Recommend Synapse |
| SELECT inside a SELECT | Query within a query | Flag as complex, assess severity |
| 4+ tables joined | Complex multi-table join | Consider pre-joining in Synapse |
| Query over 50 lines | Likely complex | Review carefully, discuss with developer |
| Simple SELECT + WHERE + 1-2 JOINs | Standard import | Fine to use in Power BI |

---

*Last updated: 2026-05-30*
*Owner: Adam McLean - COE Data Governance & Visualisation*
*Review cycle: Fortnightly*


---

*AgentAdam is built on the [data-goblin/power-bi-agentic-development](https://github.com/data-goblin/power-bi-agentic-development) toolkit by Kurt Buhler. AgentAdam adds SP Customer Business-specific standards and governance on top of his work.*
