# AgentAdam — Report Planning Template

> **Optional.** Got a one-line idea? Just paste that to AgentAdam and go.
> Want more structure? Fill this in and paste it instead. Either way you are
> giving the agent everything in one go — which means fewer back-and-forth
> questions, a faster build, and lower credit cost.
>
> This is **not** submitted to anyone and is **not** part of the plugin. It is
> a thinking aid. Use the bits that help, ignore the rest.

---

## Three ways to use this

```
A one-liner is fine
  "A sales report showing performance against target by region"
  → paste that and let the agent take it from there

This template if you want structure
  → fill in what you can, leave blanks where unsure,
    the agent asks about anything missing

Already have a plan? (yours, or drafted with Copilot)
  → paste that instead, then skim below for gaps
  → treat AI-drafted plans as a draft to CHECK, not gospel — they
    can assume tables that don't exist, pick a finer grain than you
    need, or miss our governance rules
```

---

## The report

```
1. What's the purpose of this report?
   What's it for, and what should someone be able to do or see
   after looking at it?
   →

2. Who's the audience?
   Executive  /  Operational  /  Mixed
   →
```

## What you're measuring

```
3. What do you want to measure?
   Your key metrics — the numbers that matter
   (e.g. revenue, volume sold, complaints, average wait time):
   →

4. How do you want to break those down?
   The dimensions you'll slice by
   (e.g. by month, region, product, team):
   →

5. What's the lowest grain you actually need?
   Individual transactions, or are monthly / regional / summary
   figures enough?
   →
   (Finer grain = bigger, slower model. Only go as low as the
    report genuinely needs.)
```

## The data

```
6. Where does the data come from?
   Synapse table or view  /  a SQL query  /  CSV or Excel  /  other
   → name it or describe it:
   (AgentAdam works best with Synapse — it'll flag if a query or
    file should become a proper table in the daily batch.)
```

## The model

```
7. New model, or adding to an existing one?
   →

8. Will this model be used by more than one report?
   Just this one  /  Shared across several  /  Not sure
   →
   (Usually one model per report for us — but it changes how
    carefully the agent treats changes, so worth knowing.)

9. Do you need a date table?
   (Almost always yes.) If yes — what date range, and calendar or
   fiscal year?
   →
```

## Governance & growth

```
10. Does this need Row Level Security (RLS)?
    Yes  /  No  /  Not sure
    (Usually only for sharing with external partners. Internal
     reports usually don't need it.)
    →

11. Will this grow or expand later?
    Any pages, fields, or features planned down the line?
    →
    (Tells AgentAdam what to leave room for — and what NOT to strip
     out later as "unused".)
```

## Pages — *optional, skip if you haven't planned this far*

```
12. If you've thought about pages, sketch them.
    One line per page is plenty — e.g.
      Page 1: overview KPIs and trend
      Page 2: breakdown by region
      Page 3: product detail
    No worries if not — the agent will help you structure it.
    →
```

---

**Done? Paste it — or just your one-liner — to AgentAdam and let it build you
a proper plan.**

---

*Not part of the plugin. A human planning aid for SP Customer Business
developers. Questions → Adam McLean.*
