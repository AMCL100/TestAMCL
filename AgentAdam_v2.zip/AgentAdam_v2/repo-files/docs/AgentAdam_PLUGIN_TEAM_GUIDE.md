# AgentAdam — Team Guide

> **Status:** TEST · **Owner:** Adam McLean — COE Data Governance & Visualisation
>
> AgentAdam's rules load automatically into every VS Code session on your
> machine. Once you are set up, just open VS Code and start talking to Copilot.
> No startup commands. No loading files. No cloning.

---

## How it works

```
AgentAdam's core rules live in a SharePoint folder that syncs to your machine.
VS Code reads from that folder automatically — no matter what you have open.

The plugin adds specialist skills on top (DAX, SQL review, model evaluation,
documentation) that load on demand when you ask for them.

After setup: open VS Code → open your report → talk to Copilot. That is it.
```

---

## One-time setup

Do these steps once. You never repeat them.

---

### 1. Check Git is installed

The plugin install clones from GitHub behind the scenes. You will not type
any Git commands — but Git must be present on your machine.

```
Open a terminal in VS Code (Ctrl + `)  or open Command Prompt
Type: git --version
Press Enter
```

```
See a version number → you are good, skip to step 2
See "not recognised" → install Git:
  Check your Software Centre / Company Portal for "Git"
  Or download from https://git-scm.com and install with default options
  Then close and reopen VS Code completely
```

Not sure? Ask Adam or IT — it is a 2-minute fix.

---

### 2. Install VS Code

```
Press the Windows key → type: Microsoft Store → open it
Search for: Visual Studio Code
Click Install
```

---

### 3. Install GitHub Copilot

```
Open VS Code
Click the Accounts icon bottom-left → Sign in with GitHub
Press Ctrl+Shift+X → search GitHub Copilot → Install
(this also installs Copilot Chat)
```

---

### 4. Turn on plugins

```
Press Ctrl+,  (opens Settings)
Search for: chat.plugins.enabled
Tick the box to enable it
```

---

### 5. Install the AgentAdam plugin

Pick whichever method is easiest:

**Method A — Command Palette (recommended)**
```
Press Ctrl+Shift+P
Type: Chat: Install Plugin From Source
Paste: https://github.com/U357001_ibe/AgentAdam
Press Enter
```

**Method B — Copilot Chat**
```
Open Copilot Chat (Ctrl+Alt+I)
Click the gear icon → Plugins
Add the marketplace → paste the repo URL
```

**Method C — Agents window**
```
Open the Agents window
Add a plugin → paste the repo URL
```

VS Code adds the AgentAdam marketplace, which contains FIVE plugins:
```
agentadam         your SP governance and standards (the rulebook)
pbi-desktop       Kurt Buhler's Power BI Desktop integration
semantic-models   Kurt Buhler's TMDL editing capability
reports           Kurt Buhler's PBIR report editing capability
pbip              Kurt Buhler's PBIP project handling
```

Install all five — the agentadam plugin is the governance layer, the
other four give the agent the technical capability to actually edit
Power BI files. You need all five for the full experience.

**Install all five — copy and paste these commands one by one into Copilot Chat:**

```
/plugin install agentadam@U357001_ibe/AgentAdam
```

```
/plugin install pbi-desktop@U357001_ibe/AgentAdam
```

```
/plugin install semantic-models@U357001_ibe/AgentAdam
```

```
/plugin install reports@U357001_ibe/AgentAdam
```

```
/plugin install pbip@U357001_ibe/AgentAdam
```

Each one installs in a few seconds. After all five, check Extensions
(Ctrl+Shift+X) → Agent Plugins - Installed → confirm all five appear.

When Adam pushes an update to the repo, all five plugins update
automatically — you never need to reinstall.

**Already had Kurt's plugins installed from local paths?**
That still works. The bundled versions just give you a cleaner setup
going forward. No urgent action needed if your current install works.

---

### 6. Sync the AgentAdam SharePoint folder

AgentAdam's core rules live in SharePoint. You need to sync the folder
to your machine once so VS Code can read from it.

```
1. Open this link in your browser:
   https://iberdrola.sharepoint.com/sites/UK%20Operations/UK%20Operations%20Document%20Library/Reporting/Data%20Visualisation/Agentic%20BI%20-%20AgentAdam

2. Click Sync at the top of the page
   (this adds the folder to your OneDrive sync client)

3. Wait for it to sync — usually takes less than a minute

4. Open File Explorer and confirm the folder is there:
   C:\Users\[yourname]\IBERDROLA S.A\UK Operations - Agentic BI - AgentAdam\
   
```

---

### 7. Add the VS Code setting

This tells VS Code to always load AgentAdam's rules, regardless of
which folder you have open.

```
1. Press Ctrl+Shift+P
2. Run: Open User Settings (JSON)
   (it must say USER settings — not Workspace settings)
3. Add this to the file:

   "chat.instructionsFilesLocations": {
     "~/IBERDROLA S.A/UK Operations - Agentic BI - AgentAdam": true
   }


4. Save the file (Ctrl+S)
5. Reload VS Code: Ctrl+Shift+P → Developer: Reload Window
```

If your settings.json already has other settings, add it inside the
existing curly braces — do not create a second set:

```json
{
  "editor.fontSize": 14,
  "chat.plugins.enabled": true,
  "chat.instructionsFilesLocations": {
    "~/IBERDROLA S.A/UK Operations - Agentic BI - AgentAdam": true
  }
}
```

---

### 8. Confirm everything works

Open any folder in VS Code (it does not need to be a report folder).
Open Copilot Chat and ask:

```
What is Zone C and its coordinates?
```

Expected answer: `y:136 to 1066, x:28 to 2535`

If that answers correctly without any extra setup — you are fully configured.
AgentAdam's rules are now loading automatically in every session.

You can also confirm the plugin skills are registered:
```
Ctrl+Shift+X → look for Agent Plugins - Installed → confirm "agentadam" is there
```

---

## Every session

This is the whole thing:

```
1. Open VS Code
2. Open your report folder (File → Open Folder)
3. Talk to Copilot
```

AgentAdam's rules are already loaded. You do not need to run any commands
or type any startup sequence. Just start working.

---

## Before you build — every session

Two things AgentAdam cannot do for you:

```
1. Close Power BI Desktop completely (not minimised — closed)
   The agent edits files directly. Desktop will overwrite its work if open.

2. Take a backup of your report folder
   Copy the folder, paste it, rename with today's date.
   If something goes wrong and you have no backup, work is lost.
```

---

## Your report must be .pbip — not .pbix

AgentAdam cannot read .pbix files. Convert first if needed:

```
File → Save as → Power BI Project (.pbip)
Options → Preview features → Enhanced metadata format (PBIR)
Save and close Desktop
```

---

## What you can ask AgentAdam to do

```
"Build a sales report for a mixed audience..."    pages, visuals, bookmarks
"Write a measure for year-over-year growth"       DAX to our standards
"Review this SQL before I import it"              plain-English SQL review
"Review my semantic model"                        read-only health check
"Document this report"                            handover documentation
```

The agent always presents a plan and waits for your approval before
changing anything. It never publishes — you always publish manually in Desktop.

---

## When AgentAdam updates

```
Core rules update (Adam edits the SharePoint file)
  → your machine syncs automatically via OneDrive
  → takes effect in your next VS Code session
  → you do not need to do anything

Plugin skills update (Adam pushes to GitHub)
  → your plugin updates automatically within 24 hours
  → or immediately: Ctrl+Shift+P → Extensions: Check for Extension Updates
```

---

## If you get stuck

```
Zone C question gives wrong answer?
  Check step 7 — the path in your settings.json must exactly match
  your File Explorer path — it should be:
  ~/IBERDROLA S.A/UK Operations - Agentic BI - AgentAdam
  After fixing: Ctrl+Shift+P → Developer: Reload Window

SharePoint folder not showing in File Explorer?
  Open the OneDrive sync client (system tray icon)
  Check you are signed in and syncing
  Try the Sync button in the SharePoint browser again

Git error when installing plugin ("spawn git ENOENT")?
  Git is not installed — see step 1

Plugin not appearing in Extensions?
  Ctrl+Shift+P → Developer: Reload Window
  Check chat.plugins.enabled is true

Anything else?
  Ask Adam — no question is too small during the pilot.
```

---

## The five-second summary

```
Once:     Git check, VS Code, Copilot, plugin, SharePoint sync, one setting
Always:   Open VS Code, open your report, close Desktop, take a backup, work
Never:    Publish via agent, use .pbix, fix things manually in Desktop
```

---

*AgentAdam — SP Customer Business · COE Data Governance & Visualisation*
*Built on data-goblin by Kurt Buhler. Questions → Adam McLean.*
