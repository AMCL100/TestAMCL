# AgentAdam VS Code Extension — Owner Guide

> **For:** Adam McLean · How to maintain, update, and repackage the extension.

---

## What the extension contains

```
agentadam-vscode/
  package.json          extension manifest (name, version, contributes)
  extension.js          registers the webview panel, handles clipboard
  media/
    panel.html          the full sidebar UI — all tabs, logic, styles
    icon.svg            the green A in the Activity Bar
  LICENSE.txt
  README.md
```

The entire UI lives in `media/panel.html`. It is a self-contained HTML
file with all CSS and JavaScript inline. No build step, no bundler, no
npm dependencies to maintain.

---

## How to update the content

### Adding or changing a starter prompt
Open `media/panel.html` and find the prompt you want to change.
Prompts look like this:

```html
<div class="prompt-card"
  onclick="copyPrompt('b1','Your prompt text here')"
  id="pc-b1">
  <span class="prompt-text">Your prompt text here</span>
  <span class="prompt-copy">Copy</span>
</div>
```

Change the text in both the `onclick` argument and the `prompt-text` span.
Keep the `id` and the key (`b1`, `b2` etc.) — these are just identifiers.

### Adding or changing a Will/Won't Do item
Find the `ww-card` div for the tab you want and edit the text:

```html
<div class="ww-item">
  <span style="color:#4ec94e">✓</span>Your updated text here
</div>
```

### Updating zone coordinates or colours
Find the Reference tab section (`id="page-ref"`) and update the
`.zone-item` or `.colour-row` entries directly.

### Changing the version number
Edit `package.json` — the `"version"` field. Use semantic versioning:
- Bug fixes and text changes → patch (1.0.0 → 1.0.1)
- New tab or feature → minor (1.0.0 → 1.1.0)
- Major redesign → major (1.0.0 → 2.0.0)

---

## How to repackage after making changes

You need Node.js and vsce installed. On the machine where you built it:

```
1. Open a terminal
2. Navigate to the extension folder:
   cd path\to\agentadam-vscode

3. If vsce is not installed:
   npm install -g @vscode/vsce

4. Package:
   vsce package --no-dependencies --allow-missing-repository

5. A new .vsix file appears in the folder
   e.g. agentadam-1.0.1.vsix

6. Share the new .vsix with the team via Teams
```

---

## How to test before sharing

Before packaging and sending to the team, test locally:

```
1. Open VS Code
2. Press Ctrl+Shift+X → ... → Install from VSIX
3. Select the new .vsix
4. Reload VS Code
5. Click the green A icon and test every tab:
   - All prompts copy correctly
   - Session checklist checkboxes work
   - Litmus test copies work
   - Reference tab shows correct coordinates
6. If anything is wrong, edit panel.html and repackage
```

---

## How to uninstall (for clean reinstall)

```
Ctrl+Shift+X → search "AgentAdam" → click the gear icon → Uninstall
Reload VS Code
Then install the new version from VSIX
```

---

## Architecture notes

The extension uses VS Code's WebviewViewProvider API to show a sidebar panel.

When the user clicks "Copy" on a prompt, the webview sends a message to
`extension.js` which uses `vscode.env.clipboard.writeText()` — the proper
VS Code clipboard API that works reliably on all platforms.

The `retainContextWhenHidden: true` option means the panel keeps its state
(including which checkboxes are ticked) when the user switches to another
activity bar item and comes back.

There are no external dependencies, no bundler, no transpilation, no npm
install needed. The extension works from the raw source files.

---

## File locations once installed

VS Code installs extensions to:
```
C:\Users\[username]\.vscode\extensions\sp-customer-business.agentadam-1.0.0\
```

If you need to make a quick edit without repackaging, you can edit the
`panel.html` file directly in that location and reload VS Code. Use this
for urgent fixes only — always update the source and repackage properly.

---

## Roadmap ideas captured

```
Auto-send prompt to Copilot Chat    (needs VS Code API research)
Live SharePoint sync timestamp      (check file modified time)
Planning template inline            (add a new tab)
Model evaluation quick-launch       (add a prompt to Model tab)
```

---

*Extension source lives alongside the AgentAdam repo.*
*Questions about this guide → that's me.*
