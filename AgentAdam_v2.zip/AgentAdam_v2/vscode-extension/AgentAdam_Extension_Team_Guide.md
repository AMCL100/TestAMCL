# AgentAdam VS Code Extension — Team Guide

> **Version:** 1.0.0 · **Owner:** Adam McLean · **Internal use only**
> A sidebar panel that puts AgentAdam's capabilities, prompts, and
> reference material one click away while you work.

---

## Install — do this once

### Step 1 — Download the extension
Get `agentadam-1.0.0.vsix` from Adam (Teams or SharePoint).

### Step 2 — Install in VS Code
```
1. Open VS Code
2. Press Ctrl+Shift+X  (Extensions panel)
3. Click the ...  menu in the top-right of the Extensions panel
4. Click "Install from VSIX..."
5. Find and select agentadam-1.0.0.vsix
6. Click Reload when VS Code prompts you
```

### Step 3 — Find the panel
Look for the green **A** icon in the Activity Bar on the far left of VS Code.
Click it to open the AgentAdam sidebar panel.

---

## What each tab does

**▶ Session — start here every time**
Three checkboxes to tick off before every build session:
- Desktop fully closed (not minimised)
- Backup taken
- Report saved as .pbip

When all three are ticked, a green "Ready to build" message appears.
The Build tab will warn you if you skip the checklist.

**⬡ Build — Edit & Build Report**
Starter prompts for building pages, visuals, and bookmarks.
Click any prompt to copy it, then paste into Copilot Chat.

**◈ Model — Review Semantic Model**
Read-only health check prompts.
Also shows the three gating questions the agent asks before starting.

**⟨⟩ SQL — Review SQL**
Prompts for SQL review against Synapse best practice.

**ƒ DAX — Write DAX**
Prompts for writing and reviewing DAX measures to AgentAdam standards.

**☰ Docs — Generate Documentation**
Prompts for handover docs, measure catalogues, and data lineage.

**✓ Litmus — verify the agent is loaded**
Six test questions. Click any to copy, paste into Copilot Chat,
and confirm the answer matches. If it does, your standards are loaded.

**⊞ Reference — quick lookup**
Zone A/B/C coordinates, slicer widths, and all eight brand colours.
Keep this open when placing visuals or building layouts.

---

## How to use the prompts

```
1. Click a prompt in the panel  →  it copies to your clipboard
2. Switch to Copilot Chat (Ctrl+Alt+I)
3. Paste (Ctrl+V) and press Enter
4. Replace any [placeholder text] with your actual values first
```

---

## Updates

When Adam releases a new version, he'll share a new .vsix file via Teams.
Install the new version the same way — VS Code replaces the old one.

---

## Troubleshooting

```
Green A icon not visible in the Activity Bar?
  Right-click the Activity Bar → tick AgentAdam to enable it
  Or Ctrl+Shift+P → "AgentAdam: Open Panel"

Panel shows but prompts don't copy?
  Make sure GitHub Copilot is installed and you're signed in
  Try reloading: Ctrl+Shift+P → Developer: Reload Window

Wrong version installed?
  Ctrl+Shift+X → search "AgentAdam" → check the version number
  Uninstall and reinstall from the latest .vsix if needed
```

---

*Questions → Adam McLean · COE Data Governance & Visualisation*
