# pbir CLI; Complete Command Reference

Complete command reference for the pbir CLI. All commands prefixed with `pbir`.

## Table of Contents
- [Navigation and Discovery](#navigation-and-discovery)
- [Property Management](#property-management)
- [Report Creation and Management](#report-creation-and-management)
- [Page Operations](#page-operations)
- [Visual Operations](#visual-operations)
- [Theme Operations](#theme-operations)
- [Color Operations](#color-operations)
- [Font Operations](#font-operations)
- [DAX Operations](#dax-operations)
- [Field Operations](#field-operations)
- [Filter Operations](#filter-operations)
- [Bookmark Operations](#bookmark-operations)
- [Annotation Operations](#annotation-operations)
- [Best Practice Analyzer (BPA)](#best-practice-analyzer-bpa)
- [Connection and Fabric](#connection-and-fabric)
- [Desktop Operations (Windows)](#desktop-operations-windows)
- [Usage Metrics](#usage-metrics)
- [Batch Automation](#batch-automation)
- [Configuration and Setup](#configuration-and-setup)
- [Visual Types Reference](#visual-types-reference)

---

## Navigation and Discovery

```bash
# List reports in base directory
pbir ls                                          # All reports with counts
pbir ls --tree                                   # All reports with tree structure
pbir ls "Report.Report"                          # Contents of a report (pages, filters, theme)
pbir ls "Report.Report/Page.Page"                # Visuals on a page

# Tree structure (pbir ls --tree is the canonical form; pbir tree is a retained alias)
pbir ls "Report.Report" --tree                   # Hierarchical view (-T short flag)
pbir ls "Report.Report" --tree -v                # Verbose: include field bindings per visual
pbir tree "Report.Report" -v                     # Equivalent alias

# Display JSON content
pbir cat "Report.Report/Page.Page"               # Page JSON
pbir cat "Report.Report/Page.Page/Visual.Visual"  # Visual JSON
pbir cat "Report.Report/reportExtensions"         # reportExtensions.json
pbir cat "Report.Report/ThemeName.Theme"          # Theme JSON

# Find by glob pattern
pbir find "*.Report"                             # All reports
pbir find "Report.Report/**/*.Visual"            # All visuals in report
pbir find "**/*card*.Visual"                     # All card-named visuals
pbir find "**/*.Visual" --type visual --count    # Count all visuals
pbir find "**/*.Page" --json                     # JSON output
```

## Property Management

```bash
# Get properties
pbir get "Report.Report"                                          # Report properties
pbir get "Report.Report/Page.Page"                                # Page properties
pbir get "Report.Report/Page.Page/Visual.Visual"                  # Visual properties (all)

# Set properties (supports glob patterns for bulk)
pbir set "Report.Report/Page.Page/Visual.Visual.title.text" --value "Revenue"
pbir set "Report.Report/Page.Page/Visual.Visual.title.fontSize" --value 14
pbir set "Report.Report/**/*.Visual.title.show" --value false -f  # Glob: all visuals
pbir set "Report.Report/**/*.Visual.border.show" --value true -f  # Glob: all borders
pbir set "path" --property "background.color" --value "#F0F0F0"   # Alternative syntax
pbir set "path" --json '{"title": {"show": true, "text": "Sales"}}'  # JSON input; accepts what `pbir get --json` returns
pbir set "path.title.text" --value "Draft" --dry-run             # Preview; never writes

# Discover properties
pbir visuals properties "Report.Report/Page.Page/Visual.Visual"   # Tree view of all properties
pbir visuals format "Report.Report/Page.Page/Visual.Visual"       # Merged theme + visual values
```

## Report Creation and Management

```bash
# Create new report
pbir new report "Sales.Report" -c "MyWorkspace/Sales.SemanticModel"
pbir new report "Sales.Report" --from-template my-dashboard
pbir new report --list-templates

# Rebind to different model
pbir report rebind "Report.Report" "Workspace/Model.SemanticModel"

# Format conversion
pbir report convert "Report.Report" -F pbix      # Convert to PBIX
pbir report convert "Report.Report" -F pbip      # Convert to PBIP

# Merge and split
pbir report merge "R1.Report" "R2.Report" -o "Combined.Report"
pbir report merge-to-thick "Report.Report" "Model.SemanticModel"
pbir report split-pages "Report.Report" -o ./split
pbir report split-from-thick "ThickReport" --target "Workspace/Model"

# Copy
pbir cp "Source.Report" "Target.Report"                   # Copy report
pbir cp "Source.Report" "Target.Report" --format pbix     # Copy and convert

# Delete
pbir rm "Report.Report/Page.Page" -f              # Remove page
pbir rm "Report.Report/Page.Page/Visual.Visual" -f  # Remove visual
pbir rm "Report.Report/filter:Name" -f             # Remove filter
pbir rm "Report.Report/bookmark:Name" -f           # Remove bookmark
pbir rm "Report.Report" --measures -f              # Remove all extension measures
pbir rm "Report.Report" --theme -f                 # Remove custom theme
pbir rm "Report.Report" --annotations -f           # Remove all annotations
pbir rm "Report.Report" --all -f                   # Remove filters+bookmarks+annotations

# Rename and link to a published report
pbir report rename "Report.Report" "Q4 Sales Dashboard"   # Renames folder + .platform displayName (--no-rename-folder to keep folder)
pbir report link "Report.Report"                          # Show the local report's link to its published copy
pbir report link "Report.Report" "Sales.Workspace/Exec.Report"  # Set the link (used by pbir usage; set automatically by download/publish/connect)
pbir report unlink "Report.Report"                        # Remove the link

# Other
pbir report clear-diagram "Report.Report"          # Delete diagram layout
pbir open "Report.Report"                          # Open in Power BI Desktop
pbir validate "Report.Report"                      # Validate structure
```

`report link` records the published identity locally (never in the report definition); `pbir usage` and other remote commands read it to skip re-resolving. It differs from `report rebind`, which re-points a report at a different model.

## Page Operations

```bash
# Add page
pbir add page "Report.Report/Dashboard.Page" -n "Dashboard"
pbir add page "Report.Report/Overview.Page" -n "Overview" --width 1920 --height 1080
pbir add page "Report.Report/Page.Page" --from-template executive-dashboard
pbir add page --list-templates

# Rename and move
pbir pages rename "Report.Report/Old.Page" --to "New Name" -f   # Single-page rename; new name via --to
pbir pages move "Report.Report/Sales.Page" --to 1

# Resize and type
pbir pages resize "Report.Report/Page.Page" --width 1920 --height 1080
pbir pages type "Report.Report/Page.Page" --type 16:9    # Also: 4:3, letter, tooltip, custom
pbir pages display "Report.Report/Page.Page" -o FitToWidth   # FitToPage, FitToWidth, ActualSize

# Visibility
pbir pages hide "Report.Report/Page.Page"                 # Hide in view mode
pbir pages hide "Report.Report/Page.Page" --show           # Show (unhide)

# Styling
pbir pages background "Report.Report/Page.Page" --image bg.png    # Canvas background image (--scaling Fit|Fill, --transparency); color lives on wallpaper
pbir pages wallpaper "Report.Report/Page.Page" --color "#2B579A"  # Outspace/wallpaper color (or --image)

# Active page and interactions
pbir pages active-page "Report.Report" "HomePage"
pbir pages interactions "Report.Report/Page.Page"          # List/set visual interactions (cross-filter/highlight/none)
pbir pages interactions "Report.Report/Page.Page" --source "Slicer_Region,Slicer_Year" --target "Card_Sales,Card_Orders" --type NoFilter   # Every source-target pair in one call
pbir pages json "Report.Report/Page.Page"                  # Raw page JSON

# Drillthrough, tooltip pages, and theme conformance
pbir pages drillthrough "Report.Report/Details.Page" --table Products --field Category  # Add a drillthrough field (--cross-report, --show, --clear)
pbir pages set-tooltip "Report.Report/Tooltip.Page" --width 400 --height 300            # Make a page a tooltip page (--clear to revert)
pbir pages conform "Report.Report/Page.Page" --properties title,background --force --no-dry-run  # Conform visuals to the theme (dry-run by default)

# Copy/move between reports
pbir cp "R1.Report/Page.Page" "R2.Report/NewPage.Page"
pbir mv "R1.Report/Page.Page" "R2.Report/Page.Page"
```

## Visual Operations

### Creation

```bash
# Single visual
pbir add visual card "Report.Report/Page.Page" --title "Revenue"
pbir add visual card "Report.Report/Page.Page" -d "Values:Sales.Revenue" --x 100 --y 50
pbir add visual lineChart "Report.Report/Page.Page" --title "Trend" --width 600 --height 400
pbir add visual tableEx "Report.Report/Page.Page" --title "Detail"
pbir add visual kpi "Report.Report/Page.Page" -d "Indicator:Sales.Revenue"
pbir add visual --list                            # List all 50+ visual types with data roles

# Role names match the visual list (Values, Category, Y, Series, Indicator, ...).
# The CLI matches role names case-insensitively, so lowercase also works.

# Import a pre-existing bulk-creation spec; do not edit report JSON directly
pbir add visual "Report.Report/Page.Page" --from-json visuals.json
# JSON format: [{"visual_type": "card", "x": 0, "y": 0, "title": "Sales", "fields": {"Values": "Sales.Revenue"}}]

# Title/subtitle textboxes
pbir add title "Report.Report/Page.Page" "Sales Dashboard"
pbir add subtitle "Report.Report/Page.Page" "Q4 2025 Performance"
```

### Position and Layout

```bash
# Position and size
pbir visuals position "Visual.Visual" --x 100 --y 50 --width 400 --height 300
pbir visuals resize "Visual.Visual" --width 400 --height 300

# Alignment (multiple visuals)
pbir visuals align "Report.Report/Page.Page" left Visual1 Visual2 Visual3
pbir visuals align "Report.Report/Page.Page" top Visual1 Visual2
pbir visuals align "Report.Report/Page.Page" distribute-horizontal V1 V2 V3

# Z-order, snap, mobile
pbir visuals z-order "Visual.Visual"             # View/manage layer stacking
pbir visuals snap "Visual.Visual"                # Snap to grid
pbir visuals mobile "Visual.Visual"              # Get/set mobile layout

# Visual groups (scale/position multiple visuals together)
pbir visuals group "Report.Report/Page.Page" --list
pbir visuals group "Report.Report/Page.Page" --create "KPI Group"
pbir visuals group "Report.Report/Page.Page/KPI Group.Visual" --add "Card.Visual" --add "KPI.Visual"
pbir visuals group "Report.Report/Page.Page/KPI Group.Visual" --remove "Card.Visual"
pbir visuals group "Report.Report/Page.Page/Visual.Visual" --ungroup     # Remove visual from its group
pbir visuals group "Report.Report/Page.Page/KPI Group.Visual" --ungroup  # Delete group, free members

# Style presets (curated formatting bundles)
pbir visuals preset --list                                               # minimal, bold, clean, emphasis, presentation
pbir visuals preset "Report.Report/Page.Page/Visual.Visual" --name minimal
pbir visuals preset "Report.Report/**/*.Visual" --name presentation
```

### Container Formatting (all visual types)

```bash
# Title and subtitle
pbir visuals title "Visual.Visual" --text "Title" --show --fontSize 14 --fontColor "#333"
pbir visuals title "Visual.Visual" --bold --alignment center
pbir visuals subtitle "Visual.Visual" --text "Subtitle" --show

# Background, border, shadow
pbir visuals background "Visual.Visual" --color "#FFFFFF" --transparency 0
pbir visuals border "Visual.Visual" --show --color "#E0E0E0" --radius 8 --width 1
pbir visuals shadow "Visual.Visual" --show       # Drop shadow

# Padding and spacing
pbir visuals padding "Visual.Visual" --top 10 --bottom 10 --left 10 --right 10
pbir visuals spacing "Visual.Visual"             # Component spacing
pbir visuals divider "Visual.Visual" --show      # Title/subtitle divider

# Header and tooltip
pbir visuals header "Visual.Visual" --show       # Visual header icons
pbir visuals tooltip "Visual.Visual"             # Tooltip configuration
pbir visuals general "Visual.Visual"             # General properties

# Visibility and presets
pbir visuals hide "Visual.Visual"                # Hide visual
pbir visuals hide "Visual.Visual" --show         # Show visual
pbir visuals preset "Visual.Visual"              # Apply style presets

# Clear formatting (reset to theme defaults)
pbir visuals clear-formatting "Report.Report/**/*.Visual" -f          # All visuals in report
pbir visuals clear-formatting "Report.Report/Page.Page/*.Visual" -f   # All on page
pbir visuals clear-formatting "Visual.Visual"                         # Single visual
pbir visuals clear-formatting "Report.Report/**/*.Visual" --only-containers -f  # VCO only (safe, keeps CF)
pbir visuals clear-formatting "Report.Report/**/*.Visual" --keep-cf -f         # Keep CF entries
pbir visuals clear-formatting "Report.Report/**/*.Visual" --dry-run            # Preview changes
```

### Chart-Specific Formatting

```bash
# Legend (22 visual types)
pbir visuals legend "Visual.Visual" --show --position Right

# Axes
pbir visuals axis "Visual.Visual" category --show --title "Category"
pbir visuals axis "Visual.Visual" value --show --title "Amount"

# Data labels (22 visual types)
pbir visuals labels "Visual.Visual" --show --fontSize 10

# Sorting
pbir visuals sort "Visual.Visual" -f "Sales.Revenue" -d Descending
pbir visuals sort "Visual.Visual" --remove

# Reference lines (add creates the entry; style it via pbir set with id())
pbir visuals reference-line add "Visual.Visual" --value 100        # Constant line; --value also accepts a field ref
pbir visuals reference-line list "Visual.Visual"
pbir visuals reference-line remove "Visual.Visual" --id 1
pbir set "Visual.Visual.y1AxisReferenceLine.id(1).displayName" --value "Target"   # Style after creation
# `add` is NOT idempotent (each call appends); it prints the new id to stdout for chaining: ID=$(pbir visuals reference-line add ...)

# Error bars (upsert per series; style via pbir set with field())
pbir visuals error-bars add "Visual.Visual" --series "Sales.Revenue" --upper "Sales.Target" --lower "Sales.Target"
pbir visuals error-bars list "Visual.Visual"
pbir visuals error-bars remove "Visual.Visual" --series "Sales.Revenue"
pbir set "Visual.Visual.error.field(Sales.Revenue).markerShape" --value "diamond"  # Style after creation
```

### Data Binding

```bash
# Show current bindings and available roles
pbir visuals bind "Visual.Visual" --show
pbir visuals bind "Visual.Visual" --list-roles

# Add fields
pbir visuals bind "Visual.Visual" -a "Values:Sales.Revenue"
pbir visuals bind "Visual.Visual" -a "Category:Products.Category" -t Column
pbir visuals bind "Visual.Visual" -a "Values:Sales.TotalSales" -t Measure

# Remove and clear
pbir visuals bind "Visual.Visual" -r "Values:Sales.Revenue"
pbir visuals bind "Visual.Visual" -c "Values"    # Clear entire role

# Field-well behavior
pbir visuals show-all "Visual.Visual" --role Category               # Show empty subcategory rows (--off to disable)
pbir visuals field-hidden "Visual.Visual" --role Y --field "Sales.Revenue"  # Hide a bound field in the field well (--show to reveal); stays bound and active

# Click action (buttons, shapes, images)
pbir visuals action "Visual.Visual" --type PageNavigation --target "Details"  # Also: WebUrl, Bookmark, Back, Drillthrough, Q&A
pbir visuals action "Visual.Visual" --show                          # Inspect current action
pbir visuals action "Visual.Visual" --clear
```

### Conditional Formatting

Two surfaces share one model:

- **`pbir set` / `pbir get`**. dot-path reads and scalar edits on existing CF entries.
- **`pbir visuals cf`**. structural authoring (create, copy, convert).

```bash
# Create measure-based CF (structural. stays on `visuals cf`)
pbir visuals cf "Visual.Visual" --measure "labels.color _Fmt.StatusColor"
pbir visuals cf "Visual.Visual" --measure "dataPoint.fill _Fmt.BarColor"

# Read CF via pbir get (.cf tail)
pbir get "Visual.Visual.dataPoint.fill.cf"                              # ASCII summary
pbir get "Visual.Visual.dataPoint.fill.cf.gradient.min.color"           # scalar leaf
pbir get "Visual.Visual.dataPoint.fill.cf" --json                       # raw JSON
pbir get "Report.Report/**/*.Visual.**.cf"                              # bulk read

# Edit CF leaves via pbir set
pbir set "Visual.Visual.dataPoint.fill.cf.gradient.min.color" --value "bad"
pbir set "Visual.Visual.dataPoint.fill.cf.gradient.max.value" --value 250
pbir set "Visual.Visual.labels.color.cf.rules.case[0].color" --value "alertRed"
pbir set "Visual.Visual.labels.color.cf.rules.else.color"   --value "foreground"
pbir set "Visual.Visual.dataPoint.fill.cf.measure"          --value "_Fmt.NewColor"

# Remove CF (aliases: --remove / --clear)
pbir set "Visual.Visual.dataPoint.fill.cf" --remove
pbir set "Visual.Visual.**.cf" --remove -f                              # bulk wipe

# Per-field / per-series / interaction-state selectors compose with .cf
pbir set "Visual.Visual.values.field(Sales.Revenue).fontColor" --value "#118DFF"
pbir set "Visual.Visual.dataPoint.series(Cities.City=Antwerp).fill" --value "#E66C37"
pbir set "Visual.Visual.y1AxisReferenceLine.id(2).lineColor" --value "#FF0000"
pbir set "Visual.Visual.labels.hover.fontColor" --value "#E3F2FD"

# Convert / copy / theme-tokenize (structural. retained on `visuals cf`)
pbir visuals cf "Visual.Visual" --theme-colors "dataPoint.fill"             # Hex -> theme tokens
pbir visuals cf "Visual.Visual" --to-measure dataPoint.fill                 # Convert to extension measure
pbir visuals cf "Target.Visual" --copy-from "Source.Visual"                 # Copy CF between visuals

# Note: the former `pbir visuals cf --info`/`--list`/`--has`/`--set-color`/
# `--remove`/`--remove-all` flags and the `pbir visuals format-field` /
# `format-state` commands no longer exist (removed in 0.9.30; listed in
# `pbir context` under migration-1.0). Use the `pbir get`/`pbir set` forms above.
```

### Custom Visuals

```bash
# Script injection
pbir visuals deneb "Visual.Visual" --spec-file chart.json
pbir visuals python "Visual.Visual" --script-file script.py
pbir visuals r "Visual.Visual" --script-file script.r

# Query extraction and testing
pbir visuals query "Visual.Visual"               # Extract DAX query
pbir visuals test "Visual.Visual"                # Performance test

# Raw JSON
pbir visuals json "Visual.Visual"                # Raw visual.json
```

## Theme Operations

```bash
# Inspection
pbir cat "Report.Report/theme"                  # Full theme JSON
pbir theme colors "Report.Report"                # Palette: analyze, normalize, bind literals to the theme
pbir theme fonts "Report.Report"                 # Show the theme's fonts per level (title, label, callout, header, ...)
pbir theme validate "Report.Report"              # Validate theme structure

# Modification
pbir theme set-colors "Report.Report" --good "#00B050" --bad "#FF0000"
pbir theme set-fonts "Report.Report" title --font-size 14 --font-face "Segoe UI Semibold"  # Theme fonts per level
pbir theme set-formatting "Report.Report" "card.*.title.fontSize" --value 14   # Wildcard or per-visual-type
pbir theme push-visual "Visual.Visual"           # Push visual formatting to theme defaults or a named preset
pbir theme background "Report.Report" --image bg.png
pbir theme icons "Report.Report" --set custom-icon --url "data:image/svg+xml;utf8,..."
pbir theme rename "Report.Report" "NewThemeName"

# Import/export only; do not hand-edit serialized theme JSON
pbir theme serialize "Report.Report" -o CustomTheme.Theme    # Read-only export for inspection
pbir theme build "Provided.Theme"                            # Build a user-provided theme folder

# Templates
pbir theme list-templates
pbir theme apply-template "Report.Report" sqlbi
pbir theme create-template --new-template my-theme.json --name my-theme   # Register a theme JSON file as a template
```

## Color Operations

`pbir color` audits and replaces a color across the whole report AND its theme in one pass: visual properties, the visual container, page/canvas background, conditional-formatting stops/cases, and the theme palette.

```bash
pbir color list "Report.Report"                                        # Audit: distinct colors + usage counts (report + theme)
pbir color replace "Report.Report" --from "#FF0000" --to "#00FF00"     # Preview the replacement (default is dry-run)
pbir color replace "Report.Report" --from "#FF0000" --to "#00FF00" -f  # Apply everywhere (--force)
pbir color replace "Report.Report" --from "#FF0000" --to "#00FF00" --theme   # Scope to the theme palette only
pbir color replace "Report.Report" --from "#FF0000" --to "#00FF00" --report  # Scope to report colors only (not theme)
```

`color replace` previews unless `-f/--force` is given. `--theme` and `--report` scope the pass; default touches both. `-j/--json` for machine-readable output. For palette/token edits prefer `pbir theme set-colors`; use `color replace` for a literal hex sweep across report + theme.

## Font Operations

`pbir fonts` is the typography mirror of `pbir color`: audit and replace font families across the whole report AND theme (text classes + visualStyles) in one pass, and clear per-visual font/format overrides so the theme default applies.

```bash
pbir fonts list "Report.Report"                                        # Audit: families, sizes, weights, styles (report + theme)
pbir fonts available                                                   # Built-in Power BI font families
pbir fonts replace "Report.Report" --from "Calibri" --to "Segoe UI"    # Preview the family swap (default is dry-run)
pbir fonts replace "Report.Report" --from "Calibri" --to "Segoe UI" -f # Apply everywhere (--theme / --report to scope)
pbir fonts clear "Report.Report" --size --weight -f                    # Drop size + bold overrides so the theme default wins
pbir fonts clear "Report.Report" --all -f                              # Clear family/size/weight/style/display-units/decimals/format
pbir fonts clear "Report.Report/Page.Page/Visual.Visual" --family -f   # Scope to a page or visual via the path
```

`fonts clear` (alias `fonts reset`) only removes overrides from visuals/pages; it never edits theme.json. `clear` flags: `--family`, `--size`, `--weight`, `--style`, `--display-units`, `--decimals`, `--format`, `--all`. To author the THEME's own fonts instead, use `pbir theme set-fonts` / `pbir theme fonts`.

## DAX Operations

```bash
# Extension measures (thin report measures in reportExtensions.json)
pbir dax measures list "Report.Report"
pbir dax measures add "Report.Report" -t _Measures -n "YoY Growth" \
  -e 'DIVIDE([Sales]-[PY Sales],[PY Sales])' --data-type Double
pbir dax measures add "Report.Report" -t _Fmt -n "StatusColor" \
  -e 'IF([Sales]>[Target],"good","bad")' --data-type Text
pbir dax measures update "Report.Report" "YoY Growth" -e '<new expression>'  # edit an existing measure
pbir dax measures rename "Report.Report" "OldName" "NewName"
pbir rm "Report.Report" --measure "MeasureName" -f         # remove ONE measure
pbir dax measures clear "Report.Report" -f                 # remove ALL measures (destructive); --table to scope, --dry-run to preview
pbir dax measures json "Report.Report"

# Visual calculations (inline DAX on visuals)
pbir dax viscalcs list "Report.Report"
pbir dax viscalcs add "R.Report/P.Page/V.Visual" -n "Running Total" \
  -e "RUNNINGSUM([Revenue])"
pbir dax viscalcs update "R.Report/P.Page/V.Visual" "Running Total" -e "<new expression>"  # edit existing
pbir dax viscalcs rename "R.Report/P.Page/V.Visual" "OldName" "NewName"
pbir rm "R.Report/P.Page/V.Visual" --viscalc "CalcName" -f  # remove ONE viscalc
pbir dax viscalcs clear "R.Report/P.Page/V.Visual" -f       # remove ALL viscalcs (destructive); --dry-run to preview
pbir dax viscalcs json "R.Report/P.Page/V.Visual"
```

## Field Operations

```bash
pbir fields list "Report.Report"                              # All unique fields with types
pbir fields list "Report.Report/Page.Page"                    # Fields on a page
pbir fields find "Revenue" "Report.Report"                    # Fuzzy search with locations
pbir fields where-used "Report.Report" "Sales.Revenue"        # Every known location that references a field (--contains for substring)
pbir fields replace "Report.Report" --from "Sales.Revenue" --to "Finance.Revenue"   # Repoint a field everywhere
pbir fields replace-table "Report.Report" --from "f_invoices" --to "Invoices"        # Rename a TABLE across all references (--dry-run)
pbir fields rename "Report.Report" "Sales.Revenue" "Total Sales"   # Set a field's display name (--list to view, --clear to reset)
pbir fields add "Report.Report/Page.Page/Visual.Visual" --bucket Values --field Sales.Revenue
```

## Filter Operations

```bash
# Management
pbir filters list "Report.Report"
pbir filters set "Report.Report/Date.Year.Filter" --values 2024 --values 2025   # Repeat --values per value (not comma-separated)
pbir filters set "Report.Report/Date.Date.Filter" --type RelativeDate
pbir filters clear "Report.Report/Date.Year.Filter"
pbir filters rename "Report.Report" "OldName" "New Display Name"
pbir filters json "Report.Report"

# Visibility and locking
pbir filters hide "Report.Report/Filter.Filter"
pbir filters lock "Report.Report/Filter.Filter"
pbir filters unlock "Report.Report/Filter.Filter"

# Creation
pbir add filter Date Year -r "Report.Report"
pbir add filter Products Category -p "Report.Report/Page.Page" --values Electronics
pbir add filter Date Date -r "Report.Report" --type RelativeDate

# Filter pane management
pbir filters pane-hide "Report.Report"
pbir filters pane-collapse "Report.Report"
pbir filters pane-get "Report.Report"
pbir filters pane-set "Report.Report" --width 320
pbir filters pane-card "Report.Report" -s Applied --bg-color "#E3F2FD"
```

## Bookmark Operations

```bash
pbir bookmarks list "Report.Report"
pbir bookmarks rename "Report.Report" "OldName" "NewName"
pbir bookmarks data "Report.Report" "BookmarkName"           # Show data state
pbir bookmarks data "Report.Report" "BookmarkName" --off     # Don't capture filters
pbir bookmarks display "Report.Report" "BookmarkName" --off  # Don't capture visibility
pbir bookmarks current-page "Report.Report" "BookmarkName" --off
pbir bookmarks visuals "Report.Report" "BookmarkName" --all
pbir bookmarks json "Report.Report"
```

## Annotation Operations

```bash
pbir annotations list "Report.Report"
pbir cat "Report.Report/annotations"                  # Report + pages + visuals
pbir annotations update "Report.Report" key "value"
pbir annotations rename "Report.Report" old-key new-key
pbir add annotation "Report.Report" --name version --value "1.0"
```

## Best Practice Analyzer (BPA)

```bash
# Run BPA over a report
pbir bpa run "Report.Report"
pbir bpa run "Report.Report" --fail-on error -o json   # CI-friendly, exit code follows severity
pbir bpa run "Report.Report" --fix --save              # Apply automatically-safe fixes in place

# Manage rules
pbir bpa rules list                                    # All rules with IDs and severities
pbir bpa rules ignore PBIR_DROP_SHADOW "Report.Report"
pbir bpa rules unignore PBIR_DROP_SHADOW "Report.Report"
```

Pair `pbir validate` (schema and structure) with `pbir bpa run` (design and layout rules). See `references/bpa.md` for the full workflow.

## Connection and Fabric

```bash
# Connection management
pbir connect "Report.Report"                     # Connect to local report
pbir connect MyWorkspace MyReport                # Connect to remote
pbir connect                                     # Show current connection
pbir connect --clear                             # Disconnect
pbir connect --profile dev                       # Activate saved profile

# Profiles
pbir profile list
pbir profile save dev --description "Dev workspace"
pbir profile show dev
pbir profile remove dev

# Cloud operations (requires fab CLI auth)
pbir download "Workspace.Workspace"                              # List reports in workspace
pbir download "Workspace.Workspace/Report.Report" -o ./output    # Download report
pbir download "Workspace.Workspace/Report.Report" -o ./output -F pbip  # Download as PBIP
pbir publish "Report.Report" "Workspace/Report"

# Model queries
pbir model                                       # List all reports and models
pbir model "Report.Report"                       # Show workspace/model info
pbir model "Report.Report" -d                    # Get model definition
pbir model "Report.Report" -d -t Sales           # Filter to table
pbir model "Report.Report" -d -v                 # Full TMDL
pbir model "Report.Report" -q "EVALUATE VALUES('Sales'[Region])"
pbir model "Report.Report" -q "EVALUATE 'Sales'" -F json  # JSON output
```

Model query routing: thin reports (`byConnection`) query the Power BI / Fabric service (EVALUATE DAX only; DMVs rejected). Thick reports (`byPath`) open in Power BI Desktop query the local Analysis Services engine; requires the .NET Framework ADOMD client (auto-detected from DAX Studio or Desktop installs; override with `PBIR_ADOMD_DIR`).

## Desktop Operations (Windows)

Requires Power BI Desktop running with the report open and the preview feature "Enable external tool access to Power BI Desktop through secure local APIs" enabled.

```bash
pbir desktop list                                # Running instances (PID, open file, unsaved state, pages)
pbir desktop status                              # Alias of list

# Reload the on-disk definition into the canvas (refresh and reload are aliases)
pbir desktop refresh "Report.Report"
pbir desktop reload "Report.Report"              # Alias of refresh
pbir desktop refresh "Report.Report" -m          # --model: also re-apply the model (TMDL) definition
pbir desktop refresh --pid 1234                  # Reload a specific instance (omit the path)

# Screenshots
pbir desktop screenshot "Report.Report/Page.Page"             # PNG of a specific page
pbir desktop screenshot "Report.Report/Page.Page" -o out.png  # Explicit output path (single page)
pbir desktop screenshot "Report.Report" --all                 # Every page -> --output-dir (default ./screenshots)
pbir desktop screenshot "Report.Report" --all --output-dir ./shots --settle 500
pbir desktop screenshot "Report.Report" --scale 3             # Render scale, clamped 1-3 (default 2)
pbir desktop screenshot "Report.Report" --pid 1234            # Disambiguate instances
```

Screenshot flags: `--all` (every page), `-o/--output` (single-page PNG path), `--output-dir` (folder for `--all`, default `screenshots`), `--scale` (clamped 1-3, default 2), `--settle` (ms delay before the first capture, with `--all`), `--pid`, `--json`.

Notes: screenshots need the Desktop window in the Report view. Refresh on an instance with unsaved changes makes Desktop save first (rewrites the definition on disk). PBIX files support screenshot but not refresh. `PBIR_DESKTOP_AUTO_REFRESH=1` auto-reloads the canvas after every pbir mutation. See `desktop-integration.md` for the full workflow.

## Usage Metrics

`pbir usage` reports view/viewer/page/load-time metrics for a published report or a whole workspace, pulled from the Power BI service. Auth uses the existing `az login` Power BI token (same tenant as the report); region is auto-detected.

```bash
pbir usage "Report.Report"                       # Local report; auto-resolves its published identity (see report link)
pbir usage "Sales.Workspace"                     # Workspace overview
pbir usage "Sales.Workspace/Exec.Report"         # Single published report
pbir usage -w Sales -r Exec                      # Same, via flags (names or GUIDs; GUIDs skip lookup)
pbir usage "Sales.Workspace" -n 25               # Top 25 viewers (default 10)
pbir usage -w Sales -r Exec --model -y           # Add the usage metrics model for richer page/viewer detail
pbir usage "Sales.Workspace" --no-datahub        # Skip the last-visited lookup
pbir usage "Sales.Workspace" -o json             # JSON for piping
```

A local report resolves its published identity from a saved link (`pbir report link`), the model's workspace, or a prompt. By default the output shows views, viewers, pages, load times, and last-visited. `--model` (`-m`) opts into the workspace usage metrics model for richer detail; it needs Contributor+ and generating it creates a hidden model in the workspace, so it prompts unless `-y/--yes` (or `--no-input` to refuse). `--region` is a fallback only when auto-detection fails. These endpoints are undocumented Power BI service telemetry; see `.claude/rules/undocumented-apis.md` for the underlying WABI metrics APIs.

## Batch Automation

Declarative multi-step edits from a strict JSON spec (`version: 2`), for repeatable builds and anything that must be reviewed before it runs. One spec covers set/bind/CF/presets, layout (move, resize, align, distribute, grid, z-order), create/remove/rename/clone, filters, bookmarks, annotations, page behavior, theme, field replacement, and extension measures, plus `backup`, `validate_report`, and `assert` steps.

```bash
pbir batch examples                              # Bundled specs: audit-report, brand-format, field-measures, report-polish
pbir batch example brand-format > batch.json     # Start from one
pbir batch schema --version 2                    # Exact contract
pbir batch validate batch.json                   # Shape check, no execution
pbir batch plan batch.json --root "Report.Report" --json      # Resolved target counts + stable plan_digest (--verbose-json lists targets)
pbir batch run batch.json --root "Report.Report" --dry-run --json
pbir batch run batch.json --root "Report.Report" --plan-digest <hash>   # Refuses to run if the plan drifted
```

Targets resolve per step as `defaults` then `select`, minus `exclude`, filtered by `where` (a boolean tree of `{field, op, value}` leaves over `path_type`, `visual_type`, `page_name`, position, `has_bindings`, ...), then `max_targets` and `expect`. `root` may be absolute or relative to the working directory; `create_visual` bindings are checked against the model; a later step can target a visual created earlier in the same run (also in `--dry-run`); unresolved `${steps.x}` references are refused before anything runs; a mid-run failure reports what it already wrote. Prefer `batch` over shell loops when the same change must be re-applied or audited.

## Configuration and Setup

```bash
# Config
pbir config show                                 # Current settings
pbir config init                                 # Create config file
pbir config set debug true                       # Set config value
pbir config paths                                # Where config, auth state, templates, backups, and caches live (--json)
```

`pbir` and `pbir-mcp` share one platform-native storage layout (since 0.9.30): configuration in the OS config directory (roaming AppData on Windows, `Library` on macOS, XDG on Linux), templates/backups/auth state in the data directory, and disposable caches (PBIX extractions, model metadata, schemas) in the cache directory. Never hard-code `~/.pbir/` or `~/.config/pbir/`; ask `pbir config paths`. The first run after upgrading migrates durable files from the legacy layout and leaves legacy caches in place for manual deletion. `PBIR_CONFIG` overrides the config file and `PBIR_AUTH_DIR` the auth directory (absolute paths). `pbir setup` was removed; install this plugin from the marketplace instead.

```bash

# Schema discovery and management (pbir capabilities is an alias of pbir schema)
pbir schema status                               # Compare local vs remote schema versions
pbir schema fetch                                # Download latest schemas from GitHub
pbir schema regenerate                           # Regenerate flattened schemas from raw Microsoft schemas
pbir schema check "Report.Report"                # Check report file schema versions
pbir schema upgrade "Report.Report"              # Upgrade report file schemas to latest
pbir schema types                                # List available visual and entity types
pbir schema describe "card"                      # A visual type's objects + properties
pbir schema describe "card" "title"              # One object's properties and allowed values
pbir schema roles "lineChart"                    # Canonical PBIR data roles (required? multiple? Column/Measure)
```

## Visual Types Reference

### Charts
`areaChart`, `barChart`, `clusteredBarChart`, `clusteredColumnChart`, `columnChart`, `donutChart`, `funnel`, `gauge`, `hundredPercentStackedAreaChart`, `hundredPercentStackedBarChart`, `hundredPercentStackedColumnChart`, `lineChart`, `lineClusteredColumnComboChart`, `lineStackedColumnComboChart`, `pieChart`, `ribbonChart`, `scatterChart`, `stackedAreaChart`, `stackedBarChart`, `stackedColumnChart`, `treemap`, `waterfallChart`, `decompositionTreeVisual`, `keyDriversVisual`

### Cards and KPIs
`card`, `cardVisual`, `kpi`, `multiRowCard`, `scorecard`

### Tables
`tableEx`, `pivotTable` (matrix)

### Slicers
`slicer`, `advancedSlicerVisual`, `listSlicer`, `textSlicer`

### Maps
`map`, `filledMap`, `azureMap`, `shapeMap`

### Containers
`shape`, `actionButton`, `bookmarkNavigator`, `pageNavigator`

### Media
`textbox`, `image`

### Custom
`aiNarratives`, `chicletSlicer`, `hierarchySlicer`, `pythonVisual`, `scriptVisual` (R), `qnaVisual`, `rdlVisual`, `timeline`

### Common Data Roles
- **Charts**: Category, Y (Legend, SmallMultiples)
- **Combo charts**: Category, ColumnY, LineY (Legend)
- **Cards**: Values
- **KPI**: Indicator (TrendLine, Goal)
- **Tables**: Values (Rows, Columns for matrix)
- **Slicers**: Values
- **Scatter**: X, Y (Category, Size, Legend)
- **Maps**: Location (Size, Color/Values)

## Global Flags

Global flags go BEFORE the subcommand: `pbir -q new report ...`, not `pbir new report -q ...`.

```text
--quiet / -q              # Suppress animations, tips, spinners (agent-friendly)
--output-format text|json # Structured stdout for commands that support it
--error-format text|json  # Structured stderr where supported
--debug                   # Enable tracebacks, timing, and resolution logging
--version / -V            # Show version
--interactive / -i        # Launch the interactive browser (human users)

# Validation bypass (pbir validates implicitly on mutations; these relax that)
--rawdog                  # Skip EVERY validation check (umbrella for --skip all)
--skip <category>         # Skip validation categories; repeatable, comma-separated.
                          # Categories: structure, schema, schema-version, fields,
                          #             enums, qa, roles, layout, theme
# Example: author a visual whose field is not in the model yet
pbir --skip fields set "R.Report/P.Page/V.Visual.title.text" --value "Draft"
```

Use global `--output-format json` before the subcommand when supported; since 0.9.32 it also covers the listing commands (`fields list`, `bookmarks list`, `dax measures list`, `dax viscalcs list`, `annotations list`, `pages interactions`), and error paths keep stdout clean for scripts. Command-specific `-f/--force`, `--json`, and `-F json` go after their subcommand; check `pbir <command> --help` because availability varies.
