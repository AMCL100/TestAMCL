# Kurt's plugins — v26.20 → v26.31.5

Your repo has been carrying **v26.20**. These are **v26.31.5**, pulled
27 August 2026. Roughly eleven weekly releases of fixes.

Licence: **GPL-3.0** (`LICENSE` included). Kurt has given explicit
permission for this use — record that alongside the attribution file.

---

## How to update

In your local clone, replace the four folders under `data-goblin/plugins/`:

```
data-goblin/plugins/pbi-desktop/       ← replace
data-goblin/plugins/semantic-models/   ← replace
data-goblin/plugins/reports/           ← replace
data-goblin/plugins/pbip/              ← replace
```

Then:

```
git add -A
git commit -m "Update data-goblin plugins 26.20 -> 26.31.5"
git push
```

`marketplace.json` needs no change — the paths are the same.

---

## Do this AFTER v2.1, not with it

This changes build behaviour. v2.1 changes rules. If both land in the same
week and something comes out odd, you won't know which caused it.

```
Week 1   Deploy v2.1. Install the plugins at 26.20. Confirm they work.
Week 2+  Build a couple of reports. Establish a baseline.
Then     Bump to 26.31.5 as its own deliberate change.
```

---

## What's in them now

```
pbi-desktop      connect-pbid

semantic-models  dax · lineage-analysis · power-query
                 refresh-semantic-model · semantic-model
                 standardize-naming-conventions

reports          create-pbi-report · modifying-theme-json
                 pbi-report-design · pbir-cli · review-report

pbip             pbip · pbir-format · tmdl
```

Several of these didn't exist at 26.20 — `lineage-analysis`,
`standardize-naming-conventions`, `pbi-report-design` and `pbir-cli`
are all worth a read before you bump, because they overlap with things
AgentAdam now does itself.

**Check for conflicts.** `pbi-report-design` is Kurt's report design
guidance. AgentAdam has its own. Kurt's skills defer to project
instructions, so yours should still win — but worth verifying with a
litmus question after the bump:

> "What is the canvas area and its coordinates?"

If that still returns y:136–1066, x:28–2535, your authority hierarchy
is holding.

---

## Binaries

Two `bin/` folders were stripped so this zip passes mail filters.
See `MISSING-BINARIES.md` — nothing breaks without them, and there's a
simpler route if public GitHub is reachable from your work machine.
