# Binaries removed from this package

Two folders were stripped so the zip passes corporate mail filters:

```
pbip/hooks/bin/                  TMDL validation executables
  tmdl-validate-windows-x64.exe
  tmdl-validate-darwin-arm64
  tmdl-validate-darwin-x64
  tmdl-validate-linux-x64

reports/skills/pbir-cli/bin/
  fetch.sh
```

## Do you need them?

`pbip/hooks/bin/` is used by the TMDL validation hook. If the hook runs
without the binary it will fail quietly — you lose a validation step, but
nothing breaks. You can deploy without it and add it later.

## Getting them

Easiest: pull Kurt's repo directly on your work machine and copy the
folders across.

```
git clone --depth 1 https://github.com/data-goblin/power-bi-agentic-development.git
```

Then copy:

```
power-bi-agentic-development/plugins/pbip/hooks/bin/
  →  data-goblin/plugins/pbip/hooks/bin/

power-bi-agentic-development/plugins/reports/skills/pbir-cli/bin/
  →  data-goblin/plugins/reports/skills/pbir-cli/bin/
```

Or download the two folders from GitHub in the browser.

## Better idea

If public GitHub is reachable from your work machine, skip the transfer
problem entirely — clone Kurt's repo there and copy all four plugin
folders straight across. Nothing needs to travel by email.

The rest of this package (the AgentAdam files) still needs transferring,
but it's all text and won't trip anything.
