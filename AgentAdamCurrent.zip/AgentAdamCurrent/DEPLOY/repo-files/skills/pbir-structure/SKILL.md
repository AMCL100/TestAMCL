# Skill: Reading PBIR

## WHEN to activate

Any time the agent needs to read, interpret, audit or edit the report
definition of a PBIP project. This underpins several other skills:

```
go-live-readiness       checking visual selection and field bindings
production-documenter   describing pages and what they contain
template-standards      verifying zones, spacing and formatting
model-evaluation        finding columns and measures nothing uses
```

This skill is about **understanding** PBIR. Plugins may provide patterns for
writing it; this is the knowledge AgentAdam owns, and it stays valid whatever
tooling sits underneath.

---

## Folder structure

```
MyReport.Report/
├── definition.pbir              pointer to the semantic model
├── definition/
│   ├── report.json              report-level settings, theme, filters
│   ├── pages/
│   │   ├── pages.json           page order and the active page
│   │   └── [pageName]/
│   │       ├── page.json        page settings, size, filters
│   │       └── visuals/
│   │           └── [visualName]/
│   │               └── visual.json
│   └── bookmarks/
│       ├── bookmarks.json
│       └── [bookmarkName].bookmark.json
└── StaticResources/
    └── RegisteredResources/     theme file, images
```

One folder per page, one folder per visual. The folder names are GUIDs or
generated names — **never** the display name. To find "the Summary page" you
must read each `page.json` and check its `displayName`.

---

## page.json — the essentials

```json
{
  "name": "e8a1...",
  "displayName": "Summary",
  "displayOption": "FitToPage",
  "height": 1080,
  "width": 2560,
  "visibility": "AlwaysVisible",
  "filterConfig": { "filters": [ ... ] }
}
```

```
displayName    the human name. This is what to report to the developer.
width/height   confirm 2560 × 1080 against our standards
visibility     "HiddenInViewMode" means it won't appear to users —
               check whether that's intentional before flagging
filterConfig   page-level filters. Always an array.
```

---

## visual.json — the anatomy

The file that matters most. Four parts worth understanding:

```json
{
  "name": "a7f3...",
  "position": { "x": 28, "y": 136, "width": 1200, "height": 400, "z": 1000 },
  "visual": {
    "visualType": "clusteredColumnChart",
    "query": {
      "queryState": {
        "Category": { "projections": [ { "field": { ... }, "queryRef": "..." } ] },
        "Y":        { "projections": [ { "field": { ... }, "queryRef": "..." } ] }
      }
    },
    "objects": { ... },
    "visualContainerObjects": { ... }
  }
}
```

### position

Check against our zones:

```
Top bar        y:8–128      slicers and titles only
Filter pane    y:129–1066   x:2020–2546, hidden by default
Canvas         y:136–1066   x:28–2535, all report visuals

Minimum 10px spacing between visuals.
z controls layering — higher sits on top.
```

A visual whose `y` is below 136 is in the top bar. If it isn't a slicer or a
title, that's a standards violation.

### visualType

The visual type as a string. Common values:

```
clusteredColumnChart   barChart            clusteredBarChart
lineChart              areaChart           lineClusteredColumnComboChart
card                   cardVisual          multiRowCard
tableEx                pivotTable          matrix
slicer                 advancedSlicer
pieChart               donutChart          gauge
scatterChart           map                 filledMap
textbox                image               shape
actionButton
```

`cardVisual` is Card v2. `card` is the older simplified card — our standard
is v2, so flag `card` on new builds.

Anything not in this list is likely a custom visual. Check whether we have
it licensed before assuming it will render.

### query / projections

Where the fields are bound. **The single most important structural rule:**

```
projections is ALWAYS an array — even for one field.

CORRECT   "projections": [ { "field": {...}, "queryRef": "Sales.Amount" } ]
WRONG     "projections":   { "field": {...}, "queryRef": "Sales.Amount" }

Writing it as an object produces a file that opens but renders blank.
This is the most common PBIR authoring failure.
```

The `queryState` keys are **roles**, and they differ by visual type:

```
Bar / column     Category, Y, Series, Tooltips
Line             Category, Y, Series
Card v2          Values, ReferenceLabels, DetailLabels
Table            Values
Matrix           Rows, Columns, Values
Slicer           Values
Scatter          X, Y, Size, Details
```

Each projection carries a `queryRef` such as `"Sales.Amount"` or
`"DimDate.Month"`. **This is how to determine which model objects a report
actually uses** — collect every `queryRef` across every visual, and anything
in the model not appearing in that set (and not referenced inside a measure's
DAX) is unused.

`nativeQueryRef` holds the display name shown to the user, which is often
different from the underlying field. Both matter: `queryRef` for lineage,
`nativeQueryRef` for what the reader sees.

### objects vs visualContainerObjects

```
objects                  formatting of the data presentation —
                         data labels, axes, legend, series colours

visualContainerObjects   formatting of the container —
                         title, subtitle, background, border, shadow
```

Title and subtitle live in `visualContainerObjects`, not `objects`. A common
mistake is looking for the title in the wrong place and concluding there
isn't one.

Both are structured as arrays of property bundles:

```json
"visualContainerObjects": {
  "title": [ { "properties": { "text": { "expr": { "Literal": { "Value": "'Net Margin'" } } } } } ]
}
```

Literal string values are wrapped in single quotes *inside* the JSON string.
`"'Net Margin'"` is correct; `"Net Margin"` is not.

---

## Filters

Three levels, all using the same shape, all always arrays:

```
report.json    filterConfig    applies everywhere
page.json      filterConfig    applies to one page
visual.json    filterConfig    applies to one visual
```

When auditing, check for filters left on a single test account or a fixed
date — a classic pre-production leftover.

---

## Reading a report: a practical sequence

To understand what a report contains:

```
1. pages.json            page order and which is active
2. each page.json        displayName, size, visibility, page filters
3. each visual.json      visualType, position, queryRefs, title
4. report.json           theme, report-level filters
5. bookmarks.json        navigation and state, if present
```

From that you can answer: what pages exist, what each shows, which model
objects are used, whether zones are respected, and whether the visual choices
are sensible.

---

## Common problems to flag

```
projections as an object      renders blank — always an array
Visual below y:136 that       top bar is slicers and titles only
  isn't a slicer or title
Visuals overlapping           check z-order was intentional
Less than 10px spacing        standards violation
"card" instead of             Card v2 is our default
  "cardVisual" on new builds
Vocabulary placeholder text   "Example subtitle for more context..."
  left in a subtitle          must be rewritten or removed
Hidden pages                  intentional, or unfinished work?
Filters on a single value     test leftover
Visuals bound to no field     unfinished
More than ~20 visuals         every visual is a query — capacity concern
  on one page
Custom visualType             confirm it's licensed and available
```

---

## Rules when editing

- **Never** edit a `.pbix`. Only PBIP projects have readable definitions.
- **Never** change the theme file. Flag theme gaps instead.
- **Never** modify the vocabulary pages in the template.
- Keep `projections` an array. Every time.
- Preserve the `name` GUIDs — changing them breaks bookmarks and
  cross-filtering.
- After any structural edit, ask the developer to reload in Desktop and
  confirm the page renders before continuing. The agent cannot see the
  result; only the developer can.

---

## The honest limitation

The agent reads the definition, not the rendering. It can confirm a visual is
bound to the right field and positioned in the right zone. It cannot confirm
the chart looks right, the labels don't collide, or the numbers are correct.

Desktop validation is not optional. It is the only way to close that gap.
