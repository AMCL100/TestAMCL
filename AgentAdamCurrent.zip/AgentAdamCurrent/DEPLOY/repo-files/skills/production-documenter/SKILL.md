# Skill: Production Report Documenter

## WHEN to activate

When the developer asks for production documentation for a report — e.g.
*"document this report for production"*, *"produce the technical
documentation"*, *"run the documenter"*.

Distinct from the `documentation` skill, which produces lighter handover
notes. This one produces the formal record that goes to Confluence and feeds
the Governance Framework.

---

## Where the content comes from

```
FROM THE DEVELOPER   report name, developer, business owner, data owner,
                     summary, key metrics and what each means

FROM THE FILES       everything else — lineage, ERD, measure catalogue, SQL
```

### Asking for the human part

Ask for all six in **one message**, not six separate questions. Show what
you already know so the developer only fills the gaps.

> Before I document this, I need six things that aren't in the project files:
>
> ```
> Report name:      [I'll use "Overdue Debt >90 Days" from the project unless you'd prefer otherwise]
> Developer:
> Business owner:
> Data owner:
> Summary:          one paragraph — what it's for, who reads it, what it supports
> Key metrics:      the headline figures and what each means to the business
> ```
>
> Approx row counts:  rough figures per table — Desktop shows them
>                      bottom right in table view
>
> Paste them back and I'll do the rest.

Infer what you reasonably can from the project — report name, and often the
key metrics from the cards on the landing page — and present those as
suggestions to confirm rather than blanks to fill.

If the developer used the report planner at the start of the build, much of
this was already answered. Look for it before asking.

---

## No Mermaid

Confluence here does not render Mermaid. Never emit a Mermaid block.

The ERD is produced as **a relationship table plus a text star-schema
diagram in a code block**. Both render cleanly in Confluence and stay
readable in the repo.

---

## Document structure

Produce exactly this, in this order, written to
`report-documentation.md` in the report folder.

### 1. Header

```markdown
# [Report Name]

| | |
|---|---|
| **Developer** | [name] |
| **Business owner** | [name] |
| **Data owner** | [name] |
| **Documented** | [date] |
| **Model** | [semantic model name] |
| **Refresh** | [schedule and strategy] |
```

### 2. Summary

Two or three paragraphs. What the report is for, who reads it, what decisions
it supports. Plain business language — this section is for people who will
never open Power BI.

### 3. Key metrics

For each headline metric, a short subsection:

```markdown
### [Metric name]

**What it means:** [business definition, plain English]

**How it is calculated:** [the logic in words, not DAX]

**DAX:**
```
[the measure]
```

**Depends on:** [tables and columns it touches]
```

Business definition first, DAX last. Most readers stop after the first line.

### 4. Lineage

Trace each table back to the warehouse. Note every transformation between
source and model.

```markdown
| Model table | Source | Transformations | Refresh |
|---|---|---|---|
| FactDebt | `reporting.OverdueDebt` | Filtered to >90 days; joined to DimAccount | Incremental, 30 days |
```

Beneath the table, note anything worth a reader's attention — logic embedded
in the partition query, hardcoded filters, anything not obvious from the
table alone.

### 5. Tables

One subsection per table in the model. This is the reference section —
someone picking the report up in a year should be able to answer "what is
actually in here" without opening Desktop.

```markdown
#### FactDebt

**Purpose:** Daily overdue debt position by account
**Grain:** One row per account per snapshot date
**Type:** Fact · Import
**Approx rows:** ~2.3m
**Date bounded:** Yes — incremental refresh, rolling 25 months

| Column | Data type | Format | Used by | Notes |
|---|---|---|---|---|
| AccountKey | Whole number | — | Relationship to DimAccount | Key |
| SnapshotDate | Date | dd/mm/yyyy | Relationship to DimDate | Key |
| OverdueBalance | Decimal | £#,##0 | Overdue Debt measure | |
| MedalLabel | Text | — | Slicer, Account split visual | |
| SourceRef | Text | — | *Not used* | Candidate for removal |
```

Include for every table:

```
Purpose         one line, business language
Grain           what one row represents — say it explicitly
Type            fact / dimension / bridge / calculated · import or direct query
Approx rows     see below
Date bounded    incremental window, WHERE clause, or "no — full history"
```

And for every column: data type, format string, what uses it (measure,
relationship, visual, or nothing), and anything worth knowing.

**Mark unused columns clearly.** A column referenced by no measure, no
relationship and no visual is dead weight, and the documentation is where
that becomes visible. Say so in the Notes column rather than quietly
listing it.

#### Getting the row counts

Row counts are **not in the project files**. TMDL holds the definition, not
the data. Do not invent a number and do not estimate one from thin air.

In order of preference:

```
1. Ask the developer. They can read it off Power BI Desktop —
   the table view shows the row count bottom right.

2. Infer a bound from the incremental refresh policy where one
   exists, and label it as such:
   "~25 months of daily snapshots — developer to confirm actual count"

3. If neither is available, write "Not recorded" and flag it.
```

When asking, roll it into the single metadata question rather than coming
back a second time:

> While you're there — approximate row counts for each table? Desktop shows
> them bottom right in table view. Rough figures are fine, they're for
> orientation not accuracy.

---

### 6. Semantic model

**Relationship table:**

```markdown
| From | To | Cardinality | Direction | Active |
|---|---|---|---|---|
| FactDebt[AccountKey] | DimAccount[AccountKey] | Many to one | Single | Yes |
```

**Star schema, as text in a code block:**

```
                    DimDate
                       |
                       | AccountKey
    DimAccount ------- FactDebt ------- DimSegment
                       |
                       |
                  DimProduct
```

Keep it simple. The relationship table carries the detail; the diagram only
needs to convey the shape.

### 7. Measure catalogue

Every measure in the model:

```markdown
| Measure | Display folder | Format | Description |
|---|---|---|---|
```

Flag any measure with a missing description or format string — the
documentation is where that gap becomes visible.

### 8. SQL

Every distinct query feeding the model, one code block per table, each
labelled with the table it populates. Full text, not summarised — this
section is the record.

### 9. Footer

```markdown
---
*Generated by AgentAdam on [date] from the project files.*
*Any change to the report or model requires this document to be regenerated.*
```

---

## Confluence

Produce Markdown shaped for a clean paste into Confluence. Do not attempt to
publish — the developer copies it across.

If asked about auto-publishing, say it is possible via the Confluence REST
API but out of scope for now.

---

## Rules

- **Never invent an owner.** If the developer hasn't said, leave it blank and
  flag it. A wrong owner is worse than none.
- **Never transcribe figures.** No values from screenshots, no numbers
  recalled from a previous session. Everything comes from the files.
- **Business language before technical.** Every section leads with what it
  means, then how it works.
- **Flag the gaps.** Missing descriptions, undocumented transformations,
  measures nothing uses — surface them rather than quietly producing tidy
  documentation over an untidy model.
- **Regenerate, don't patch.** If the report changes, run the documenter
  again. The document is derived, not maintained.
