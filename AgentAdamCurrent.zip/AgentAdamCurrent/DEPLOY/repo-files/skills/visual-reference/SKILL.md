# Skill: Building from a visual reference

## WHEN to activate

Any time the developer attaches an image and asks for a page to be built,
adapted or laid out from it. Covers:

- A screenshot of a report from elsewhere ("make mine like this")
- A hand-drawn or whiteboard wireframe
- A mockup from Excel, PowerPoint or a design tool
- A screenshot of one of our own existing reports being rebuilt

---

## The core rule

A screenshot carries two things: **what the page is doing** and **how the
source styled it**. Take the first. Never take the second.

```
FROM THE IMAGE      the intent — visuals, hierarchy, story, grouping
FROM THE TEMPLATE   the form — zones, coordinates, colours, fonts, spacing
```

This is the standard AgentAdam authority hierarchy applied to an image.
The template still wins on form. The developer still wins on content.
An image is a content input, not a styling instruction.

**Never reproduce the source's styling**, even when the developer says
"make it look like this". They mean the layout and the ideas, not the
other organisation's brand. If they genuinely want a styling change,
that is a theme conversation with Adam, not a per-report decision.

---

## EXTRACT from the image

- Which visuals are present and what each one shows
  (e.g. "horizontal bar of value by category", "line trend over months")
- Information hierarchy — what is largest, most prominent, read first
- Grouping — which visuals sit together and appear related
- Rough proportions — is the trend the hero, or supporting context
- Reading order implied by the arrangement
- Interaction hints — slicers, tabs, buttons, drill paths
- The story the page is telling and, if inferable, its audience

## IGNORE completely

- Colours — use the AgentAdam palette, applied by meaning
- Fonts and type sizes — IberPangea per the standards
- Any branding, logos, headers or footers from the source
- Exact pixel positions from the image
- Chart styling — gradients, shadows, rounded corners, dark backgrounds
- Border and card styling from the source

## NEVER TRUST from an image

- **Numbers and values.** Never transcribe figures from a screenshot.
  They will be subtly wrong. All values come from the model.
- **Field and measure names.** These cannot be reliably read from a
  picture. Ask the developer, or map to what exists in the model.
- **That the source's chart choice is correct for our data.** A visual
  that suited their data may not suit ours.

---

## Aspect ratio — reflow, do not scale

Most reports found online are designed for roughly 16:9. Our canvas is
2560 × 1080, which is considerably wider.

```
DO NOT   scale the source layout proportionally — it leaves dead space
         at the edges and undersized visuals in the middle

DO       reflow horizontally. Use the full canvas width (x:28–2535).
         Visuals stacked vertically in the source can often sit
         side by side for us.
```

State this when it applies:

> "The source is a 16:9 layout — ours is much wider, so I've moved the
>  breakdown alongside the trend rather than beneath it. Same content,
>  reflowed to our canvas."

---

## Custom and unavailable visuals

Source reports often use visuals we do not have, or do not permit.

```
1. Identify what the visual is doing, not what it is called
2. Map it to the nearest equivalent in our visual vocabulary
3. Tell the developer what you substituted and why
```

Never assume a custom visual is available. If there is no close
equivalent, say so and propose the nearest standard alternative
rather than silently dropping the content.

---

## Map to a layout pattern

Name which of our four layout patterns the reference most resembles, and
say so before building:

```
3/30/300     glance / scan / dig — a self-service dashboard shape
Narrative    a story arc across the page, clear reading order
Executive    one hero figure with supporting context around it
Operational  a status grid, scannable, no drill-to-row
```

If the source does not map cleanly to any of them, say that too and
propose the closest fit rather than inventing a fifth pattern.

---

## Required response before building

Always describe the adaptation and get approval. Never build straight
from an image without confirming the read.

Structure the response as:

```
WHAT I CAN SEE
  A list of the visuals and what each appears to show.

THE SHAPE
  Which layout pattern this maps to, and why.

WHAT I'M CHANGING TO FIT OUR TEMPLATE
  Colours to our palette, applied by meaning.
  Fonts to IberPangea.
  Reflowed to 2560 × 1080 — specifically what moved and why.
  Any visual substitutions, with the reason.

WHAT I NEED FROM YOU
  Which measures and fields map to each visual.
  Anything I have read wrongly.
```

Then wait. Do not begin building until the developer confirms.

---

## Worked example

> **Developer:** *[attaches a screenshot of a finance dashboard]* Make mine
> like this but in our corporate settings.

> **Agent:** Here's what I can see — a large headline figure top-left, three
> smaller comparison figures beside it, a twelve-month trend line across the
> top-right, a horizontal bar breakdown bottom-left, and a detail table
> bottom-right.
>
> That maps closest to our **3/30/300** pattern — headline at a glance,
> breakdowns to scan, table to dig into.
>
> Changes to fit our template: the source uses a dark background with
> teal and purple accents — I'll use our palette instead, with colour
> carrying good/bad meaning rather than being decorative. Fonts to
> IberPangea. The source is 16:9, so rather than scaling I'll widen the
> trend and move the breakdown alongside it, using the full canvas width.
> Their gauge visual isn't in our vocabulary — nearest equivalent is a
> KPI card with a reference label, unless you'd prefer something else.
>
> What I need from you: which measure is the headline figure, what the
> three comparisons should be, and the dimension for the breakdown.
>
> Shall I proceed on that basis?

---

## Reminder

The developer chose that reference because of what it *does* — how it
organises information and what it makes easy to see. That is the part
worth taking. The styling belongs to whoever built it, and ours belongs
to us.
