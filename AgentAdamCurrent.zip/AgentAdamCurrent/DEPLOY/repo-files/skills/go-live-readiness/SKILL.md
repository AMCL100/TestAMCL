# Skill: Go Live Readiness Review

## WHEN to activate

When the developer asks for a go-live review, readiness check, pre-production
review, or similar — e.g. *"run a go live readiness review"*, *"is this ready
for production?"*

This is a **governance and performance pit stop** before a report goes into
production — a second pair of eyes, not an approval gate. It is read-only.
Change nothing, and never issue a verdict.

---

## Scope — four checks, nothing else

```
1. SQL review              the queries feeding the model
2. PII exposure            what personal data is reaching the report
3. Model performance       structure, size and refresh cost
4. Measure performance     DAX that makes every visual work harder
```

Do not extend the review beyond these four. A focused report that gets read
is worth more than a comprehensive one that doesn't.

---

## The honest boundary — state this in every report

The agent reads files. It does not execute anything.

```
CAN    read the SQL, the model definition and every measure
       identify patterns known to cause problems
       flag things that warrant a human look

CANNOT run a query or measure a duration
       confirm what data a column actually contains
       prove any finding is a real-world problem
```

This is a **design review, not a test**. Say so at the top of every report.

---

## Check 1 — SQL review

Read the SQL from the model's TMDL partitions. Apply the `sql-review` skill,
and additionally flag for go-live:

- **Logic that belongs in the warehouse.** Where a query has grown complex
  enough that it should be a table in the reporting schema on a daily batch,
  rather than executed from a report on every refresh.
- **Queries heavy enough to affect others.** Where a refresh could plausibly
  affect Synapse availability beyond the report that owns it.
- **Data source integrity.** Anything pointing at a personal OneDrive, a
  local `C:\` path, a development database, or a personal workspace.
  Always **look at this first** — a report pointing at a personal or
  development source is not ready to go anywhere.
- Wide selects pulling columns the model never uses.
- Functions applied to join or filter keys, preventing index use.
- The same logic repeated across multiple partitions.

---

## Check 2 — PII exposure

The agent sees column **names**, never values. Every finding here is a prompt
for human review, not a clearance. Say that explicitly.

### Flag for review

```
Direct identifiers    CustomerName, FirstName, Surname, Email,
                      Phone, Mobile, DateOfBirth, NINumber
Location              AddressLine1/2, PostCode, Postcode
Financial             SortCode, AccountNo (bank), IBAN, CardNumber,
                      individual-level debt or arrears detail
Sensitive             PSR / Priority Services, vulnerability flags,
                      health or accessibility indicators
Meter                 meter serial numbers
```

### Explicitly NOT PII in our context

```
MPAN, MPRN    supply point identifiers, not personal data.
              Never flag these.
```

### How to report a finding

For each flagged column, state:

- Where it sits — model only, or bound to a visual and therefore visible
- Whether row-level security is defined on the model
- Whether the report is intended for a restricted or general audience

A PII column sitting in the model but never surfaced in a visual is a
different conversation from one displayed in a table on the landing page.
Make the distinction clearly — it changes the severity.

**Severity guidance:** sensitive-category data (PSR, vulnerability, health)
sensitive-category data (PSR, vulnerability, health) visible in a report
with no RLS belongs in **look at this first**. Direct identifiers visible
without RLS go in **worth checking** — there may be a perfectly good reason,
and the agent can't know the audience. Anything present in the model but
never surfaced is **for awareness** — it may simply not need importing.

---

## Check 3 — Model performance

Read the TMDL. Check:

**Refresh cost**
- Is incremental refresh configured on the large fact tables, or is every
  refresh a full load? The single biggest capacity and Synapse-load question.
- Partition policy sensible for the data volume.

**Grain and date boundedness — check this on every fact table**

First establish whether the table is aggregated or sitting at detail grain.
Signals of detail grain:

```
· A row-identifying column — TransactionID, AccountNumber + Date,
  a surrogate key that looks one-per-event
· No GROUP BY in the partition SQL
· Columns that only make sense per-record — reference numbers,
  free text, individual timestamps
· Naming: Fact* rather than Agg*, Summary* or Snapshot*
```

**If the table is NOT aggregated, it must be bounded by date.** Report
explicitly which of these applies:

```
BOUNDED — acceptable
  · Incremental refresh policy with a rolling window
    (RangeStart / RangeEnd, e.g. "last 25 months")
  · A WHERE clause on a date column in the partition SQL
    (e.g. WHERE SnapshotDate >= DATEADD(month, -24, GETDATE()))
  · A fixed cut-off with a documented reason

UNBOUNDED — flag it
  · No date filter anywhere, and no incremental policy
  · A filter on a static date that will never move
    ("WHERE Year >= 2020" grows forever — it is not a window)
  · Filtered only in the report layer, not at import
```

State the finding in this shape:

> `FactDebt` is at detail grain (one row per account per day) with no
> incremental refresh policy and no date predicate in the partition query.
> Every refresh loads the full history, and the table grows indefinitely.
> Either add a rolling window, or aggregate upstream in the reporting
> schema.

**Severity:** an unaggregated fact table with no date restriction is a
**worth checking** at minimum. Where the table is plausibly large it moves
to **look at this first**, because a full refresh of an unbounded detail
table is the kind of thing that affects other people. The agent can't see
the row count, so say what it's assuming and ask.

Where the table is small and genuinely needs full history, that's fine —
but it's better as a stated decision than an accident.

A filter in the report layer does not count. By then the data is already
in the model and has already crossed the wire.

**Model size**
- **Auto date/time enabled** — creates a hidden date table per date column.
  Silent and significant bloat. Nearly always **worth checking**.
- Unused columns — cross-reference every model column against PBIR field
  bindings and measure DAX. Columns referenced by neither are dead weight.
- High-cardinality columns, especially free text and timestamps at second
  precision.
- Data types — high-precision decimal where fixed decimal would do,
  datetime where date suffices, text that should be integer.

**Structure**
- Calculated columns on fact tables. Always flag — against our standards.
- Bi-directional relationships — ambiguity and performance cost.
- Many-to-many relationships.
- Inactive relationships nothing activates via `USERELATIONSHIP`.
- Date table properly marked, and a real date dimension rather than
  generated columns.

---

## Check 4 — Measure performance

Read every measure in the model. Check:

**Patterns that cost**
- Iterators (`SUMX`, `AVERAGEX`, `FILTER`) over large fact tables where a
  simpler aggregation would do.
- Nested iterators — an iterator inside an iterator.
- `FILTER` wrapping an entire table rather than a column.
- Repeated sub-expressions that should be a `VAR`.
- Long dependency chains — measures referencing measures referencing measures.

**Correctness and standards**
- `/` used instead of `DIVIDE` — blanks and divide-by-zero.
- Hardcoded values: dates, account numbers, magic numbers. Ticking time bombs.
- Implicit measures — auto-generated aggregations rather than explicit ones.
- Missing format strings.
- Missing descriptions.

**Reach**
- Measures bound to no visual anywhere in the report. Either unused, or the
  report is unfinished. Worth asking which.

---

## This is a review list, not a gate

**Never issue a pass, a fail, or a verdict.** The agent cannot run a query,
cannot measure a duration and cannot see the data. It is in no position to
approve or block anything, and pretending otherwise would be both wrong and
quickly distrusted.

What it produces is **a list of things worth looking at, in priority order**,
with enough context for a person to make the call.

Group findings into three bands:

```
LOOK AT THIS FIRST    likely to cause a real problem in production.
                      The agent is reasonably confident and the
                      consequence would be material.

WORTH CHECKING        might matter, depends on context the agent
                      cannot see — data volume, audience, intent.
                      Needs a human to decide.

FOR AWARENESS         noted, probably fine. Recorded so nobody has
                      to rediscover it later.
```

These are **priorities for attention**, not severities. "Look at this first"
means exactly that — start here — not "this is forbidden".

### How to phrase a finding

Every finding says what was seen, why it might matter, and what the person
might want to do. Never an instruction, never a judgement.

```
GOOD   FactDebt is at detail grain with no incremental policy and no date
       predicate in the partition query, so every refresh loads full
       history. Worth checking the volume — if it's large, a rolling
       window or upstream aggregation would reduce the load on Synapse.

BAD    BLOCKER: FactDebt has no incremental refresh. Must be fixed
       before go-live.
```

The first gives a person what they need to decide. The second makes a
ruling the agent has no basis for.

### Where the agent is uncertain, say so

Much of what this review finds depends on things the agent cannot see.
Say which, plainly:

> Six columns appear unused by any measure, relationship or visual. Worth
> confirming — they may be there for a planned change, or used in a way I
> can't detect from the files.

Being explicit about uncertainty is what makes the confident findings
worth trusting.

---

## Output format

Write the review to `go-live-review.md` in the report folder.

```markdown
# Go Live Readiness Review — [Report Name]

**Reviewed:** [date]

> A review list, not an approval. Findings come from reading the project
> files — no query was run and no data was inspected. Several findings
> depend on context I can't see, so they're flagged for a person to judge
> rather than stated as problems.

## Summary
[Two or three sentences. What stood out, and roughly how much there is
to look at. No verdict.]

## Look at this first
[Each: what was seen · where · why it might matter · what you might do.
Or "Nothing in this band."]

## Worth checking
[Each, same shape. These depend on context — say what context is missing.
Or "Nothing in this band."]

## For awareness
[Brief list. Or "Nothing in this band."]

## Done well
[Two or three things, briefly. Genuine, not padding.]

## What was checked
| Area | Findings | Notes |
|---|---|---|
| SQL review | n | |
| PII exposure | n | column names only — contents not inspected |
| Model performance | n | |
| Measure performance | n | |
```

Every finding must name **where** it is — the table, the measure, the
partition, the visual. A finding the developer can't locate is not actionable.

---

## Tone

Direct, specific and useful. Not alarmist. The developer has built something
and is asking for a second look before it goes live — write like a colleague
doing a careful review, not an audit function looking for fault.

Where something is done well, say so. It isn't padding: it tells the
developer what to keep doing, and it makes the rest land better.

Never tell the developer what they must do. Tell them what you saw, why it
might matter, and what they might want to check. The decision is theirs —
they can see things the agent cannot.
