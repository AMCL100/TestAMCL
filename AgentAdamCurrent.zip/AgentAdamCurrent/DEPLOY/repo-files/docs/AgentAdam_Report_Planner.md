# AgentAdam Report Planner

> **How to use this:** Fill in the sections below, then paste the whole
> thing to the agent as your opening message. The agent has everything it
> needs to start planning — no back-and-forth on basics.
>
> **What to skip:** Anything you're unsure about. Leave blank and the
> agent will ask. You don't need to know exact visual types — describe
> what you want to see.
>
> **Optional lines** are marked with `(optional)`. Skip freely.

---

## Report

**Report name:**

**Report purpose:** _One sentence — what question does this report answer or what decision does it support?_

**Audience:** _Who reads this? Executive board / operational team / analysts / mixed._

**Data source:** _Existing model at [path], or new model from [tables/systems], or "not sure yet"._

**Layout preference (optional):** _If you already know — 3/30/300, Narrative, Executive, or Operational. Otherwise the agent picks per page._

---

## Pages

_Copy the block below for each page. Delete this note when done._

### Page 1

**Page name:**

**Page purpose:** _What is this page for? Explaining? Monitoring? Comparing? Exploring?_

**Visuals:** _What you want to see. Doesn't need to be specific chart types._
_e.g. "sales trend over 12 months", "top 10 customers by margin", "cost breakdown by category"_

**Key measures:** _The main numbers on this page._

**Key slicers:** _Max 4 across the top bar. 5th onwards goes to the filter pane._

**Layout preference (optional):** _If different from the report-level default._

**Notes (optional):** _Anything unusual — accessibility needs, weird data, tricky comparisons._

---

### Page 2

**Page name:**

**Page purpose:**

**Visuals:**

**Key measures:**

**Key slicers:**

---

## When you paste this to the agent

The agent will:

1. Confirm the pre-session checklist (Desktop closed, backup taken, `.pbip`)
2. Ask for the report title text (top-right text box)
3. Review your plan and flag anything that conflicts with template standards
4. Propose adaptations where needed, get your approval
5. Build page by page with Desktop validation checkpoints

You still control everything. The plan is your starting point, not a contract.

---

*AgentAdam — SP Customer Business · COE Data Governance & Visualisation*
