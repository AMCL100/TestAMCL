# AgentAdam — everything, and how to deploy it

*Packaged 27 August 2026*

Nothing in here has been deployed. This is the whole accumulated set of
changes in one go, with the steps to land it.

Allow about an hour, plus a bit of testing.

---

## The single most important thing

**Kurt's four plugins have never actually been installed.** Not on the
team's machines, not on yours. The entire pilot has run on the `agentadam`
governance plugin alone, with Copilot's own file editing underneath and
none of the proven PBIR/TMDL patterns.

That very likely accounts for a good chunk of what we spent weeks treating
as rules problems — broken `projections` JSON, formatting drift, blank
visuals.

The install format we'd all been using was simply wrong. This works:

```
Ctrl+Shift+P → Chat: Install Plugin From Source
Paste:  U357001_ibe/AgentAdam          ← just the repo path, nothing else
The Extensions sidebar opens showing all 5 plugins
Click Install on EACH one individually
Confirm all 5 under Extensions → Agent Plugins - Installed
```

These do **not** work, both tested and failed:

```
pbi-desktop@U357001_ibe/AgentAdam      rejected as invalid
"github.copilot.chat.plugins" in settings JSON   installs nothing
```

---

## What's in this release

### Rules that change every build

**The formatting drift fix.** A decision tree the agent must follow for
every visual: vocabulary page → adapt closest match → full specification →
ask the developer. Plus an explicit rule that Copilot's own training
defaults are never the answer at any step.

**The full formatting specification.** Every visual type end to end —
titles, subtitles, legends, axes, data labels, colour, and per-type
settings for columns, lines, cards, tables, matrices and slicers. This is
what makes the vocabulary page a *convenience* rather than a *dependency*.
A developer without the template open now gets the same result.

**Font rule hardened.** IberPangea everywhere, stated as non-negotiable in
both the instructions file and the skill, with every element it applies to
listed and the fonts it must never substitute named.

**Card Visual v2 as default.** Reference and detail labels only when the
developer asks for them.

**DAX highlighting patterns.** Concrete `SWITCH` + `MAXX` / `MINX` for max
and min, above/below average, thresholds. The agent asks whether high is
good, bad or neutral before picking a colour.

**Plus everything from June that never went out** — the blue/orange
palette, narrowed slicer zone, subtitle and page/report title rules, legend
defaults, SQL review reading from TMDL, Desktop validation checkpoints, the
four layout patterns, and the corrected authority hierarchy.

### Four new skills — 7 up to 11

All read-only or explicitly triggered. None change how a normal build
behaves.

```
go-live-readiness       "run a go live readiness review"
                        SQL, PII, model performance, measure performance,
                        grain and date boundedness. Produces a prioritised
                        review list — never a pass/fail verdict. MPAN and
                        MPRN excluded from PII flagging.

production-documenter   "document this report for production"
                        Confluence record — owners, summary, key metrics,
                        lineage, ERD, measure catalogue, full SQL.
                        No Mermaid; relationship table plus text
                        star-schema.

pbir-structure          No trigger of its own. Reference knowledge the
                        others draw on — projections always an array,
                        titles in visualContainerObjects.

visual-reference        Fires only when an image is attached.
                        "make mine like this but in our corporate
                        settings" — extract intent, never styling.
```

### Versions

```
Plugin       1.1.3 → 1.1.4
Extension    1.0.3  (unchanged, but never distributed)
Kurt's       26.20  → 26.31.5 available, deploy LATER (see step 6)
```

---

## Deployment

### Step 1 — SharePoint (2 min)

```
Open  https://iberdrola.sharepoint.com/sites/UK%20Operations/UK%20Operations%20Document%20Library/Reporting/Data%20Visualisation/Agentic%20BI%20-%20AgentAdam

Upload  DEPLOY/sharepoint-file/agentadam.instructions.md
        → Replace when prompted

Wait 1–2 minutes for OneDrive to sync.
```

### Step 2 — GitHub (10 min)

Open your local clone and overwrite from `DEPLOY/repo-files/`:

```
.github/copilot-instructions.md
.github/plugin/marketplace.json
plugins/agentadam/.github/plugin.json     ← now v1.1.4
skills/                                    ← all 11, four are new
AgentAdam/                                 ← standards files
docs/                                      ← workflow HTML, corrected
README.md
ROADMAP.md
```

Then:

```
git add -A
git commit -m "v1.1.4 — formatting spec, font rule, four new skills, card v2, DAX highlighting, corrected install method"
git push
```

Skills are scanned from the folder — nothing to register.

### Step 3 — install the plugins on YOUR machine (5 min)

Use the method at the top of this file. All five must appear under
**Agent Plugins - Installed**.

Do this before touching the team. You want to see it working once.

### Step 4 — the test that matters (20 min)

Take a page you've already built and rebuild it.

```
Compare against the old output. Look specifically for:
  · placeholder subtitles left in place
  · legend positions
  · number formatting
  · blank visuals
  · font family
```

This tells you whether the remaining problems were rules problems or were
the missing engine all along. **Don't skip it** — everything after this
depends on knowing the answer.

### Step 5 — the team (15 min)

If step 4 looks better, send the pilot devs this:

```
Quick fix — you probably only have 1 of 5 AgentAdam plugins installed.

1. Ctrl+Shift+P
2. Chat: Install Plugin From Source
3. Paste:  U357001_ibe/AgentAdam
4. The Extensions sidebar opens with all 5 listed
5. Click Install on each one
6. Check Extensions → Agent Plugins - Installed shows all 5

Two minutes. Should noticeably improve output quality.
```

Then share `DEPLOY/vscode-extension/agentadam-1.0.3.vsix` and post the
change summary in Teams. `REFERENCE/AgentAdam_Team_Update.html` has a
team-friendly version of what changed.

### Step 6 — Kurt's plugins, LATER (not today)

`DEPLOY/kurt-plugins-26.31.5/` holds his current four. Eleven weekly
releases of fixes since your 26.20.

**Deploy this as a separate change, a couple of weeks after the above.**
It changes build behaviour, where everything else in this release changes
rules. If both land in the same week and something comes out odd, you
won't know which to blame.

See `UPDATE-NOTES.md` in that folder. Binaries were stripped so the zip
passes mail filters — `MISSING-BINARIES.md` explains how to get them, and
the easier route if public GitHub is reachable from your machine.

---

## Verification

After deploying, put these to Copilot Chat:

```
"What is the canvas area and its coordinates?"
    y:136–1066, x:28–2535

"What colour means Bad in our charts?"
    orange #E3850D

"What font do we use, and where does it apply?"
    IberPangea, everywhere, no exceptions

"What do you check before formatting a visual?"
    vocabulary → standards → ask, in that order

"What card visual do you use by default?"
    Card Visual v2, no reference or detail labels

"How do you highlight the highest value in a bar chart?"
    SWITCH + MAXX, blue #017CBE

"How many slicers maximum on the top bar?"
    four, then the filter pane
```

Wrong answers mean SharePoint sync hasn't refreshed on that machine.
`Ctrl+Shift+P → Developer: Reload Window`.

Answering correctly isn't the same as applying it, though — build a page
and check the output too. That gap is exactly the drift you've been chasing.

---

## After this lands

**Change nothing for four to six weeks.** Use it on real work. Note what
goes wrong. One change at a time with weeks between, so when a developer
says "it did something odd" there's only one recent change to look at.

And wait until the same thing has gone wrong three times before writing a
rule for it. Most one-off problems are one-offs.

Worth trying once it's bedded in:

```
"run a go live readiness review"       against a report you know well —
                                       does it raise what you'd have raised?
"document this report for production"  check the lineage section is right
```

---

## Still parked

Not a backlog. Each needs a reason, or someone else's approval:

```
PBIP hot-reload          shipped August — Desktop now detects external
                         file changes. The "close Desktop first" rule
                         can relax. Do it after this settles.

pbir-cli                 pip install, so it may sidestep your CLI
                         blocker. Validates after every edit, screenshots
                         pages back to the agent, custom BPA rules that
                         could turn standards into pass/fail checks.
                         Kurt's skills already prefer it when present and
                         fall back cleanly when absent — no AgentAdam
                         changes needed either way.

Extension marketplace    removes the manual .vsix step
Single-plugin restructure one install gets everything
Version tracking         dev can see which version they're on
Microsoft engine swap    when Skills for Fabric is GA, IT approves CLI,
                         and the rename-breaks-visuals issue is fixed
MCP / Service            would let the readiness review run against the
                         live estate — needs XMLA read-write and a
                         tenant setting
```

Worth a 30-minute look each quarter. First one around Ignite.

---

## What's in the folders

```
DEPLOY/
  DEPLOY.md                 this file
  sharepoint-file/          the instructions file to upload
  repo-files/               everything to push to GitHub
  vscode-extension/         agentadam-1.0.3.vsix for the team
  kurt-plugins-26.31.5/     Kurt's current four — step 6, later
  guides-for-adam/          SharePoint setup reference

REFERENCE/
  AgentAdam_Developer_Workflow.html   setup guide for devs, install
                                      method corrected
  AgentAdam_Report_Planner.md         planning questionnaire
  AgentAdam_Team_Update.html          team-facing change summary
  AgentAdam_DataCommunity_Deck.html   the presentation
  AgentAdam_SHAREPOINT_SETUP_GUIDE.md
```

---

*Plugin v1.1.4 · extension v1.0.3 · instructions file dated 2026-08-27*
*Built on data-goblin by Kurt Buhler, used with permission. GPL-3.0.*
