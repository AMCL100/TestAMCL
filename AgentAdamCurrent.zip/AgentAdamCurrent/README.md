# AgentAdam — deployment package

*27 August 2026*

Nothing in here has been deployed yet. This is everything, in one go.

```
→  Open  DEPLOY/DEPLOY.md  and work through it.
```

About an hour, plus testing.

---

## The short version

```
1  Upload the instructions file to SharePoint            2 min
2  Push repo-files/ to GitHub                           10 min
3  Install the 5 plugins on YOUR machine                 5 min
4  Rebuild one page you know — compare the output       20 min
5  If better, roll out to the pilot devs                15 min
6  Kurt's plugin update — a couple of weeks LATER
```

**Step 3 matters most.** Kurt's four plugins have never been installed on
anyone's machine, including yours. The install format everyone was using
was wrong. Correct one:

```
Ctrl+Shift+P → Chat: Install Plugin From Source
Paste:  U357001_ibe/AgentAdam
Then click Install on each of the 5 in the sidebar
```

**Step 4 matters second.** It tells you whether the problems you've been
chasing were rules problems or a missing engine.

---

## What changed

```
Formatting specification   full spec for every visual type, so the
                           vocabulary page is optional not required
Font rule                  IberPangea, non-negotiable, everywhere
Card v2 default            reference/detail labels on request only
DAX highlighting           concrete max/min/average/threshold patterns
Four new skills            11 total, up from 7
Install method             corrected in the workflow HTML
Plugin                     v1.1.3 → v1.1.4
Kurt's plugins             26.31.5 included, deploy separately later
```

Plus all the June fixes that never went out.
